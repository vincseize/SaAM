
-- BACKUP BASE DE DONNÉES -- 
-- DATE (AA-MM-JJ): 2014-02-22 
-- FAITE PAR : MAILLARDET
-- 068e3504a03224b5832de5f9d29385eb 

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- ----------------- TABLE saam_acl ------------------------

DROP TABLE IF EXISTS `saam_acl`;

CREATE TABLE `saam_acl` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `grp_name` varchar(64) NOT NULL,
  `1` varchar(8) NOT NULL,
  `2` varchar(8) NOT NULL,
  `3` varchar(8) NOT NULL,
  `4` varchar(8) NOT NULL,
  `5` varchar(8) NOT NULL,
  `6` varchar(8) NOT NULL,
  `7` varchar(8) NOT NULL,
  `8` varchar(8) NOT NULL,
  `9` varchar(8) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `grp_name` (`grp_name`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

INSERT INTO `saam_acl` VALUES 
('1','VIEW_TOOLS_BTNS_ADMIN','N','A','N','N','A','A','A','A','A'),
('2','VIEW_TOOLS_BTNS_NOTES','N','A','A','A','A','A','A','A','A'),
('3','VIEW_TOOLS_BTNS_SCRIPT','N','A','A','A','A','A','A','A','A'),
('4','VIEW_TOOLS_BTNS_PLUGINS','N','N','A','A','A','A','A','A','A'),
('5','VIEW_TOOLS_BTNS_DEV','N','N','N','N','N','N','N','A','A'),
('6','VIEW_TOOLS_CAL','A','A','A','A','A','A','A','A','A'),
('7','VIEW_HEADER_BTN_PREF','N','A','A','A','A','A','A','A','A'),
('8','VIEW_HEADER_BTN_WIP','N','N','N','N','N','N','N','A','A'),
('9','VIEW_HEADER_SEARCH','N','A','A','A','A','A','A','A','A'),
('10','VIEW_HEADER_JCHAT','N','N','A','A','A','N','N','A','A'),
('11','VIEW_BANK_BTN_DEL','N','N','N','A','A','N','N','A','A'),
('12','VIEW_TOOLS_BTNS_BUGHUNTER','N','N','A','A','A','A','A','A','A'),
('13','VIEW_DEPT_PROD','N','N','N','N','N','A','A','A','A'),
('14','VIEW_DEPT_STRUCTURE','N','N','N','N','A','A','A','A','A'),
('15','SHOTS_ADMIN','N','N','N','N','A','N','A','A','A'),
('16','SHOTS_PUBLISH','N','A','O','O','A','N','A','A','A'),
('17','SHOTS_MESSAGE','N','A','O','O','A','N','A','A','A'),
('18','SHOTS_TAGS','N','A','O','O','A','N','A','A','A'),
('19','SHOTS_DEPTS_INFOS','N','A','O','O','A','N','A','A','A'),
('20','SHOTS_UPLOAD','N','A','O','O','A','N','A','A','A'),
('21','ASSETS_ADMIN','N','N','N','N','A','N','A','A','A'),
('23','ASSETS_MESSAGE','N','A','O','O','A','N','A','A','A'),
('24','ASSETS_PUBLISH','N','A','O','O','A','N','A','A','A'),
('25','ASSETS_TAGS','N','A','O','O','A','N','A','A','A'),
('26','ASSETS_UPLOAD','N','A','O','O','A','N','A','A','A'),
('27','ASSETS_HANDLE','N','N','O','O','A','N','A','A','A'),
('28','ASSETS_REVIEW_ASK','N','N','O','O','A','N','N','A','A'),
('29','ASSETS_REVIEW_VALID','N','N','N','N','O','N','N','A','A'),
('30','SCENES_ADMIN','N','N','N','N','A','A','A','A','A'),
('31','SCENES_HANDLE','N','N','O','O','A','N','A','A','A'),
('32','SCENES_PUBLISH','N','A','O','O','A','N','A','A','A'),
('33','SCENES_MESSAGE','N','A','O','O','A','N','A','A','A'),
('34','SCENES_REVIEW_ASK','N','N','O','O','A','N','N','A','A'),
('35','SCENES_REVIEW_VALID','N','N','N','N','O','N','N','A','A'),
('36','BANK_UPLOAD','N','A','A','A','A','A','A','A','A'),
('37','ASSETS_CREATE','N','N','N','N','A','A','A','A','A');


-- ----------------- TABLE saam_all_langs ------------------------

DROP TABLE IF EXISTS `saam_all_langs`;

CREATE TABLE `saam_all_langs` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `constante` varchar(25) NOT NULL,
  `fr` tinytext NOT NULL,
  `en` tinytext NOT NULL,
  `ar` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `constante` (`constante`)
) ENGINE=MyISAM AUTO_INCREMENT=233 DEFAULT CHARSET=utf8;

INSERT INTO `saam_all_langs` VALUES 
('1','L_VERSION','Version','Version',''),
('2','L_VERSIONS','Versions','Versions',''),
('3','L_PROJECT','Projet','Project','مخطط'),
('9','L_CONX_ASK','Merci d\'entrer vos identifiants','Please enter your ID\'s',''),
('10','L_CONX_BYE','À bientot','Be seeing you',''),
('23','L_SEQUENCE','Séquence','Sequence',''),
('24','L_SHOT','Plan','Shot',''),
('26','L_BTN_PREFS','PRÉFÉRENCES','PREFERENCES','بالأفضليات'),
('27','L_BTN_HELP','AIDE','HELP','مساعدة'),
('28','L_BTN_ADMIN_NEWS','Gestion Nouvelles','Admin News',''),
('29','L_BTN_ADMIN_USERS','Gestion Utilisateurs','Admin Users',''),
('30','L_BTN_ADMIN_PROJECTS','Gestion Projets','Admin Projects',''),
('31','L_BTN_ADMIN','Administration','Administration',''),
('32','L_BTN_NOTES','NOTES','NOTES',''),
('33','L_BTN_SCRIPT','SCRIPTS','SCRIPTS',''),
('34','L_BTN_CONFIG','CONFIG','CONFIG',''),
('35','L_BTN_UPDATE','MISE À JOUR','UPDATE',''),
('36','L_BTN_SQL','OUTILS SQL','SQL TOOLS',''),
('37','L_BTN_API','API','API',''),
('38','L_BTN_LANGUAGES','LANGUES','LANGUAGES','لغة'),
('39','L_BTN_DEBUG','DÉBUG','DEBUG',''),
('40','L_BTN_TRBACK','TRACKBACKS','TRACKBACKS',''),
('41','L_BTN_YES','OUI','YES','بلى'),
('42','L_BTN_NO','NON','NO','لا'),
('43','L_CONX_ERR','Mauvais pseudo / mot de passe','Bad login / password',''),
('44','L_ASSET','Asset','Asset',''),
('45','L_BTN_RECETTE','RECETTE','RECETTE',''),
('46','L_WIP','! Travaux en cours !','! work in progress !',''),
('47','L_DEMO_MODE','Mode démo actif','Demo mode activated',''),
('48','L_BTN_FAQ','FAQ','FAQ',''),
('49','L_BTN_FRAMEWORK','FRAMEWORK','FRAMEWORK',''),
('50','L_BTN_WIP','WIP','WIP',''),
('51','L_PROJECTS','Projets','Projects',''),
('52','L_SEQUENCES','Séquences','Sequences',''),
('92','L_SHOTS','Plans','Shots',''),
('54','L_BTN_DISCONNECT','Déconnexion','Log out',''),
('55','L_GL_ADD','ajouter','add',''),
('56','L_GL_DEL','supprimer','delete',''),
('57','L_GL_MOD','modifier','modify',''),
('58','L_BTN_PROJ_ADD','ajouter projet','add project',''),
('59','L_BTN_SEQ_ADD','ajouter séquence','add sequence',''),
('60','L_BTN_SHOT_ADD','ajouter plan','add shot',''),
('61','L_BTN_ASSET_ADD','ajouter asset','add asset',''),
('62','L_BTN_ASSET_MOD','modifier asset','modify asset',''),
('63','L_BTN_ASSET_DEL','supprimer asset','delete asset',''),
('64','L_ASSETS','Assets','Assets',''),
('65','L_GLOBAL_VIEW','Vue d\'ensemble','Overview',''),
('66','L_DAILIES','DAILIES','DAILIES',''),
('67','L_STRUCTURE','STRUCTURE PLANS','SHOTS STRUCTURE',''),
('68','L_BUDGET','BUDGET','FINANCE',''),
('69','L_FPS','Fps','Fps',''),
('70','L_FORMAT','Format','Format',''),
('71','L_FRAMES','Frames','Frames',''),
('72','L_YEAR','An','Year',''),
('73','L_YEARS','Ans','Years',''),
('75','L_WEEK','Semaine','Week',''),
('76','L_WEEKS','Semaines','Weeks',''),
('78','L_DAY','Jour','Day',''),
('79','L_DAYS','Jours','Days',''),
('80','L_DAYX','Jour(s)','Day(s)',''),
('81','L_HOUR','Heure','Hour',''),
('82','L_HOURS','Heures','Hours',''),
('93','L_OUTDATE_SINCE','Dépassée depuis','Outdated since',''),
('84','L_MINUTE','Minute','Minute',''),
('85','L_MINUTES','Minutes','Minutes',''),
('87','L_SECOND','Seconde','Second',''),
('88','L_SECONDS','Secondes','Seconds',''),
('90','L_MONTH','Mois','Month',''),
('91','L_MONTHS','Mois','Month',''),
('94','L_BANK','BANK','BANK',''),
('95','L_NO_RETAKE','Pas encore de published.','No published.',''),
('96','L_RETAKE_MESSAGES','Messages du published','Published\'s messages',''),
('103','L_CURRENT','en cours','current',''),
('98','L_BTN_BUGHUNTER','BUG HUNTER','BUG HUNTER',''),
('99','L_ADD_MESSAGE','Nouveau message','New message',''),
('100','L_ADD_RETAKE_ERROR','Il faut uploader un published avant de valider. Glissez-déposez un fichier sur la zone mauve.','You must upload a published before validate. Drag and drop a file on the purple zone.',''),
('101','L_TODAY','Aujourd\'hui','Today',''),
('102','L_TOMORROW','Demain','Tomorrow',''),
('104','L_SHORTCUTS','Raccourcis','Shortcuts',''),
('105','L_FILETYPE_ALLOW','Types de fichiers authorisés','Allowed filetypes',''),
('106','L_FRAMERATE','Cadence','Framerate',''),
('108','L_DESCRIPTION','Description','Description',''),
('109','L_USTATUS_LEAD','Lead','Lead',''),
('110','L_USTATUS_SUPERVISOR','Superviseur','Supervisor',''),
('111','L_TITLE','Titre','Title',''),
('112','L_DATE','Date','Date',''),
('113','L_DATES','Dates','Dates',''),
('114','L_MODIFICATION','Modification','Update',''),
('115','L_BTN_VALID','Valider','Validate',''),
('118','L_BTN_CANCEL','Annuler','Cancel',''),
('119','L_RANGE','Bornes','Range',''),
('120','L_START','Début','Start',''),
('121','L_END','Fin','End',''),
('122','L_WELCOME','BIENVENUE','WELCOME',''),
('123','L_TRACKBACK_LINK','Voir la liste des bugs','View the list of bugs',''),
('124','L_BTN_ADD_BUG','J\'ai trouvé un bug','I found a bug',''),
('125','L_THANKS_BUG','MERCI de votre contribution !','THANK YOU for your contribution!',''),
('126','L_FINAL','FINAL','FINAL',''),
('127','L_CREATOR','Créateur','Creator',''),
('128','L_SHOW','Montrer','Show',''),
('129','L_HIDE','Cacher','Hide',''),
('130','L_LOCK','Bloquer','Lock',''),
('131','L_MODIFY','Modifier','Modify',''),
('132','L_ARCHIVE','Archiver','Archive',''),
('133','L_RESTORE','restaurer','restore',''),
('134','L_DESTRUCT','détruire','destroy',''),
('135','L_SCENARIO','scénario','scenario',''),
('136','L_SOUND','son','sound',''),
('137','L_DECTECH','dec.tech.','tech.script',''),
('138','L_STORYBOARD','storyboard','storyboard',''),
('139','L_DEPTS','Départements','Departments',''),
('140','L_INTERFACE','Interface','Interface',''),
('141','L_PLUGINS','Plugins','Plugins',''),
('142','L_MAJ','Mise à jour','Update',''),
('143','L_ABOUT','À propos','About',''),
('144','L_BTN_ADD_DEPT','Ajouter un département','Add a department',''),
('145','L_ADMIN_DEPT','Gestion des départements','Manage departments',''),
('146','L_LOCKED','Bloqué','Locked',''),
('147','L_TEAM','Équipe','Team',''),
('148','L_ASSIGNED_TO','plans / assets attribués à','shots / assets assigned to',''),
('149','L_NOTHING','Aucun','No',''),
('150','L_FIRST_TIME','C\'est la première fois que vous venez ? Choisissez un département !','First time you come here ? Choose a department !',''),
('151','L_ETAPES','Étapes','Steps',''),
('152','L_TAGS','Tags','Tags',''),
('153','L_APPROVED','Validé','Approved',''),
('154','L_ASSIGNMENTS','Assignations','Assignments',''),
('155','L_ADD_RETAKE','Créer un published','Add a published',''),
('156','L_ASSET_HUNG_BY','Tenu par','Hung by',''),
('157','L_ASSET_FREE','libre','free',''),
('158','L_NOBODY','Personne','Nobody',''),
('159','L_FREE_ASSET','Libérer asset','Free asset',''),
('160','L_ASSET_HANDLE','Prendre la main','Handle asset',''),
('161','L_NOTES','Notes','Notes',''),
('162','L_NEWS','Nouvelles','News',''),
('163','L_RETAKES','Published','Published',''),
('164','L_USERS','Utilisateurs','Users',''),
('165','L_MY_SHOTS','Vos plans','Your shots',''),
('166','L_MY_ASSETS','Vos assets','Your assets',''),
('167','L_MY_NOTES','Vos notes','Your notes',''),
('168','L_ROOT','Racine','Root',''),
('169','L_INFOS','Infos','Infos',''),
('170','L_DIRECTOR','Réalisateur','Director',''),
('171','L_OTHERS','Autres','Others',''),
('172','L_THIS_WEEK','Cette semaine','This week',''),
('173','L_LAST_WEEK','La semaine dernière','Past week',''),
('174','L_DAILY','Daily','Daily',''),
('175','L_ADD','Ajouter','Add',''),
('176','L_DELETE','Supprimer','Delete',''),
('177','L_LIST','Liste','List',''),
('178','L_NO_NOTE','Aucune note','No note',''),
('179','L_DECTECH_LONG','Découpage technique','technical script',''),
('180','L_CALENDAR','Calendrier','Calendar',''),
('181','L_INTRANET','Intranet','Intranet',''),
('182','L_BTN_SAVE','Sauvegarder','Save',''),
('183','L_DEPENDENCIES','Dépendances','Dependencies',''),
('184','L_IN_SCENES','Utilisé dans les scènes','Used in scenes',''),
('185','L_SCENES','Scènes','Scenes',''),
('186','L_SCENE','Scène','Scene',''),
('187','L_PROD','Prod','Prod',''),
('188','L_SCHEDULE','Calendrier','Schedule',''),
('190','L_EVERYTHING','Tout','All',''),
('191','L_KEYFRAME','Keyframe','Keyframe',''),
('192','L_MOCAP','Mocap','Mocap',''),
('193','L_VFX','VFX','VFX',''),
('194','L_SET','Set','Set',''),
('195','L_VIEW_MODE','Mode d\'Affichage','View Mode',''),
('196','L_NO_SCENE','Aucune scène','No scene',''),
('197','L_SELECT_SCENE','Sélectionnez une scène','Select a scene',''),
('198','L_DERIVATIVES','Dérivées','Derivatives',''),
('199','L_DERIVATIVE','Dérivée','Derivative',''),
('200','L_MASTER','Master','Master',''),
('201','L_ASSIGN','Assigner','Assign',''),
('202','L_CAMERAS','Cameras','Cameras',''),
('203','L_MANAGE','Gérer','Manage',''),
('204','L_USER_PREFS_INFOS','Infos utilisateur','User infos',''),
('205','L_USER_PREFS_UI','Interface utilisateur','User interface',''),
('206','L_OPEN','Ouvrir','Open',''),
('207','L_LABEL','Label','Label',''),
('208','L_ARTISTS','Artistes','Artists',''),
('209','L_ANSWER','Répondre','Answer',''),
('210','L_REM_TIME','Temps qu\'il reste','Remaining time',''),
('211','L_SUPERVISOR','Superviseur','Supervisor',''),
('212','L_LEAD','Lead','Lead',''),
('213','L_ADD_PROJECT','Ajout de projet','Adding project',''),
('214','L_BASE_INFOS','Informations de base','Base informations',''),
('215','L_PROJECT_NAME','Nom du projet','Project name',''),
('216','L_PRODUCTION','Production','Production',''),
('217','L_NOMENCLATURA','Nomenclature','Nomenclatura',''),
('218','L_REF','Référence','Reference',''),
('219','L_PROJECT_TYPE','Type de projet','Project type',''),
('220','L_SOFTWARE_USED','Logiciels utilisés','Used Softwares',''),
('221','L_VIGNETTE','Vignette','Vignette',''),
('222','L_SEND','Envoyer','Send',''),
('223','L_NEXT','Suivant','Next',''),
('224','L_DONE','Terminé','Done',''),
('225','L_BTN_TUTOS','TUTORIELS','TUTORIALS',''),
('226','L_TUTO_FOR','Tutoriels pour','Tutorials for',''),
('227','L_ALL_USERS','Tout le monde','Everybody',''),
('228','L_ARTIST','Artiste','Artist',''),
('229','L_DIR_PROD','Dir. production','Prod manager',''),
('230','L_DEVELOPPER','Développeur','Developper',''),
('231','L_VISITOR','Visiteur','Visitor',''),
('232','L_MAGIC','Magique','Magic','');


-- ----------------- TABLE saam_assets ------------------------

DROP TABLE IF EXISTS `saam_assets`;

CREATE TABLE `saam_assets` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `category` int(2) NOT NULL DEFAULT '0',
  `filename` varchar(256) NOT NULL,
  `path_relative` varchar(256) NOT NULL,
  `ID_projects` text NOT NULL,
  `ID_shots` text NOT NULL,
  `ID_creator` int(6) NOT NULL,
  `ID_handler` int(6) NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `review` text NOT NULL,
  `custom_attr` text NOT NULL,
  `deadline` datetime NOT NULL,
  `date` datetime NOT NULL,
  `update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(6) NOT NULL,
  `hide` tinyint(1) NOT NULL,
  `checkretake` tinyint(1) NOT NULL,
  `progress` int(3) NOT NULL,
  `team` varchar(256) NOT NULL,
  `relations_assets` text NOT NULL,
  `archive` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filename` (`filename`),
  KEY `category` (`category`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;

INSERT INTO `saam_assets` VALUES 
('12','1','moon.blend','./characters/moon/','[\"277\"]','','4','0','La belle Lune de mai','','','0000-00-00 00:00:00','2013-04-04 23:01:21','2014-02-12 21:07:23','4','0','0','0','[\"4\",\"73\"]','[\"Marcel_000.blend\"]','0'),
('13','1','crastor.blend','./characters/crastors/','[\"277\"]','[\"856\",\"857\"]','4','4','Petite bestiole mi-castor mi-lapin, complètement débile et qui mange du bois !','','','0000-00-00 00:00:00','2013-04-04 23:05:12','2014-02-12 20:03:15','4','0','0','0','[\"4\",\"73\"]','[\"Marcel_000.blend\",\"horse.blend\"]','0'),
('14','1','Marcel_000.blend','./characters/marcel/','[\"277\"]','[\"855\",\"856\"]','4','0','wazaaa','','','0000-00-00 00:00:00','2013-04-04 23:42:24','2014-02-12 20:06:18','4','0','0','0','[\"4\",\"73\"]','[\"moon.blend\",\"crastor.blend\"]','0'),
('15','4','ballon1.blend','./props/ballons/','[\"277\"]','','4','0','','','','0000-00-00 00:00:00','2013-04-05 18:25:40','2013-04-05 18:25:40','4','0','0','0','','','0'),
('16','2','Marcel-Bedroom.blend','./sets/bedroom/','[\"277\"]','','4','0','','','','0000-00-00 00:00:00','2013-04-05 23:17:37','2013-10-20 20:15:56','4','0','0','0','','[\"crastor.blend\",\"Marcel_000.blend\"]','0'),
('17','2','phare-eglise-int-ground.blend','./sets/phare-eglise-int/','[\"277\"]','','4','0','','','','0000-00-00 00:00:00','2013-04-06 12:01:53','2013-12-20 20:58:34','4','0','0','0','','','0'),
('19','3','Barrique.blend','./props/phare_ground/barrique/','[\"277\"]','','4','0','','','','0000-00-00 00:00:00','2013-05-16 20:28:10','2013-10-20 20:15:20','4','1','0','0','[\"2\",\"4\"]','','0'),
('18','0','neige.blend','./materials/','[\"277\"]','','4','0','','','','0000-00-00 00:00:00','2013-05-08 00:47:43','2013-09-15 18:30:10','4','0','0','0','[\"4\"]','','0'),
('20','0','scaphandre.blend','./props/phare_ground/scaphandre/','[\"277\"]','','4','0','','','','0000-00-00 00:00:00','2013-05-24 14:23:48','2013-07-22 16:22:07','4','0','0','0','[\"4\"]','','0'),
('21','1','gus.blend','./characters/gus/','[\"1\"]','','1','0','','','','0000-00-00 00:00:00','2013-05-25 01:23:51','2013-11-13 13:36:42','4','0','0','0','[\"2\",\"4\"]','','0'),
('22','0','ciel1.JPG','./mattpaintings/','[\"277\"]','','4','0','','','','0000-00-00 00:00:00','2013-06-13 16:36:38','2013-07-22 16:21:39','4','0','0','0','[\"4\"]','','0'),
('23','0','kid.blend','./characters/kid/','[\"1\"]','','4','0','','','','0000-00-00 00:00:00','2013-06-15 15:18:49','2013-11-13 13:37:14','4','0','0','0','[\"2\",\"4\"]','','0'),
('24','3','casque_pompier.blend','./props/casque_pompier/','[\"277\"]','','4','0','yeah','','','0000-00-00 00:00:00','2013-07-12 23:30:13','2013-09-23 16:16:26','4','0','0','0','[\"2\",\"4\"]','[\"ballon1.blend\"]','0'),
('25','0','chapka.blend','./props/chapka/','[\"277\"]','','4','0','','','','0000-00-00 00:00:00','2013-07-12 23:30:17','2013-07-12 23:30:17','4','0','0','0','','','0'),
('26','0','ocean_water.blend','./materials/','[\"277\"]','','4','0','','','','0000-00-00 00:00:00','2013-07-22 16:21:31','2013-07-22 16:21:34','4','0','0','0','[\"4\"]','','0'),
('27','0','ciel2.JPG','./mattpaintings/','[\"277\"]','','4','0','','','','0000-00-00 00:00:00','2013-07-22 16:21:40','2013-07-22 16:21:43','4','0','0','0','[\"4\"]','','0'),
('28','0','horse.blend','./props/chambre/horse/','[\"277\"]','','4','0','','','','0000-00-00 00:00:00','2013-07-22 16:21:56','2013-07-22 16:21:59','4','0','0','0','[\"2\",\"4\"]','','0'),
('29','0','kid_001.blend','./characters/kid/','[\"1\"]','','4','0','','','','0000-00-00 00:00:00','2013-07-24 17:25:24','2013-07-24 17:25:24','4','0','0','0','','','0'),
('30','1','gniuk.blend','./characters/gniuk/','[\"277\"]','','4','0','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','2014-02-13 15:59:43','4','0','0','0','[\"4\",\"73\"]','','0'),
('38','0','ciel_de_ouf.jpg','./mattpainting/','[\"1\"]','','4','0','','','','0000-00-00 00:00:00','2013-11-13 13:36:58','2013-11-13 13:37:05','4','0','0','0','[\"2\",\"4\"]','','0'),
('39','2','bigIsland.blend','./sets/bigIsland/','[\"277\"]','','4','0','','','','0000-00-00 00:00:00','2013-12-20 20:58:17','2013-12-20 20:58:18','4','0','0','0','','','0'),
('40','2','littleIsland.blend','./sets/littleIsland/','[\"277\"]','','4','0','','','','0000-00-00 00:00:00','2013-12-20 20:58:21','2013-12-20 20:58:23','4','0','0','0','','','0'),
('41','2','Phare-Eglise-EXT_000.blend','./sets/phare-eglise-ext/','[\"277\"]','','4','0','','','','0000-00-00 00:00:00','2013-12-20 20:58:27','2013-12-20 20:58:30','4','0','0','0','','','0'),
('42','2','pont-inter-iles.blend','./sets/pont-inter-iles/','[\"277\"]','','4','0','','','','0000-00-00 00:00:00','2013-12-20 20:58:36','2013-12-20 20:58:38','4','0','0','0','','','0'),
('51','1','test_addAsset1.blend','./tests/gniuk/blah/','[\"277\"]','','4','0','','','','2014-03-06 00:00:00','2014-02-24 00:00:00','2014-02-22 02:15:52','4','0','0','0','[\"4\",\"58\",\"72\",\"73\"]','','0'),
('52','3','test_addAsset2.blend','./ohhhYeah/','[\"277\"]','','4','0','','','','2014-03-19 00:00:00','2014-02-17 00:00:00','2014-02-22 02:19:47','4','0','0','0','[\"4\"]','','0');


-- ----------------- TABLE saam_assets_depts_infos ------------------------

DROP TABLE IF EXISTS `saam_assets_depts_infos`;

CREATE TABLE `saam_assets_depts_infos` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `ID_project` int(4) NOT NULL,
  `ID_asset` int(6) NOT NULL,
  `8` varchar(256) NOT NULL,
  `9` varchar(256) NOT NULL,
  `10` varchar(256) NOT NULL,
  `12` varchar(256) NOT NULL,
  `11` varchar(256) NOT NULL,
  `13` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `saam_assets_depts_infos` VALUES 
('2','277','13','{\"assetStep\":99}','{\"retake\":true,\"assetStep\":99}','','{\"retake\":true,\"assetStep\":1}','{\"assetStep\":1}','{\"assetStep\":99}'),
('6','277','12','','{\"assetStep\":0}','','{\"assetStep\":0,\"retake\":false}','',''),
('5','277','16','{\"assetStep\":0,\"retake\":false}','{\"assetStep\":0,\"retake\":true}','','','',''),
('7','277','14','{\"retake\":false,\"assetStep\":0}','{\"assetStep\":0}','','{\"assetStep\":0}','{\"assetStep\":2}',''),
('8','277','24','','{\"assetStep\":0}','','','',''),
('9','1','21','','{\"assetStep\":0}','','','',''),
('10','277','18','','{\"assetStep\":0}','','','',''),
('11','277','19','','{\"assetStep\":0}','','','','');


-- ----------------- TABLE saam_cameras ------------------------

DROP TABLE IF EXISTS `saam_cameras`;

CREATE TABLE `saam_cameras` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `ID_project` int(6) NOT NULL,
  `ID_scene` int(6) NOT NULL,
  `ID_sequence` int(6) NOT NULL,
  `ID_shot` int(6) NOT NULL,
  `ID_creator` int(6) NOT NULL,
  `update` datetime NOT NULL,
  `updated_by` int(6) NOT NULL,
  `tags` text NOT NULL,
  `hide` tinyint(1) NOT NULL,
  `archive` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

INSERT INTO `saam_cameras` VALUES 
('11','CAM_002_M_001_D_002_ZOU','277','12','0','0','4','2014-01-29 15:45:34','4','','0','0'),
('10','CAM_001_M_001_D_002_TESTYEAH','277','12','0','0','4','2014-01-29 15:12:16','4','','0','0'),
('9','CAM_003_M_001_D_001_BLAH','277','10','353','855','4','2014-01-29 15:45:39','4','','0','0'),
('8','CAM_002_M_001_D_001_TEST','277','10','0','0','4','2014-01-29 15:45:25','4','','0','0'),
('7','CAM_001_M_001_D_001_SHOT001','277','10','353','808','4','2014-01-29 15:45:37','4','','0','0'),
('22','CAM_001_M_002_D_001_ZAA','277','11','0','0','4','2014-02-01 00:45:15','4','','0','0'),
('23','CAM_001_M_002_D_001_ZAAX','277','11','378','982','4','2014-02-01 00:45:26','4','','0','0');


-- ----------------- TABLE saam_comments_asset ------------------------

DROP TABLE IF EXISTS `saam_comments_asset`;

CREATE TABLE `saam_comments_asset` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `ID_asset` int(9) NOT NULL,
  `ID_project` int(6) NOT NULL,
  `dept` varchar(64) NOT NULL,
  `response_to` int(12) NOT NULL,
  `comment` text NOT NULL,
  `senderId` int(6) NOT NULL,
  `senderLogin` varchar(32) NOT NULL,
  `senderStatus` int(2) NOT NULL,
  `sender` varchar(256) NOT NULL,
  `num_retake` int(3) NOT NULL,
  `read_by` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ID_asset` (`ID_asset`),
  KEY `response_to` (`response_to`),
  KEY `num_retake` (`num_retake`)
) ENGINE=MyISAM AUTO_INCREMENT=108 DEFAULT CHARSET=utf8;

INSERT INTO `saam_comments_asset` VALUES 
('42','13','277','10','0','test yeah','4','polosson','9','Polo','1','','2013-04-06 12:19:16'),
('43','13','277','10','42','test reponse YEAH !','4','polosson','9','Polo','1','','2013-04-06 12:19:29'),
('50','13','277','10','0','hop la, vla pour les assets, un ptit message ?','3','moutew','8','Moutew','1','','2013-07-12 16:51:27'),
('51','24','277','10','0','zawaaaaa','4','polosson','9','Polo','1','','2013-07-14 20:09:55'),
('52','24','277','10','0','Cool ...
En tout cas te prends pas trop le choux, dans le sens ou ce sont des assets mineurs ...
Bienvenue dans l\'\'équipe Azuk !','4','polosson','9','Polo','1','','2013-07-14 20:10:48'),
('53','24','277','10','0','Voyons voir ce que ça donne avec un petit urlencode ?
Hop j\'ai sauté une ligne !!

\"attention\" les vélos nom d\'\'unchien\'\'
^^
:D

','4','polosson','9','Polo','1','','2013-07-14 20:17:38'),
('57','13','277','10','0','owkay, 1er message','58','debug','3','debug','1','','2013-07-17 23:39:18'),
('65','13','277','10','57','owkay','58','debug','3','debug','1','','2013-07-17 23:54:58'),
('77','13','277','10','0','rhoooo
magnifique','4','polosson','9','Polo','2','','2013-09-06 02:53:09'),
('67','12','277','10','0','En voila une belle Lune !! Un peu stretchée mais ça va...','4','polosson','9','Polo','2','','2013-08-31 02:09:11'),
('68','12','277','10','67','Non, elle est stretchée parce que l\'image n\'est pas au format du film.','4','polosson','9','Polo','2','','2013-08-31 02:09:34'),
('69','12','277','10','67','Ah, ok je vois','4','polosson','9','Polo','2','','2013-08-31 02:09:43'),
('70','12','277','10','0','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec a diam lectus. Sed sit amet ipsum mauris. Maecenas congue ligula ac quam viverra nec consectetur ante hendrerit. Donec et mollis dolor. Praesent et diam eget libero egestas mattis sit amet vitae augue. Nam tincidunt congue enim, ut porta lorem lacinia consectetur. Donec ut libero sed arcu vehicula ultricies a non tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit','4','polosson','9','Polo','2','','2013-08-31 02:10:11'),
('71','12','277','10','70','okok','4','polosson','9','Polo','2','','2013-08-31 02:10:18'),
('72','13','277','10','0','yeah','4','polosson','9','Polo','3','','2013-09-04 19:16:16'),
('73','13','277','10','0','et là ? C good ?','4','polosson','9','Polo','6','','2013-09-04 19:18:01'),
('74','13','277','10','73','c\'est goooood !!','4','polosson','9','Polo','6','','2013-09-04 19:18:15'),
('75','13','277','10','50','owkay, pourquoi pas, mais c\'est le dernier !
lol','4','polosson','9','Polo','1','','2013-09-04 19:18:41'),
('78','13','277','10','0','sfgsfgb sfdb sfdbsfdsfgb','4','polosson','9','Polo','2','','2013-09-06 03:15:35'),
('80','12','277','9','0','Test de commentaire depuis l\'API !','4','polosson','9','Polo','2','','2013-09-23 02:19:45'),
('81','13','277','9','0','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec a diam lectus. Sed sit amet ipsum mauris. Maecenas congue ligula ac quam viverra nec consectetur ante hendrerit. Donec et mollis dolor. Praesent et diam eget libero egestas mattis sit amet vitae augue. Nam tincidunt congue enim, ut porta lorem lacinia consectetur. Donec ut libero sed arcu vehicula ultricies a non tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean ut gravida lorem. Ut turpis felis, pulvinar a semper sed, adipiscing id dolor. Pellentesque auctor nisi id magna consequat sagittis. Curabitur dapibus enim sit amet elit pharetra tincidunt feugiat nisl imperdiet. Ut convallis libero in urna ultrices accumsan. Donec sed odio eros. Donec viverra mi quis quam pulvinar at malesuada arcu rhoncus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. In rutrum accumsan ultricies. Mauris vitae nisi at sem facilisis semper ac in est.','4','polosson','9','Polo','1','','2013-09-23 02:20:42'),
('94','14','277','9','91','et pis moi !','4','polosson','9','Polo','2','','2013-11-13 01:04:20'),
('93','14','277','9','91','oh oui !','4','polosson','9','Polo','2','','2013-11-13 01:04:07'),
('89','14','277','9','87','yo 2','4','polosson','9','Polo','2','','2013-11-13 01:03:14'),
('90','14','277','9','87','yo 3','4','polosson','9','Polo','2','','2013-11-13 01:03:22'),
('91','14','277','9','0','mouagahahaha','4','polosson','9','Polo','2','','2013-11-13 01:03:50'),
('92','14','277','9','91','t\'en veux ?','4','polosson','9','Polo','2','','2013-11-13 01:04:01'),
('88','14','277','9','87','yo 1','4','polosson','9','Polo','2','','2013-11-13 01:03:09'),
('95','14','277','9','91','wouzaa','4','polosson','9','Polo','2','','2013-11-13 01:05:12'),
('96','14','277','9','87','yo 4','4','polosson','9','Polo','2','','2013-11-13 01:05:31'),
('97','14','277','9','87','yo da !','4','polosson','9','Polo','2','','2013-11-13 01:05:40'),
('98','14','277','9','0','burped code','4','polosson','9','Polo','2','','2013-11-13 01:20:16'),
('83','13','277','9','0','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec a diam lectus. Sed sit amet ipsum mauris. Maecenas congue ligula ac quam viverra nec consectetur ante hendrerit. Donec et mollis dolor. Praesent et diam eget libero egestas mattis sit amet vitae augue. Nam tincidunt congue enim, ut porta lorem lacinia consectetur. Donec ut libero sed arcu vehicula ultricies a non tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean ut gravida lorem. Ut turpis felis, pulvinar a semper sed, adipiscing id dolor. Pellentesque auctor nisi id magna consequat sagittis. Curabitur dapibus enim sit amet elit pharetra tincidunt feugiat nisl imperdiet. Ut convallis libero in urna ultrices accumsan. Donec sed odio eros. Donec viverra mi quis quam pulvinar at malesuada arcu rhoncus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. In rutrum accumsan ultricies. Mauris vitae nisi at sem facilisis semper ac in est.','4','polosson','9','Polo','1','','2013-09-23 02:20:42'),
('84','13','277','9','0','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec a diam lectus. Sed sit amet ipsum mauris. Maecenas congue ligula ac quam viverra nec consectetur ante hendrerit. Donec et mollis dolor. Praesent et diam eget libero egestas mattis sit amet vitae augue. Nam tincidunt congue enim, ut porta lorem lacinia consectetur. Donec ut libero sed arcu vehicula ultricies a non tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean ut gravida lorem. Ut turpis felis, pulvinar a semper sed, adipiscing id dolor. Pellentesque auctor nisi id magna consequat sagittis. Curabitur dapibus enim sit amet elit pharetra tincidunt feugiat nisl imperdiet. Ut convallis libero in urna ultrices accumsan. Donec sed odio eros. Donec viverra mi quis quam pulvinar at malesuada arcu rhoncus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. In rutrum accumsan ultricies. Mauris vitae nisi at sem facilisis semper ac in est.','4','polosson','9','Polo','2','','2013-09-23 02:20:42'),
('85','13','277','9','0','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec a diam lectus. Sed sit amet ipsum mauris. Maecenas congue ligula ac quam viverra nec consectetur ante hendrerit. Donec et mollis dolor. Praesent et diam eget libero egestas mattis sit amet vitae augue. Nam tincidunt congue enim, ut porta lorem lacinia consectetur. Donec ut libero sed arcu vehicula ultricies a non tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean ut gravida lorem. Ut turpis felis, pulvinar a semper sed, adipiscing id dolor. Pellentesque auctor nisi id magna consequat sagittis. Curabitur dapibus enim sit amet elit pharetra tincidunt feugiat nisl imperdiet. Ut convallis libero in urna ultrices accumsan. Donec sed odio eros. Donec viverra mi quis quam pulvinar at malesuada arcu rhoncus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. In rutrum accumsan ultricies. Mauris vitae nisi at sem facilisis semper ac in est.','4','polosson','9','Polo','2','','2013-09-23 02:20:42'),
('86','13','277','9','0','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec a diam lectus. Sed sit amet ipsum mauris. Maecenas congue ligula ac quam viverra nec consectetur ante hendrerit. Donec et mollis dolor. Praesent et diam eget libero egestas mattis sit amet vitae augue. Nam tincidunt congue enim, ut porta lorem lacinia consectetur. Donec ut libero sed arcu vehicula ultricies a non tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean ut gravida lorem. Ut turpis felis, pulvinar a semper sed, adipiscing id dolor. Pellentesque auctor nisi id magna consequat sagittis. Curabitur dapibus enim sit amet elit pharetra tincidunt feugiat nisl imperdiet. Ut convallis libero in urna ultrices accumsan. Donec sed odio eros. Donec viverra mi quis quam pulvinar at malesuada arcu rhoncus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. In rutrum accumsan ultricies. Mauris vitae nisi at sem facilisis semper ac in est.','4','polosson','9','Polo','2','','2013-09-23 02:20:42'),
('87','14','277','9','0','waz az !!','4','polosson','9','Polo','2','','2013-10-03 16:36:25'),
('99','13','277','13','0','Un ptit message pour tester le nouveau fonctionnement de l\'envoi de mail !!

On verra bien ce que ça donne !!','4','polosson','9','Polo','6','','2014-02-03 14:45:16'),
('100','12','277','12','0','Test blah blah new mess\'age \"dho\" !!

Vla','4','polosson','9','Polo','1','','2014-02-05 01:27:15'),
('101','12','277','12','0','Waahzzoy','4','polosson','9','Polo','2','','2014-02-05 02:08:32'),
('102','12','277','12','101','qdfgqdf g','4','polosson','9','Polo','2','','2014-02-05 02:09:23'),
('105','12','277','12','0','ertyerty','4','polosson','9','Polo','2','','2014-02-05 03:09:30'),
('106','12','277','12','0','Test waaazou','73','artiste','3','Artiste','2','','2014-02-12 21:07:03'),
('107','12','277','12','106','OKOK bon bah...','4','polosson','9','Polo','2','','2014-02-12 21:07:23');


-- ----------------- TABLE saam_comments_final ------------------------

DROP TABLE IF EXISTS `saam_comments_final`;

CREATE TABLE `saam_comments_final` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `ID_project` int(9) NOT NULL,
  `response_to` int(12) NOT NULL,
  `comment` text NOT NULL,
  `senderId` int(6) NOT NULL,
  `senderLogin` varchar(32) NOT NULL,
  `senderStatus` int(2) NOT NULL,
  `sender` varchar(256) NOT NULL,
  `read_by` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ID_project` (`ID_project`),
  KEY `response_to` (`response_to`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

INSERT INTO `saam_comments_final` VALUES 
('10','277','0','la grande classe','3','moutew','8','Moutew','','2013-11-22 23:41:38'),
('11','277','10','yep, pas mal, no ?','4','polosson','9','Polo','','2013-11-22 23:41:51'),
('7','277','0','mozette','4','polosson','9','Polo','','2013-11-22 02:05:37'),
('9','277','7','yeah !!','3','moutew','8','Moutew','','2013-11-22 23:41:11'),
('13','277','0','serser serg segr','4','polosson','9','Polo','','2013-11-26 01:30:07'),
('14','277','0','rytuukr yu,,yru, aerg zrtth h','4','polosson','9','Polo','','2013-11-26 01:30:54'),
('15','277','0','g yu;fy ;fy u,','4','polosson','9','Polo','','2013-11-26 01:31:11'),
('16','277','0','Oooooooowwww yeah !','4','polosson','9','Polo','','2014-02-05 01:35:44');


-- ----------------- TABLE saam_comments_scenes ------------------------

DROP TABLE IF EXISTS `saam_comments_scenes`;

CREATE TABLE `saam_comments_scenes` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `ID_scene` int(9) NOT NULL,
  `ID_project` int(6) NOT NULL,
  `dept` varchar(64) NOT NULL,
  `response_to` int(12) NOT NULL,
  `comment` text NOT NULL,
  `senderId` int(6) NOT NULL,
  `senderLogin` varchar(32) NOT NULL,
  `senderStatus` int(2) NOT NULL,
  `sender` varchar(256) NOT NULL,
  `num_retake` int(3) NOT NULL,
  `read_by` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ID_scene` (`ID_scene`),
  KEY `response_to` (`response_to`),
  KEY `num_retake` (`num_retake`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

INSERT INTO `saam_comments_scenes` VALUES 
('4','1','277','10','0','mess pub 01','4','polosson','9','Polo','1','','2014-01-09 18:27:33'),
('2','1','277','9','0','retest number one','4','polosson','9','Polo','1','','2014-01-09 18:10:49'),
('3','1','277','9','2','reponse number one
zazaaa !!

  ','4','polosson','9','Polo','1','','2014-01-09 18:20:39'),
('5','1','277','10','0','mess pub 02','4','polosson','9','Polo','2','','2014-01-09 18:28:00'),
('6','1','277','9','0','yo, man','4','polosson','9','Polo','2','','2014-01-10 02:29:32'),
('7','1','277','9','6','zer guuut !','4','polosson','9','Polo','2','','2014-01-10 02:30:47'),
('8','1','277','10','0','wouzaaaa test test','4','polosson','9','Polo','2','','2014-01-17 12:45:03'),
('9','1','277','9','0','zawaah
T\'est dailies !!
chôôôô','4','polosson','9','Polo','2','','2014-02-05 01:32:39'),
('10','1','277','9','0','test wazz','4','polosson','9','Polo','3','','2014-02-05 03:11:34'),
('11','1','277','9','10','ouh yeaw','4','polosson','9','Polo','3','','2014-02-05 03:12:06'),
('12','12','277','9','0','wouza !','4','polosson','9','Polo','3','','2014-02-10 14:44:32'),
('13','1','277','9','0','Im an artist','73','artiste','3','Artiste','3','','2014-02-12 12:51:30'),
('14','10','277','9','0','wouzah','73','artiste','3','Artiste','1','','2014-02-12 13:08:22');


-- ----------------- TABLE saam_comments_shots ------------------------

DROP TABLE IF EXISTS `saam_comments_shots`;

CREATE TABLE `saam_comments_shots` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `ID_project` int(6) NOT NULL,
  `ID_shot` int(9) NOT NULL,
  `dept` varchar(64) NOT NULL,
  `response_to` int(12) NOT NULL,
  `comment` text NOT NULL,
  `senderId` int(6) NOT NULL,
  `senderLogin` varchar(32) NOT NULL,
  `senderStatus` int(2) NOT NULL,
  `sender` varchar(256) NOT NULL,
  `num_retake` int(3) NOT NULL,
  `read_by` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ID_shot` (`ID_shot`),
  KEY `response_to` (`response_to`),
  KEY `num_retake` (`num_retake`)
) ENGINE=MyISAM AUTO_INCREMENT=105 DEFAULT CHARSET=utf8;

INSERT INTO `saam_comments_shots` VALUES 
('1','1','1','3','0','Un petit message pour tester l\'affichage et le comportement du system des messages.','4','polosson','9','Polo','2','','2012-08-13 13:25:45'),
('12','1','19','3','0','lol pas d acc Ui add msg','2','vincseize','9','Karlova','2','','2012-08-13 22:26:21'),
('3','1','1','3','1','je te repond vite fait','2','vincseize','9','Karlova','2','','2012-08-13 13:25:45'),
('4','1','1','3','0','avant derniere retake','4','polosson','9','Polo','1','','2012-08-13 13:25:45'),
('5','1','1','3','0','blablablababla','4','polosson','9','Polo','1','','2012-08-13 13:25:45'),
('6','1','1','dectech','0','oooops dectech !','4','polosson','9','Polo','2','','2012-08-13 13:25:45'),
('8','1','1','3','0','test d\'ajout de message

ça maaaarche nickel ! Reste plus qu\'à faire la suppression de message, et... gooood !','4','polosson','9','Polo','2','','2012-08-13 20:06:48'),
('9','1','1','3','8','Euh, non, j’oublie les ACL... ça va être sympa à ce niveau là :P','4','polosson','9','Polo','2','','2012-08-13 20:07:44'),
('13','1','19','3','12','ya, à voir
','4','polosson','9','Polo','2','','2012-08-13 22:26:52'),
('14','1','19','3','0','dekoik ?
 oki','4','polosson','9','Polo','2','','2012-08-13 22:27:49'),
('15','1','19','3','12','lol
','2','vincseize','9','Karlova','2','','2012-08-13 22:28:11'),
('16','1','19','3','12','wazaaaaaaaaaaaa','2','vincseize','9','Karlova','2','','2012-08-13 22:29:49'),
('17','1','3','3','0','bah si , le premier','2','vincseize','9','Karlova','2','','2012-08-14 00:03:10'),
('18','1','1','3','8','clair les ACL, ouh laa, mais ptet moyen de simplifier','2','vincseize','9','Karlova','2','','2012-08-14 10:52:44'),
('19','1','1','3','0','Test d ajout de messages','2','vincseize','9','Karlova','2','','2012-08-14 10:53:35'),
('22','1','19','3','0','test de moa','2','vincseize','9','Karlova','2','','2012-08-15 14:46:08'),
('23','1','19','3','0','owkay blabla','4','polosson','9','Polo','2','','2012-08-15 14:48:00'),
('24','1','19','3','0','wazzzaaaaa :) alors alors alors ?','4','polosson','9','Polo','2','','2012-08-15 14:52:09'),
('25','1','19','3','0','un ptit dernier pour le test','4','polosson','9','Polo','2','','2012-08-15 14:54:33'),
('26','1','19','3','0','Message de Karlova, 5eme','2','vincseize','9','Karlova','2','','2012-08-15 14:55:18'),
('27','1','19','3','0','coucou guilly','2','vincseize','9','Karlova','2','','2012-08-15 17:06:03'),
('29','1','19','3','0','message pour kazzou','2','vincseize','9','Karlova','2','','2012-08-16 10:49:55'),
('30','1','19','3','0','lol, je rajouerais ptet une mini vignette du sender du message ds la barre de menu message
','2','vincseize','9','Karlova','2','','2012-08-18 17:22:09'),
('55','277','808','3','0','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec a diam lectus. Sed sit amet ipsum mauris. Maecenas congue ligula ac quam viverra nec consectetur ante hendrerit.','4','polosson','9','Polo','6','','2013-09-01 17:14:31'),
('52','277','808','3','0','wazzzoy','58','debug','3','debug','5','','2013-07-17 00:40:37'),
('53','277','808','3','52','utkgjhlkg kguikk','4','polosson','9','Polo','5','','2013-07-17 01:18:28'),
('54','277','808','3','52','dtydg hdtgh et gnety rtyntt','58','debug','3','debug','5','[4]','2013-07-17 01:18:47'),
('47','277','855','3','0','héhéhé ça fonctionne direct, c\'est pas beau ça ?','4','polosson','9','Polo','2','','2013-07-12 16:49:40'),
('48','277','856','3','0','hop la','4','polosson','9','Polo','1','','2013-07-12 23:29:52'),
('56','277','808','3','55','Owkay !

Ça roule ! :)','4','polosson','9','Polo','6','','2013-09-01 17:14:44'),
('57','277','808','3','0','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec a diam lectus. Sed sit amet ipsum mauris.','4','polosson','9','Polo','6','','2013-09-01 17:16:01'),
('62','277','808','3','0','Test de commentaire depuis l\'API !','4','polosson','9','Polo','6','','2013-09-23 02:26:58'),
('61','277','855','3','0','Test de commentaire depuis l\'API !','4','polosson','9','Polo','3','','2013-09-23 01:53:03'),
('63','277','808','3','55','wouzaaa','4','polosson','9','Polo','6','','2013-11-13 00:29:16'),
('64','277','808','3','62','gniuk gniuk 1','4','polosson','9','Polo','6','','2013-11-13 00:38:32'),
('65','277','808','3','62','yeah 2','4','polosson','9','Polo','6','','2013-11-13 00:38:38'),
('66','277','808','3','62','bon... hum 3','4','polosson','9','Polo','6','','2013-11-13 00:38:50'),
('67','277','808','3','62','pas au top tout ça... 4','4','polosson','9','Polo','6','','2013-11-13 00:39:04'),
('68','277','808','3','62','réponse au 4... 5 !','4','polosson','9','Polo','6','','2013-11-13 00:39:34'),
('69','277','808','3','55','et donc ?','4','polosson','9','Polo','6','','2013-11-13 00:55:19'),
('72','277','808','storyboard','0','wouza first !','3','moutew','8','Moutew','1','','2013-11-21 23:54:47'),
('71','277','808','3','70','zerzer','4','polosson','9','Polo','6','','2013-11-13 02:13:20'),
('70','277','808','3','0','wouza !','4','polosson','9','Polo','6','','2013-11-13 02:13:11'),
('73','277','808','4','0','test dailies msg','4','polosson','9','Polo','6','','2014-02-03 14:44:13'),
('74','312','989','4','0','Wouzah','4','polosson','9','Polo','2','','2014-02-05 01:22:14'),
('75','312','989','4','0','Un ptit test un peu plus poussé, pour t\'ester les
\"urlDécôdes\" ! YEAH','4','polosson','9','Polo','2','','2014-02-05 01:23:02'),
('76','277','808','4','0','owkay, voyons ce que ça donne','4','polosson','9','Polo','6','','2014-02-05 02:04:15'),
('77','277','808','4','0','encore','4','polosson','9','Polo','6','','2014-02-05 02:05:22'),
('78','277','808','4','0','waza','4','polosson','9','Polo','6','','2014-02-05 02:48:19'),
('79','277','808','4','0','sthzrt zrt zrt','4','polosson','9','Polo','6','','2014-02-05 02:57:22'),
('80','277','808','4','0','drhr','4','polosson','9','Polo','6','','2014-02-05 02:58:03'),
('81','277','808','4','80','gniuk gniuk','4','polosson','9','Polo','6','','2014-02-05 02:59:04'),
('82','277','808','4','80','qeffbqeb','4','polosson','9','Polo','6','','2014-02-05 02:59:39'),
('83','277','808','4','80','rthrth','4','polosson','9','Polo','6','','2014-02-05 03:01:00'),
('84','277','808','4','80','srgbsrb srtbrtb','4','polosson','9','Polo','6','','2014-02-05 03:03:07'),
('85','277','808','4','80','srthzrsth','4','polosson','9','Polo','6','','2014-02-05 03:03:46'),
('86','277','808','4','80','ertyerty','4','polosson','9','Polo','6','','2014-02-05 03:05:12'),
('87','277','808','4','80','nty detnyteyn eyt','4','polosson','9','Polo','6','','2014-02-05 03:06:47'),
('88','277','981','4','0','Kikooo !!','4','polosson','9','Polo','2','','2014-02-05 15:32:44'),
('101','277','982','storyboard','0','Test !','4','polosson','9','Polo','1','','2014-02-10 14:41:38'),
('102','277','982','storyboard','0','test','4','polosson','9','Polo','2','','2014-02-10 14:42:05'),
('91','277','808','4','80','owkay !!','4','polosson','9','Polo','6','','2014-02-05 15:38:51'),
('103','277','982','storyboard','102','ok','4','polosson','9','Polo','2','','2014-02-10 14:42:10'),
('104','277','808','4','0','wouzaahgrll','4','polosson','9','Polo','6','','2014-02-16 17:59:00'),
('93','277','983','4','0','Juste un test en local, pour voir si les my_shots sont respectés !
Désolé pour la pollution de boîte email !

En tout cas, ça va être vachement   joli qu\'avant !
lol
   !','4','polosson','9','Polo','1','','2014-02-05 15:48:36');


-- ----------------- TABLE saam_config ------------------------

DROP TABLE IF EXISTS `saam_config`;

CREATE TABLE `saam_config` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `version` varchar(25) NOT NULL,
  `oldversion` varchar(25) NOT NULL,
  `default_lang` varchar(2) NOT NULL,
  `default_theme` varchar(12) NOT NULL,
  `fps_list` varchar(256) NOT NULL,
  `default_fps` int(3) NOT NULL DEFAULT '25',
  `ratio_list` varchar(256) NOT NULL,
  `date_format` varchar(256) NOT NULL,
  `url_intranet` varchar(1024) NOT NULL,
  `home_max_news` int(11) NOT NULL DEFAULT '4',
  `calendar_file` varchar(256) NOT NULL,
  `default_depts` text NOT NULL,
  `default_project_types` text NOT NULL,
  `default_seqLabel` varchar(128) NOT NULL,
  `default_shotLabel` varchar(128) NOT NULL,
  `default_scenesLabel` varchar(128) NOT NULL,
  `alert_uploads` tinyint(1) NOT NULL DEFAULT '1',
  `alert_retakes` tinyint(1) NOT NULL DEFAULT '1',
  `alert_messages` tinyint(1) NOT NULL DEFAULT '1',
  `global_tags` text NOT NULL,
  `assets_categories` text NOT NULL,
  `default_assets_dirs` text NOT NULL,
  `default_assets_exclude_dirs` text NOT NULL,
  `default_data_folders` text NOT NULL,
  `default_status` varchar(256) NOT NULL,
  `available_softs` text NOT NULL,
  `available_competences` text NOT NULL,
  `user_status` varchar(256) NOT NULL,
  `dectech_infos` text NOT NULL,
  `wip` tinyint(1) NOT NULL DEFAULT '0',
  `dailies_max_weeks` int(3) NOT NULL,
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `version` (`version`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `saam_config` VALUES 
('1','0.1','0.0','fr','dark','16|18|23.97|24|25|30|60|100','25','16:9|4:3','d/m/Y','http://saamanager.net','4','datas/calendar/events.json','[\"layout\"]','[\"demo\",\"short\",\"feature\",\"commercial\",\"effects\",\"game\",\"web\",\"test\"]','seq_##','shot_###','','1','1','1','','{\"1\":\"characters\",\"2\":\"sets\",\"3\":\"props\",\"4\":\"textures\",\"5\":\"matte\"}','[\"characters\",\"props\",\"sets\",\"vehicles\",\"terrains\"]','[\"refs\",\"bank\",\"stills\"]','[\"refs\",\"bank\",\"stills\"]','{\"0\":\"WIP\",\"1\":\"On Hold\",\"2\":\"VALID\"}','[\"blender\",\"Zbrush\",\"AfterEffect\",\"Maya\",\"Ardour\"]','[\"director\",\"scenarist\",\"cameraman\",\"lightTech\",\"soundTech\",\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\",\"soundMix\"]','','{\"action\":{\"1\":[\"Lieu\",\"\"],\"2\":[\"Int-Ext\",\"\"],\"3\":[\"day-night\",\"\"],\"4\":[\"Action\",\"\"]},\"camera\":{\"1\":[\"Valeur_Plan\",\"\"],\"2\":[\"Mvt_Cam\",\"\"],\"3\":[\"Angle\",\"\"],\"4\":[\"Raccord\",\"\"]},\"son\":{\"1\":[\"Son_Amb\",\"\"],\"2\":[\"Dialogue\",\"\"],\"3\":[\"In-Off\",\"\"],\"4\":[\"Musique\",\"\"]}}','0','0'),
('2','0.2','0.1','fr','dark','16|18|23.97|24|25|30|60|100','25','16:9|4:3','d/m/Y','http://saamanager.net','4','datas/calendar/events.json','[\"layout\"]','[\"demo\",\"short\",\"feature\",\"commercial\",\"effects\",\"game\",\"web\",\"test\"]','seq_##','shot_###','','1','1','1','','{\"1\":\"characters\",\"2\":\"sets\",\"3\":\"props\",\"4\":\"textures\",\"5\":\"matte\"}','[\"characters\",\"props\",\"sets\",\"vehicles\",\"terrains\"]','[\"refs\",\"bank\",\"stills\"]','[\"refs\",\"bank\",\"stills\"]','{\"0\":\"WIP\",\"1\":\"On Hold\",\"2\":\"VALID\"}','[\"blender\",\"Zbrush\",\"AfterEffect\",\"Maya\",\"Ardour\"]','[\"director\",\"scenarist\",\"cameraman\",\"lightTech\",\"soundTech\",\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\",\"soundMix\"]','','{\"action\":{\"1\":[\"Lieu\",\"\"],\"2\":[\"Int-Ext\",\"\"],\"3\":[\"day-night\",\"\"],\"4\":[\"Action\",\"\"]},\"camera\":{\"1\":[\"Valeur_Plan\",\"\"],\"2\":[\"Mvt_Cam\",\"\"],\"3\":[\"Angle\",\"\"],\"4\":[\"Raccord\",\"\"]},\"son\":{\"1\":[\"Son_Amb\",\"\"],\"2\":[\"Dialogue\",\"\"],\"3\":[\"In-Off\",\"\"],\"4\":[\"Musique\",\"\"]}}','0','0'),
('3','0.3','0.2','fr','dark','16|18|23.97|24|25|30|60|100','25','16:9|4:3','d/m/Y','http://saamanager.net','4','datas/calendar/events.json','[\"layout\"]','[\"demo\",\"short\",\"feature\",\"commercial\",\"effects\",\"game\",\"web\",\"test\"]','seq_##','shot_###','','1','1','1','','{\"1\":\"characters\",\"2\":\"sets\",\"3\":\"props\",\"4\":\"textures\",\"5\":\"matte\"}','[\"characters\",\"props\",\"sets\",\"vehicles\",\"terrains\"]','[\"refs\",\"bank\",\"stills\"]','[\"refs\",\"bank\",\"stills\"]','{\"0\":\"WIP\",\"1\":\"On Hold\",\"2\":\"VALID\"}','[\"blender\",\"Zbrush\",\"AfterEffect\",\"Maya\",\"Ardour\"]','[\"director\",\"scenarist\",\"cameraman\",\"lightTech\",\"soundTech\",\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\",\"soundMix\"]','','{\"action\":{\"1\":[\"Lieu\",\"\"],\"2\":[\"Int-Ext\",\"\"],\"3\":[\"day-night\",\"\"],\"4\":[\"Action\",\"\"]},\"camera\":{\"1\":[\"Valeur_Plan\",\"\"],\"2\":[\"Mvt_Cam\",\"\"],\"3\":[\"Angle\",\"\"],\"4\":[\"Raccord\",\"\"]},\"son\":{\"1\":[\"Son_Amb\",\"\"],\"2\":[\"Dialogue\",\"\"],\"3\":[\"In-Off\",\"\"],\"4\":[\"Musique\",\"\"]}}','0','0'),
('4','0.4','0.3','fr','dark','16|18|23.97|24|25|30|60|100','25','16:9|4:3','d/m/Y','http://saamanager.net','4','datas/calendar/events.json','[\"layout\"]','[\"demo\",\"short\",\"feature\",\"commercial\",\"effects\",\"game\",\"web\",\"test\"]','seq_##','shot_###','','1','1','1','','{\"1\":\"characters\",\"2\":\"sets\",\"3\":\"props\",\"4\":\"textures\",\"5\":\"matte\"}','[\"characters\",\"props\",\"sets\",\"vehicles\",\"terrains\"]','[\"refs\",\"bank\",\"stills\"]','[\"refs\",\"bank\",\"stills\"]','{\"0\":\"WIP\",\"1\":\"On Hold\",\"2\":\"VALID\"}','[\"blender\",\"Zbrush\",\"AfterEffect\",\"Maya\",\"Ardour\"]','[\"director\",\"scenarist\",\"cameraman\",\"lightTech\",\"soundTech\",\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\",\"soundMix\"]','','{\"action\":{\"1\":[\"Lieu\",\"\"],\"2\":[\"Int-Ext\",\"\"],\"3\":[\"day-night\",\"\"],\"4\":[\"Action\",\"\"]},\"camera\":{\"1\":[\"Valeur_Plan\",\"\"],\"2\":[\"Mvt_Cam\",\"\"],\"3\":[\"Angle\",\"\"],\"4\":[\"Raccord\",\"\"]},\"son\":{\"1\":[\"Son_Amb\",\"\"],\"2\":[\"Dialogue\",\"\"],\"3\":[\"In-Off\",\"\"],\"4\":[\"Musique\",\"\"]}}','0','0'),
('5','0.41','0.4','fr','dark','16|18|23.97|24|25|30|60|100','25','16:9|4:3','d/m/Y','http://saamanager.net','4','datas/calendar/events.json','[\"layout\"]','[\"demo\",\"short\",\"feature\",\"commercial\",\"effects\",\"game\",\"web\",\"test\"]','seq_##','shot_###','','1','1','1','','{\"1\":\"characters\",\"2\":\"sets\",\"3\":\"props\",\"4\":\"textures\",\"5\":\"matte\"}','[\"characters\",\"props\",\"sets\",\"vehicles\",\"terrains\"]','[\"refs\",\"bank\",\"stills\"]','[\"refs\",\"bank\",\"stills\"]','{\"0\":\"WIP\",\"1\":\"On Hold\",\"2\":\"VALID\"}','[\"blender\",\"Zbrush\",\"AfterEffect\",\"Maya\",\"Ardour\"]','[\"director\",\"scenarist\",\"cameraman\",\"lightTech\",\"soundTech\",\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\",\"soundMix\"]','','{\"action\":{\"1\":[\"Lieu\",\"\"],\"2\":[\"Int-Ext\",\"\"],\"3\":[\"day-night\",\"\"],\"4\":[\"Action\",\"\"]},\"camera\":{\"1\":[\"Valeur_Plan\",\"\"],\"2\":[\"Mvt_Cam\",\"\"],\"3\":[\"Angle\",\"\"],\"4\":[\"Raccord\",\"\"]},\"son\":{\"1\":[\"Son_Amb\",\"\"],\"2\":[\"Dialogue\",\"\"],\"3\":[\"In-Off\",\"\"],\"4\":[\"Musique\",\"\"]}}','0','0'),
('6','0.45','0.41','fr','dark','16|18|23.97|24|25|30|60|100','25','16:9|4:3','d/m/Y','http://saamanager.net','4','datas/calendar/events.json','[\"layout\"]','[\"demo\",\"short\",\"feature\",\"commercial\",\"effects\",\"game\",\"web\",\"test\"]','seq_##','shot_###','','1','1','1','[\"Need review\",\"Stable\"]','{\"1\":\"characters\",\"2\":\"sets\",\"3\":\"props\",\"4\":\"textures\",\"5\":\"matte\"}','[\"characters\",\"props\",\"sets\",\"vehicles\",\"terrains\"]','[\"refs\",\"bank\",\"stills\"]','[\"refs\",\"bank\",\"stills\"]','{\"0\":\"WIP\",\"1\":\"On Hold\",\"2\":\"VALID\"}','[\"blender\",\"Zbrush\",\"AfterEffect\",\"Maya\",\"Ardour\"]','[\"director\",\"scenarist\",\"cameraman\",\"lightTech\",\"soundTech\",\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\",\"soundMix\"]','','{\"action\":{\"1\":[\"Lieu\",\"\"],\"2\":[\"Int-Ext\",\"\"],\"3\":[\"day-night\",\"\"],\"4\":[\"Action\",\"\"]},\"camera\":{\"1\":[\"Valeur_Plan\",\"\"],\"2\":[\"Mvt_Cam\",\"\"],\"3\":[\"Angle\",\"\"],\"4\":[\"Raccord\",\"\"]},\"son\":{\"1\":[\"Son_Amb\",\"\"],\"2\":[\"Dialogue\",\"\"],\"3\":[\"In-Off\",\"\"],\"4\":[\"Musique\",\"\"]}}','0','0'),
('7','0.5','0.45','fr','dark','16|18|23.97|24|25|30|60|100','25','16:9|4:3','d/m/Y','http://saamanager.net','4','datas/calendar/events.json','[\"layout\"]','[\"demo\",\"short\",\"feature\",\"commercial\",\"effects\",\"game\",\"web\",\"test\"]','seq_##','shot_###','','1','1','1','[\"Need review\",\"Stable\"]','{\"1\":\"characters\",\"2\":\"sets\",\"3\":\"props\",\"4\":\"textures\",\"5\":\"matte\"}','[\"characters\",\"props\",\"sets\",\"vehicles\",\"terrains\"]','[\"refs\",\"bank\",\"stills\"]','[\"refs\",\"bank\",\"stills\"]','{\"0\":\"WIP\",\"1\":\"On Hold\",\"2\":\"VALID\"}','[\"blender\",\"Zbrush\",\"AfterEffect\",\"Maya\",\"Ardour\"]','[\"director\",\"scenarist\",\"cameraman\",\"lightTech\",\"soundTech\",\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\",\"soundMix\"]','','{\"action\":{\"1\":[\"Lieu\",\"\"],\"2\":[\"Int-Ext\",\"\"],\"3\":[\"day-night\",\"\"],\"4\":[\"Action\",\"\"]},\"camera\":{\"1\":[\"Valeur_Plan\",\"\"],\"2\":[\"Mvt_Cam\",\"\"],\"3\":[\"Angle\",\"\"],\"4\":[\"Raccord\",\"\"]},\"son\":{\"1\":[\"Son_Amb\",\"\"],\"2\":[\"Dialogue\",\"\"],\"3\":[\"In-Off\",\"\"],\"4\":[\"Musique\",\"\"]}}','0','0'),
('8','0.6','0.5','fr','dark','16|18|23.97|24|25|30|60|100','25','16:9|4:3','d/m/Y','http://saamanager.net','4','datas/calendar/events.json','[\"1\",\"8\"]','[\"demo\",\"short\",\"feature\",\"commercial\",\"effects\",\"game\",\"web\",\"test\"]','SEQ','SHOT','','1','1','1','[\"Need review\",\"Stable\"]','{\"1\":\"characters\",\"2\":\"sets\",\"3\":\"props\",\"4\":\"textures\",\"5\":\"matte\"}','[\"characters\",\"props\",\"sets\",\"vehicles\",\"terrains\"]','[\"refs\",\"bank\",\"stills\"]','[\"refs\",\"bank\",\"stills\"]','{\"0\":\"WIP\",\"1\":\"On Hold\",\"2\":\"VALID\"}','[\"blender\",\"Zbrush\",\"AfterEffect\",\"Maya\",\"Ardour\"]','[\"producer\",\"assistantProd\",\"director\",\"scenarist\",\"cameraman\",\"lightTech\",\"soundTech\",\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\",\"soundMix\"]','','{\"action\":{\"1\":[\"Lieu\",\"\"],\"2\":[\"Int-Ext\",\"\"],\"3\":[\"day-night\",\"\"],\"4\":[\"Action\",\"\"]},\"camera\":{\"1\":[\"Valeur_Plan\",\"\"],\"2\":[\"Mvt_Cam\",\"\"],\"3\":[\"Angle\",\"\"],\"4\":[\"Raccord\",\"\"]},\"son\":{\"1\":[\"Son_Amb\",\"\"],\"2\":[\"Dialogue\",\"\"],\"3\":[\"In-Off\",\"\"],\"4\":[\"Musique\",\"\"]}}','0','8'),
('9','0.7','0.6','fr','dark','16|18|23.97|24|25|30|60|100','25','16:9|4:3','d/m/Y','http://saamanager.net','4','datas/calendar/events.json','[\"1\",\"8\"]','[\"demo\",\"short\",\"feature\",\"commercial\",\"effects\",\"game\",\"web\",\"test\"]','SEQ','SHOT','','1','1','1','[\"Need review\",\"Stable\"]','{\"1\":\"characters\",\"2\":\"sets\",\"3\":\"props\",\"4\":\"textures\",\"5\":\"matte\"}','[\"characters\",\"props\",\"sets\",\"vehicles\",\"terrains\"]','[\"refs\",\"bank\",\"stills\"]','[\"refs\",\"bank\",\"stills\"]','[\"--\",\"WIP\",\"OnHold\",\"VALID\",\"Disabled\"]','[\"blender\",\"Zbrush\",\"AfterEffect\",\"Maya\",\"Ardour\"]','[\"producer\",\"assistantProd\",\"director\",\"scenarist\",\"cameraman\",\"lightTech\",\"soundTech\",\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\",\"soundMix\"]','{\"1\":\"visitor\",\"2\":\"demo\",\"3\":\"artist\",\"4\":\"lead\",\"5\":\"supervisor\",\"6\":\"prod.dir.\",\"7\":\"magic\",\"8\":\"dev\",\"9\":\"root\"}','{\"action\":{\"1\":[\"Lieu\",\"\"],\"2\":[\"Int-Ext\",\"\"],\"3\":[\"day-night\",\"\"],\"4\":[\"Action\",\"\"]},\"camera\":{\"1\":[\"Valeur_Plan\",\"\"],\"2\":[\"Mvt_Cam\",\"\"],\"3\":[\"Angle\",\"\"],\"4\":[\"Raccord\",\"\"]},\"son\":{\"1\":[\"Son_Amb\",\"\"],\"2\":[\"Dialogue\",\"\"],\"3\":[\"In-Off\",\"\"],\"4\":[\"Musique\",\"\"]}}','0','8'),
('10','0.8','0.7','fr','dark','16|18|23.97|24|25|30|60|100','25','16:9|4:3','d/m/Y','http://saamanager.net','4','datas/calendar/events.json','[\"1\",\"8\"]','[\"demo\",\"short\",\"feature\",\"commercial\",\"effects\",\"game\",\"web\",\"test\"]','SEQ','SHOT','','1','1','1','[\"Need review\",\"Stable\"]','{\"1\":\"characters\",\"2\":\"sets\",\"3\":\"props\",\"4\":\"textures\",\"5\":\"matte\"}','[\"characters\",\"props\",\"sets\",\"vehicles\",\"terrains\"]','[\"refs\",\"bank\",\"stills\"]','[\"refs\",\"bank\",\"stills\"]','[\"--\",\"WIP\",\"OnHold\",\"VALID\",\"Disabled\"]','[\"blender\",\"Zbrush\",\"AfterEffect\",\"Maya\",\"Ardour\"]','[\"producer\",\"assistantProd\",\"director\",\"scenarist\",\"cameraman\",\"lightTech\",\"soundTech\",\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\",\"soundMix\"]','{\"1\":\"visitor\",\"2\":\"demo\",\"3\":\"artist\",\"4\":\"lead\",\"5\":\"supervisor\",\"6\":\"prod.dir.\",\"7\":\"magic\",\"8\":\"dev\",\"9\":\"root\"}','{\"action\":{\"1\":[\"Lieu\",\"\"],\"2\":[\"Int-Ext\",\"\"],\"3\":[\"day-night\",\"\"],\"4\":[\"Action\",\"\"]},\"camera\":{\"1\":[\"Valeur_Plan\",\"\"],\"2\":[\"Mvt_Cam\",\"\"],\"3\":[\"Angle\",\"\"],\"4\":[\"Raccord\",\"\"]},\"son\":{\"1\":[\"Son_Amb\",\"\"],\"2\":[\"Dialogue\",\"\"],\"3\":[\"In-Off\",\"\"],\"4\":[\"Musique\",\"\"]}}','0','8'),
('11','0.9','0.8','fr','dark','16|18|23.97|24|25|30|60|100','25','16:9|4:3','d/m/Y','http://saamanager.net','4','datas/calendar/events.json','[\"1\",\"9\",\"12\"]','[\"demo\",\"short\",\"feature\",\"commercial\",\"effects\",\"game\",\"web\",\"test\"]','SEQ','SHOT','M_SC','1','1','1','[\"Need review\",\"Stable\"]','{\"1\":\"characters\",\"2\":\"sets\",\"3\":\"props\",\"4\":\"textures\",\"5\":\"matte\"}','[\"characters\",\"props\",\"sets\",\"vehicles\",\"terrains\"]','[\"refs\",\"bank\",\"stills\"]','[\"refs\",\"bank\",\"stills\"]','[\"--\",\"WIP\",\"OnHold\",\"VALID\",\"Disabled\"]','[\"blender\",\"Zbrush\",\"AfterEffect\",\"Maya\",\"Ardour\"]','[\"producer\",\"assistantProd\",\"director\",\"scenarist\",\"cameraman\",\"lightTech\",\"soundTech\",\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\",\"soundMix\"]','{\"1\":\"visitor\",\"2\":\"demo\",\"3\":\"artist\",\"4\":\"lead\",\"5\":\"supervisor\",\"6\":\"prod.dir.\",\"7\":\"magic\",\"8\":\"dev\",\"9\":\"root\"}','{\"action\":{\"1\":[\"Lieu\",\"\"],\"2\":[\"Int-Ext\",\"\"],\"3\":[\"day-night\",\"\"],\"4\":[\"Action\",\"\"]},\"camera\":{\"1\":[\"Valeur_Plan\",\"\"],\"2\":[\"Mvt_Cam\",\"\"],\"3\":[\"Angle\",\"\"],\"4\":[\"Raccord\",\"\"]},\"son\":{\"1\":[\"Son_Amb\",\"\"],\"2\":[\"Dialogue\",\"\"],\"3\":[\"In-Off\",\"\"],\"4\":[\"Musique\",\"\"]}}','0','8'),
('12','0.99','0.9','fr','dark','16|18|23.97|24|25|30|60|100','25','16:9|4:3','d/m/Y','http://saamanager.net','4','datas/calendar/events.json','[\"1\",\"9\",\"12\"]','[\"demo\",\"short\",\"feature\",\"commercial\",\"effects\",\"game\",\"web\",\"test\"]','SEQ','SHOT','M_SC','1','1','1','[\"Need review\",\"Stable\"]','{\"1\":\"characters\",\"2\":\"sets\",\"3\":\"props\",\"4\":\"textures\",\"5\":\"matte\"}','[\"characters\",\"props\",\"sets\",\"vehicles\",\"terrains\"]','[\"refs\",\"bank\",\"stills\"]','[\"refs\",\"bank\",\"stills\"]','[\"--\",\"WIP\",\"OnHold\",\"VALID\",\"Disabled\"]','[\"blender\",\"Zbrush\",\"AfterEffect\",\"Maya\",\"Ardour\"]','[\"producer\",\"assistantProd\",\"director\",\"scenarist\",\"cameraman\",\"lightTech\",\"soundTech\",\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\",\"soundMix\"]','{\"1\":\"visitor\",\"2\":\"demo\",\"3\":\"artist\",\"4\":\"lead\",\"5\":\"supervisor\",\"6\":\"prod.dir.\",\"7\":\"magic\",\"8\":\"dev\",\"9\":\"root\"}','{\"action\":{\"1\":[\"Lieu\",\"\"],\"2\":[\"Int-Ext\",\"\"],\"3\":[\"day-night\",\"\"],\"4\":[\"Action\",\"\"]},\"camera\":{\"1\":[\"Valeur_Plan\",\"\"],\"2\":[\"Mvt_Cam\",\"\"],\"3\":[\"Angle\",\"\"],\"4\":[\"Raccord\",\"\"]},\"son\":{\"1\":[\"Son_Amb\",\"\"],\"2\":[\"Dialogue\",\"\"],\"3\":[\"In-Off\",\"\"],\"4\":[\"Musique\",\"\"]}}','0','8');


-- ----------------- TABLE saam_dailies ------------------------

DROP TABLE IF EXISTS `saam_dailies`;

CREATE TABLE `saam_dailies` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `ID_project` int(4) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user` int(4) NOT NULL,
  `groupe` varchar(32) NOT NULL,
  `type` varchar(32) NOT NULL,
  `corresp` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ID_project` (`ID_project`),
  KEY `date` (`date`)
) ENGINE=InnoDB AUTO_INCREMENT=309 DEFAULT CHARSET=utf8;

INSERT INTO `saam_dailies` VALUES 
('1','277','2013-06-07 11:35:05','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anim\",\"txtMess\":\"wazzza, vla pour le premier dailies\"}'),
('2','277','2013-06-14 16:48:42','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anim\",\"txtMess\":\"et, another one to bite the dust\"}'),
('3','277','2013-06-21 16:49:13','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"855\",\"dept\":\"anim\"}'),
('4','277','2013-06-28 16:49:40','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"855\",\"dept\":\"anim\",\"txtMess\":\"héhéhé ça fonctionne direct, c\'est pas beau ça ?\"}'),
('5','277','2013-07-05 16:49:46','4','SHOT','SHOT_VALID_PUBLISHED','{\"idShot\":\"855\",\"dept\":\"anim\"}'),
('6','277','2013-07-01 16:50:07','4','SHOT','SHOT_BANK_UPLOAD','{\"idShot\":\"808\",\"dept\":\"anim\",\"nbF\":\"1\",\"folder\":\"bank\"}'),
('7','277','2013-07-02 16:50:51','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\"}'),
('8','277','2013-07-03 16:51:27','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"hop la, vla pour les assets, un ptit message ?\"}'),
('9','277','2013-07-04 16:51:37','4','ASSET','ASSET_HANDLED','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"idNewHandler\":\"4\"}'),
('10','277','2013-07-12 16:51:47','4','ASSET','ASSET_HANDLED','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"idNewHandler\":\"0\"}'),
('11','277','2013-07-12 16:52:22','4','ASSET','ASSET_BANK_UPLOAD','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"nbF\":\"1\",\"folder\":\"bank\"}'),
('12','277','2013-07-12 16:52:59','4','ASSET','ASSET_NEW_PUBLISHED','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\"}'),
('13','277','2013-07-12 16:53:37','4','ASSET','ASSET_VALID_PUBLISHED','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\"}'),
('14','277','2013-07-12 16:54:08','4','ROOT','BLOCKANIM_NEW_MESSAGE','owkay, just a test'),
('15','277','2013-07-12 23:29:52','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"856\",\"dept\":\"anims\",\"txtMess\":\"hop la\"}'),
('16','277','2013-07-12 23:31:10','4','ASSET','ASSET_NEW_PUBLISHED','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\"}'),
('17','277','2013-07-14 02:23:29','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"fghjdghjdghj\"}'),
('18','277','2013-07-14 02:23:40','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"vhjkfghjfghj\"}'),
('19','277','2013-07-14 18:19:43','4','ASSET','ASSET_MOD_PUBLISHED','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\"}'),
('20','277','2013-07-14 18:31:36','4','ASSET','ASSET_MOD_PUBLISHED','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\"}'),
('21','277','2013-07-14 20:09:45','4','ASSET','ASSET_NEW_PUBLISHED','{\"pathAsset\":\"props/casque_pompier/\",\"nameAsset\":\"casque_pompier.blend\"}'),
('22','277','2013-07-14 20:09:55','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"props/casque_pompier/\",\"nameAsset\":\"casque_pompier.blend\",\"txtMess\":\"zawaaaaa\"}'),
('23','277','2013-07-14 20:10:48','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"props/casque_pompier/\",\"nameAsset\":\"casque_pompier.blend\",\"txtMess\":\"Cool... En tout cas te prends pas trop le choux, dans le sens ou ce sont des assets mineurs... Bienvenue dans léquipe Azuk !\"}'),
('24','277','2013-07-14 20:17:38','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"props/casque_pompier/\",\"nameAsset\":\"casque_pompier.blend\",\"txtMess\":\"Voyons+voir+ce+que+%C3%A7a+donne+avec+un+petit+urlencode+%3F%0AHop+j%27ai+saut%C3%A9+une+ligne+%21%21%0A%0A%22attention%22+les+v%C3%A9los+nom+d%27%27unchien%27%27%0A%5E%5E%0A%3AD%0A%0A\"}'),
('25','277','2013-07-15 13:44:22','4','ASSET','ASSET_VALID_PUBLISHED','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\"}'),
('26','277','2013-07-15 13:44:52','4','ASSET','ASSET_NEW_PUBLISHED','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\"}'),
('27','277','2013-07-17 00:07:05','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"okay\"}'),
('28','277','2013-07-17 00:40:37','58','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"wazzzoy\"}'),
('29','277','2013-07-17 00:47:37','58','SHOT','SHOT_MOD_PUBLISHED','{\"idShot\":\"808\",\"dept\":\"anims\"}'),
('30','277','2013-07-17 01:18:28','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"utkgjhlkg+kguikk\"}'),
('31','277','2013-07-17 01:18:47','58','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"dtydg+hdtgh+et+gnety+rtyntt\"}'),
('32','277','2013-07-17 01:20:45','58','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"raaaazaaaaalgul\"}'),
('33','277','2013-07-17 11:47:02','58','SHOT','SHOT_BANK_UPLOAD','{\"idShot\":\"855\",\"dept\":\"anims\",\"nbF\":\"1\",\"folder\":\"stills\"}'),
('34','277','2013-07-17 11:48:25','58','SHOT','SHOT_BANK_UPLOAD','{\"idShot\":\"855\",\"dept\":\"anims\",\"nbF\":\"1\",\"folder\":\"stills\"}'),
('35','277','2013-07-17 14:31:41','58','SHOT','SHOT_BANK_UPLOAD','{\"idShot\":\"808\",\"dept\":\"anims\",\"nbF\":\"1\",\"folder\":\"mon triip\"}'),
('36','277','2013-07-17 15:02:11','4','SHOT','SHOT_BANK_UPLOAD','{\"idShot\":\"910\",\"dept\":\"storyboard\",\"nbF\":\"1\",\"folder\":\"stills\"}'),
('37','277','2013-07-17 23:29:02','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"ertyert+erth+erth\"}'),
('38','277','2013-07-17 23:31:52','58','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"ergzerg+zerrv\"}'),
('39','277','2013-07-17 23:39:18','58','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"owkay%2C+1er+message\"}'),
('40','277','2013-07-17 23:39:29','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"r%C3%A9ponse+nom+d%27un+chien\"}'),
('41','277','2013-07-17 23:39:43','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"r%C3%A9ponse+nom+d%27un+chien\"}'),
('42','277','2013-07-17 23:44:54','58','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"h%C3%A9h%C3%A9h%C3%A9\"}'),
('43','277','2013-07-17 23:45:12','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"voila+qui+est+interresting+%3A%29\"}'),
('44','277','2013-07-17 23:53:26','58','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"jme+r%C3%A9pond\"}'),
('45','277','2013-07-17 23:53:40','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"je+te+r%C3%A9pond\"}'),
('46','277','2013-07-17 23:53:51','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"jme+r%C3%A9pond+%C3%A0+moi\"}'),
('47','277','2013-07-17 23:54:58','58','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"owkay\"}'),
('48','277','2013-07-18 00:58:37','4','ASSET','ASSET_VALID_PUBLISHED','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\"}'),
('49','277','2013-07-18 11:14:12','4','ASSET','ASSET_HANDLED','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"idNewHandler\":\"58\"}'),
('50','277','2013-07-18 11:38:06','58','ASSET','ASSET_NEW_PUBLISHED','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\"}'),
('51','277','2013-07-18 13:02:47','58','ASSET','ASSET_HANDLED','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"idNewHandler\":\"0\"}'),
('52','277','2013-07-23 12:33:33','4','ASSET','ASSET_BANK_UPLOAD','{\"pathAsset\":\"./characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"nbF\":\"1\",\"folder\":\"wip\"}'),
('53','277','2013-07-23 12:33:55','58','ASSET','ASSET_BANK_UPLOAD','{\"pathAsset\":\"./characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"nbF\":\"1\",\"folder\":\"wip\"}'),
('54','277','2013-07-24 17:25:00','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"zdfgz+feg+zrfb+zrbzrtb+gf\"}'),
('55','277','2013-07-27 23:07:36','4','ASSET','ASSET_VALID_PUBLISHED','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\"}'),
('56','277','2013-07-27 23:10:11','4','ASSET','ASSET_VALID_PUBLISHED','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\"}'),
('57','277','2013-07-27 23:18:31','4','ASSET','ASSET_VALID_PUBLISHED','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\"}'),
('58','277','2013-08-30 01:28:59','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"964\",\"dept\":\"storyboard\"}'),
('59','277','2013-08-30 01:29:35','4','SHOT','SHOT_MOD_PUBLISHED','{\"idShot\":\"964\",\"dept\":\"storyboard\"}'),
('60','277','2013-08-31 02:08:38','4','ASSET','ASSET_NEW_PUBLISHED','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\"}'),
('61','277','2013-08-31 02:09:11','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"txtMess\":\"En+voila+une+belle+Lune+%21%21+Un+peu+stretch%C3%A9e+mais+%C3%A7a+va...\"}'),
('62','277','2013-08-31 02:09:34','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"txtMess\":\"Non%2C+elle+est+stretch%C3%A9e+parce+que+l%27image+n%27est+pas+au+format+du+film.\"}'),
('63','277','2013-08-31 02:09:43','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"txtMess\":\"Ah%2C+ok+je+vois\"}'),
('64','277','2013-08-31 02:10:11','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"txtMess\":\"Lorem+ipsum+dolor+sit+amet%2C+consectetur+adipiscing+elit.+Donec+a+diam+lectus.+Sed+sit+amet+ipsum+mauris.+Maecenas+congue+ligula+ac+quam+viverra+nec+consectetur+ante+hendrerit.+Donec+et+mollis+dolor.+Praesent+et+diam+eget+libero+egestas+mattis+sit+amet+vitae+augue.+Nam+tincidunt+congue+enim%2C+ut+porta+lorem+lacinia+consectetur.+Donec+ut+libero+sed+arcu+vehicula+ultricies+a+non+tortor.+Lorem+ipsum+dolor+sit+amet%2C+consectetur+adipiscing+elit\"}'),
('65','277','2013-08-31 02:10:18','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"txtMess\":\"okok\"}'),
('66','277','2013-09-01 17:11:31','4','SHOT','SHOT_VALID_PUBLISHED','{\"idShot\":\"808\",\"dept\":\"anims\"}'),
('67','277','2013-09-01 17:13:07','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"808\",\"dept\":\"anims\"}'),
('68','277','2013-09-01 17:14:31','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"Lorem+ipsum+dolor+sit+amet%2C+consectetur+adipiscing+elit.+Donec+a+diam+lectus.+Sed+sit+amet+ipsum+mauris.+Maecenas+congue+ligula+ac+quam+viverra+nec+consectetur+ante+hendrerit.\"}'),
('69','277','2013-09-01 17:14:44','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"Owkay+%21%0A%0A%C3%87a+roule+%21+%3A%29\"}'),
('70','277','2013-09-01 17:16:01','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"Lorem+ipsum+dolor+sit+amet%2C+consectetur+adipiscing+elit.+Donec+a+diam+lectus.+Sed+sit+amet+ipsum+mauris.\"}'),
('71','277','2013-09-04 19:16:16','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"yeah\"}'),
('72','277','2013-09-04 19:18:01','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"et+l%C3%A0+%3F+C+good+%3F\"}'),
('73','277','2013-09-04 19:18:15','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"c%27est+goooood+%21%21\"}'),
('74','277','2013-09-04 19:18:41','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"owkay%2C+pourquoi+pas%2C+mais+c%27est+le+dernier+%21%0Alol\"}'),
('75','277','2013-09-04 19:20:15','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"dfghdfhdfgh+dfgghh+dfgh\"}'),
('77','277','2013-09-06 02:52:45','4','ASSET','ASSET_NEW_PUBLISHED','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\"}'),
('78','277','2013-09-06 02:53:09','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"rhoooo%0Amagnifique\"}'),
('79','277','2013-09-06 02:56:43','4','ASSET','ASSET_MOD_PUBLISHED','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\"}'),
('80','277','2013-09-06 03:15:03','4','ASSET','ASSET_MOD_PUBLISHED','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"deptID\":\"9\"}'),
('81','277','2013-09-06 03:15:35','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"deptID\":\"9\",\"txtMess\":\"sfgsfgb+sfdb+sfdbsfdsfgb\"}'),
('88','277','2013-09-06 16:50:30','4','ASSET','ASSET_BANK_UPLOAD','{\"pathAsset\":\"./characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"deptID\":\"8\",\"nbF\":\"1\",\"folder\":\"bank\"}'),
('89','277','2013-09-06 16:58:38','4','ASSET','ASSET_BANK_UPLOAD','{\"pathAsset\":\"./characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"deptID\":\"8\",\"nbF\":\"1\",\"folder\":\"bank\"}'),
('90','277','2013-09-06 16:59:29','4','ASSET','ASSET_BANK_UPLOAD','{\"pathAsset\":\"./characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"deptID\":\"8\",\"nbF\":\"1\",\"folder\":\"bank\"}'),
('91','277','2013-09-06 16:59:56','4','ASSET','ASSET_BANK_UPLOAD','{\"pathAsset\":\"./characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"deptID\":\"8\",\"nbF\":\"1\",\"folder\":\"bank\"}'),
('92','277','2013-09-06 17:01:44','4','ASSET','ASSET_BANK_UPLOAD','{\"pathAsset\":\"./characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"deptID\":\"8\",\"nbF\":\"1\",\"folder\":\"bank\"}'),
('93','277','2013-09-06 17:25:37','4','ASSET','ASSET_NEW_PUBLISHED','{\"pathAsset\":\"sets/bedroom/\",\"nameAsset\":\"Marcel-Bedroom.blend\",\"deptID\":\"8\"}'),
('94','277','2013-09-06 17:27:04','4','ASSET','ASSET_NEW_PUBLISHED','{\"pathAsset\":\"sets/bedroom/\",\"nameAsset\":\"Marcel-Bedroom.blend\",\"deptID\":\"9\"}'),
('95','277','2013-09-07 01:53:17','4','ASSET','ASSET_VALID_PUBLISHED','{\"pathAsset\":\"sets/bedroom/\",\"nameAsset\":\"Marcel-Bedroom.blend\",\"deptID\":\"9\"}'),
('102','277','2013-09-18 23:21:53','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"test+add+message+new+button\"}'),
('103','277','2013-09-18 23:22:19','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"855\",\"dept\":\"anims\"}'),
('104','277','2013-09-18 23:22:36','4','SHOT','SHOT_MOD_PUBLISHED','{\"idShot\":\"855\",\"dept\":\"anims\"}'),
('105','277','2013-09-20 13:52:02','4','ROOT','SCENARIO_UPDATE','{\"idProject\":\"277\"}'),
('106','277','2013-09-20 13:54:30','4','ROOT','SCENARIO_UPDATE','{\"idProject\":\"277\"}'),
('107','277','2013-09-20 13:56:20','4','ROOT','SCENARIO_UPDATE','{\"idProject\":\"277\"}'),
('108','277','2013-09-23 01:47:08','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"Test+de+commentaire+depuis+l%27API+%21\"}'),
('109','277','2013-09-23 01:47:44','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"VFX\",\"txtMess\":\"Test+de+commentaire+depuis+l%27API+%21\"}'),
('110','277','2013-09-23 01:53:03','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"855\",\"dept\":\"anims\",\"txtMess\":\"Test+de+commentaire+depuis+l%27API+%21\"}'),
('111','277','2013-09-23 01:53:09','4','SHOT','SHOT_VALID_PUBLISHED','{\"idShot\":\"855\",\"dept\":\"anims\"}'),
('112','277','2013-09-23 02:19:45','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"9\",\"txtMess\":\"Test+de+commentaire+depuis+l%27API+%21\"}'),
('113','277','2013-09-23 02:20:42','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"deptID\":\"8\",\"txtMess\":\"Test+de+commentaire+depuis+l%27API+%21\"}'),
('114','277','2013-09-23 02:26:58','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"Test+de+commentaire+depuis+l%27API+%21\"}'),
('115','277','2013-09-23 18:56:27','4','ASSET','ASSET_REVIEW_REQUEST','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"comment\":\"Test de demande de review depuis l\'API !\"}'),
('116','277','2013-09-23 19:01:07','4','ASSET','ASSET_REVIEW_VALID','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\"}'),
('117','277','2013-09-23 19:02:08','4','ASSET','ASSET_REVIEW_REQUEST','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"comment\":\"Test de demande de review depuis l\'API !\"}'),
('118','277','2013-09-23 19:03:40','4','ASSET','ASSET_REVIEW_REQUEST','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"comment\":\"Test de demande de review depuis l\'API !\"}'),
('119','277','2013-09-23 19:06:52','4','ASSET','ASSET_REVIEW_VALID','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\"}'),
('120','277','2013-09-23 19:07:24','4','ASSET','ASSET_REVIEW_VALID','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\"}'),
('121','277','2013-09-23 19:09:31','4','ASSET','ASSET_REVIEW_REQUEST','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"comment\":\"Test de demande de review depuis l\'API !\"}'),
('122','277','2013-09-23 19:18:27','4','ASSET','ASSET_REVIEW_VALID','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\"}'),
('123','277','2013-10-03 16:36:25','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"deptID\":\"9\",\"txtMess\":\"waz+az+%21%21\"}'),
('124','277','2013-10-07 20:42:41','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"981\",\"dept\":\"anims\"}'),
('125','277','2013-11-13 00:29:16','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"wouzaaa\"}'),
('126','277','2013-11-13 00:38:32','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"gniuk+gniuk+1\"}'),
('127','277','2013-11-13 00:38:38','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"yeah+2\"}'),
('128','277','2013-11-13 00:38:50','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"bon...+hum+3\"}'),
('129','277','2013-11-13 00:39:04','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"pas+au+top+tout+%C3%A7a...+4\"}'),
('130','277','2013-11-13 00:39:34','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"r%C3%A9ponse+au+4...+5+%21\"}'),
('131','277','2013-11-13 00:55:19','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"et+donc+%3F\"}'),
('132','277','2013-11-13 01:03:09','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"deptID\":\"9\",\"txtMess\":\"yo+1\"}'),
('133','277','2013-11-13 01:03:14','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"deptID\":\"9\",\"txtMess\":\"yo+2\"}'),
('134','277','2013-11-13 01:03:22','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"deptID\":\"9\",\"txtMess\":\"yo+3\"}'),
('135','277','2013-11-13 01:03:50','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"deptID\":\"9\",\"txtMess\":\"mouagahahaha\"}'),
('136','277','2013-11-13 01:04:01','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"deptID\":\"9\",\"txtMess\":\"t%27en+veux+%3F\"}'),
('137','277','2013-11-13 01:04:07','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"deptID\":\"9\",\"txtMess\":\"oh+oui+%21\"}'),
('138','277','2013-11-13 01:04:20','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"deptID\":\"9\",\"txtMess\":\"et+pis+moi+%21\"}'),
('139','277','2013-11-13 01:05:12','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"deptID\":\"9\",\"txtMess\":\"wouzaa\"}'),
('140','277','2013-11-13 01:05:31','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"deptID\":\"9\",\"txtMess\":\"yo+4\"}'),
('141','277','2013-11-13 01:05:40','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"deptID\":\"9\",\"txtMess\":\"yo+da+%21\"}'),
('142','277','2013-11-13 01:20:16','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"deptID\":\"9\",\"txtMess\":\"burped+code\"}'),
('143','277','2013-11-13 02:13:11','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"wouza+%21\"}'),
('144','277','2013-11-13 02:13:20','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"zerzer\"}'),
('145','277','2013-11-20 22:29:03','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"6\"}'),
('146','277','2013-11-21 23:54:47','3','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"storyboard\",\"txtMess\":\"wouza+first+%21\"}'),
('147','277','2013-11-22 01:42:11','4','ROOT','BLOCKANIM_NEW_MESSAGE','wouzaah'),
('148','277','2013-11-22 01:42:25','4','ROOT','BLOCKANIM_NEW_MESSAGE','wouzaah'),
('149','277','2013-11-22 01:45:24','4','ROOT','BLOCKANIM_NEW_MESSAGE','ezrttyzre'),
('150','277','2013-11-22 01:46:32','4','ROOT','BLOCKANIM_NEW_MESSAGE','erty'),
('151','277','2013-11-22 01:48:21','4','ROOT','BLOCKANIM_NEW_MESSAGE','fghj fiuuuu'),
('152','277','2013-11-22 02:05:37','4','ROOT','BLOCKANIM_NEW_MESSAGE','mozette'),
('153','277','2013-11-22 15:23:42','4','ROOT','BLOCKANIM_NEW_MESSAGE','ertererrg 
egsdfg 
sdfgsdfg sdfg sdfg sdffg
sdfg 
sdfg 
sdf g
sdf g!'),
('154','277','2013-11-22 23:41:11','3','ROOT','BLOCKANIM_NEW_MESSAGE','yeah !!'),
('155','277','2013-11-22 23:41:38','3','ROOT','BLOCKANIM_NEW_MESSAGE','la grande classe'),
('156','277','2013-11-22 23:41:51','4','ROOT','BLOCKANIM_NEW_MESSAGE','yep, pas mal, no ?'),
('157','277','2013-11-23 01:06:52','4','SHOT','SHOT_VALID_PUBLISHED','{\"idShot\":\"981\",\"dept\":\"anims\"}'),
('158','277','2013-11-23 01:07:41','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"981\",\"dept\":\"anims\"}'),
('159','277','2013-11-23 01:12:21','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"983\",\"dept\":\"anims\"}'),
('160','277','2013-11-23 01:16:09','4','SHOT','SHOT_MOD_PUBLISHED','{\"idShot\":\"981\",\"dept\":\"anims\"}'),
('161','277','2013-11-23 01:23:15','4','SHOT','SHOT_MOD_PUBLISHED','{\"idShot\":\"808\",\"dept\":\"anims\"}'),
('162','277','2013-11-23 17:14:02','4','SHOT','SHOT_VALID_PUBLISHED','{\"idShot\":\"808\",\"dept\":\"compositing\"}'),
('163','277','2013-11-23 17:21:29','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"808\",\"dept\":\"compositing\"}'),
('164','277','2013-11-24 00:50:41','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"982\",\"dept\":\"anims\"}'),
('165','277','2013-11-24 00:51:54','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"982\",\"dept\":\"VFX\"}'),
('166','277','2013-11-26 00:58:31','3','ROOT','BLOCKANIM_NEW_MESSAGE','Illud tamen clausos vehementer angebat quod captis navigiis, quae frumenta vehebant per flumen, Isauri quidem alimentorum copiis adfluebant, ipsi vero solitarum rerum cibos iam consumendo inediae propinquantis aerumnas exitialis horrebant.

Ergo ego senator inimicus, si ita vultis, homini, amicus esse, sicut semper fui, rei publicae debeo. Quid? si ipsas inimicitias, depono rei publicae causa, quis me tandem iure reprehendet, praesertim cum ego omnium meorum consiliorum atque factorum exempla semper ex summorum hominum consiliis atque factis mihi censuerim petenda.

Quapropter a natura mihi videtur potius quam ab indigentia orta amicitia, applicatione magis animi cum quodam sensu amandi quam cogitatione quantum illa res utilitatis esset habitura. Quod quidem quale sit, etiam in bestiis quibusdam animadverti potest, quae ex se natos ita amant ad quoddam tempus et ab eis ita amantur ut facile earum sensus appareat. Quod in homine multo est evidentius, primum ex ea caritate quae est inter natos et parentes, quae dirimi nisi detestabili scelere non potest; deinde cum similis sensus exstitit amoris, si aliquem nacti sumus cuius cum moribus et natura congruamus, quod in eo quasi lumen aliquod probitatis et virtutis perspicere videamur.

Illud tamen clausos vehementer angebat quod captis navigiis, quae frumenta vehebant per flumen, Isauri quidem alimentorum copiis adfluebant, ipsi vero solitarum rerum cibos iam consumendo inediae propinquantis aerumnas exitialis horrebant.

Ergo ego senator inimicus, si ita vultis, homini, amicus esse, sicut semper fui, rei publicae debeo. Quid? si ipsas inimicitias, depono rei publicae causa, quis me tandem iure reprehendet, praesertim cum ego omnium meorum consiliorum atque factorum exempla semper ex summorum hominum consiliis atque factis mihi censuerim petenda.

Quapropter a natura mihi videtur potius quam ab indigentia orta amicitia, applicatione magis animi cum quodam sensu amandi quam cogitatione quantum illa res utilitatis esset habitura. Quod quidem quale sit, etiam in bestiis quibusdam animadverti potest, quae ex se natos ita amant ad quoddam tempus et ab eis ita amantur ut facile earum sensus appareat. Quod in homine multo est evidentius, primum ex ea caritate quae est inter natos et parentes, quae dirimi nisi detestabili scelere non potest; deinde cum similis sensus exstitit amoris, si aliquem nacti sumus cuius cum moribus et natura congruamus, quod in eo quasi lumen aliquod probitatis et virtutis perspicere videamur.'),
('167','277','2013-11-26 01:30:07','4','ROOT','BLOCKANIM_NEW_MESSAGE','serser serg segr'),
('168','277','2013-11-26 01:30:54','4','ROOT','BLOCKANIM_NEW_MESSAGE','rytuukr yu,,yru, aerg zrtth h'),
('169','277','2013-11-26 01:31:11','4','ROOT','BLOCKANIM_NEW_MESSAGE','g yu;fy ;fy u,'),
('170','277','2013-12-19 15:49:49','4','ASSET','ASSET_HANDLED','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"idNewHandler\":\"4\"}'),
('171','277','2013-12-20 12:09:09','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"808\",\"dept\":\"blockanim\"}'),
('172','277','2013-12-20 12:09:21','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"855\",\"dept\":\"blockanim\"}'),
('173','277','2013-12-20 12:14:14','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"981\",\"dept\":\"blockanim\"}'),
('174','277','2013-12-20 12:14:24','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"983\",\"dept\":\"blockanim\"}'),
('175','277','2013-12-20 12:14:43','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"856\",\"dept\":\"blockanim\"}'),
('176','277','2013-12-20 12:14:56','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"982\",\"dept\":\"blockanim\"}'),
('177','277','2014-01-10 02:30:47','4','SCENE','SCENE_NEW_MESSAGE','{\"sceneID\":\"1\",\"deptID\":\"9\",\"txtMess\":\"zer+guuut+%21\"}'),
('178','277','2014-01-17 12:45:03','4','SCENE','SCENE_NEW_MESSAGE','{\"sceneID\":\"1\",\"deptID\":\"10\",\"txtMess\":\"wouzaaaa+test+test\"}'),
('179','277','2014-02-01 13:53:12','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('180','277','2014-02-01 13:53:53','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('181','277','2014-02-01 13:57:07','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('182','277','2014-02-01 13:57:39','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('183','277','2014-02-01 23:03:39','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('184','277','2014-02-01 23:04:08','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('185','277','2014-02-01 23:13:11','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('186','277','2014-02-01 23:15:46','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('187','277','2014-02-01 23:16:26','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"6\"}'),
('188','277','2014-02-01 23:27:29','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"2\"}'),
('189','277','2014-02-01 23:28:21','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"2\"}'),
('190','277','2014-02-01 23:29:22','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"2\"}'),
('191','277','2014-02-01 23:32:48','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('192','277','2014-02-02 01:03:26','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('193','277','2014-02-02 01:03:32','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('194','277','2014-02-02 01:03:41','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"2\"}'),
('195','277','2014-02-02 01:03:46','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"2\"}'),
('196','277','2014-02-02 01:51:00','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('197','277','2014-02-02 01:51:55','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('198','277','2014-02-02 18:58:26','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('199','277','2014-02-02 18:59:33','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('200','277','2014-02-02 19:07:25','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('201','277','2014-02-03 14:43:00','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"testZa\"}'),
('202','277','2014-02-03 14:43:15','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"2\",\"folder\":\"testZa\"}'),
('203','277','2014-02-03 14:44:13','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"test+dailies+msg\"}'),
('204','277','2014-02-03 14:45:16','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"deptID\":\"13\",\"txtMess\":\"Un+ptit+message+pour+tester+le+nouveau+fonctionnement+de+l%27envoi+de+mail+%21%0AOn+verra+bien+ce+que+%C3%A7a+donne+%21%21\"}'),
('206','312','2014-02-05 01:09:49','4','ROOT','BANK_UPLOAD','{\"idProject\":\"312\",\"nbF\":\"1\",\"folder\":\"Polo_anniv_Thorin.jpg\"}'),
('207','312','2014-02-05 01:11:33','4','ROOT','BANK_UPLOAD','{\"idProject\":\"312\",\"nbF\":\"1\",\"folder\":\"datas/projects/312_wouza/bank\"}'),
('208','312','2014-02-05 01:12:06','4','ROOT','BANK_UPLOAD','{\"idProject\":\"312\",\"nbF\":\"1\",\"folder\":\"images\"}'),
('209','312','2014-02-05 01:13:05','4','ROOT','SCENARIO_UPDATE','{\"idProject\":\"312\"}'),
('210','312','2014-02-05 01:15:47','4','SHOT','SHOT_BANK_UPLOAD','{\"idShot\":\"989\",\"dept\":\"storyboard\",\"nbF\":\"1\",\"folder\":\"bank\"}'),
('211','312','2014-02-05 01:16:24','4','SHOT','SHOT_BANK_UPLOAD','{\"idShot\":\"989\",\"dept\":\"anims\",\"nbF\":\"1\",\"folder\":\"stills\"}'),
('212','277','2014-02-05 01:18:05','4','ASSET','ASSET_BANK_UPLOAD','{\"pathAsset\":\"./characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"12\",\"nbF\":\"1\",\"folder\":\"bank\"}'),
('213','312','2014-02-05 01:19:47','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"989\",\"dept\":\"anims\"}'),
('214','312','2014-02-05 01:21:47','4','SHOT','SHOT_VALID_PUBLISHED','{\"idShot\":\"989\",\"dept\":\"anims\"}'),
('215','312','2014-02-05 01:22:06','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"989\",\"dept\":\"anims\"}'),
('216','312','2014-02-05 01:22:14','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"989\",\"dept\":\"anims\",\"txtMess\":\"Wouzah\"}'),
('217','312','2014-02-05 01:23:02','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"989\",\"dept\":\"anims\",\"txtMess\":\"Un+ptit+test+un+peu+plus+pouss%C3%A9%2C+pour+t%27ester+les%0A%22urlD%C3%A9c%C3%B4des%22+%21+YEAH\"}'),
('218','277','2014-02-05 01:26:41','4','ASSET','ASSET_NEW_PUBLISHED','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"12\"}'),
('219','277','2014-02-05 01:27:15','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"12\",\"txtMess\":\"Test+blah+blah+new+mess%27age+%22dho%22+%21%21%0A%0AVla\"}'),
('220','277','2014-02-05 01:27:38','4','ASSET','ASSET_VALID_PUBLISHED','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"12\"}'),
('221','277','2014-02-05 01:28:07','4','ASSET','ASSET_HANDLED','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"idNewHandler\":\"4\"}'),
('222','277','2014-02-05 01:28:21','4','ASSET','ASSET_HANDLED','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"idNewHandler\":\"0\"}'),
('223','277','2014-02-05 01:30:10','4','SCENE','SCENE_HANDLED','{\"sceneID\":\"1\",\"idNewHandler\":\"4\"}'),
('224','277','2014-02-05 01:32:39','4','SCENE','SCENE_NEW_MESSAGE','{\"sceneID\":\"1\",\"deptID\":\"9\",\"txtMess\":\"zawaah%0AT%27est+dailies+%21%21%0Ach%C3%B4%C3%B4%C3%B4%C3%B4\"}'),
('225','277','2014-02-05 01:32:51','4','SCENE','SCENE_VALID_PUBLISHED','{\"sceneID\":\"1\",\"deptID\":\"9\"}'),
('226','277','2014-02-05 01:33:25','4','SCENE','SCENE_NEW_PUBLISHED','{\"sceneID\":\"1\",\"deptID\":\"9\"}'),
('227','277','2014-02-05 01:35:44','4','ROOT','FINAL_NEW_MESSAGE','Oooooooowwww yeah !'),
('228','277','2014-02-05 01:49:38','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"testZa\"}'),
('229','277','2014-02-05 01:54:32','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('230','277','2014-02-05 01:55:16','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('231','277','2014-02-05 01:57:36','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('232','277','2014-02-05 01:59:33','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('233','277','2014-02-05 02:04:15','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"owkay%2C+voyons+ce+que+%C3%A7a+donne\"}'),
('234','277','2014-02-05 02:05:22','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"encore\"}'),
('235','277','2014-02-05 02:07:32','4','ASSET','ASSET_NEW_PUBLISHED','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"12\"}'),
('236','277','2014-02-05 02:08:32','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"12\",\"txtMess\":\"Waahzzoy\"}'),
('237','277','2014-02-05 02:09:23','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"12\",\"txtMess\":\"qdfgqdf+g\"}'),
('238','277','2014-02-05 02:09:39','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"12\",\"txtMess\":\"srthsfgb+nrs+nzyrtn\"}'),
('239','277','2014-02-05 02:10:56','4','ASSET','ASSET_MOD_PUBLISHED','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"12\"}'),
('240','277','2014-02-05 02:17:29','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('241','277','2014-02-05 02:17:59','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('242','277','2014-02-05 02:18:43','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('243','277','2014-02-05 02:20:06','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('244','277','2014-02-05 02:47:13','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('245','312','2014-02-05 02:48:02','4','ROOT','BANK_UPLOAD','{\"idProject\":\"312\",\"nbF\":\"1\",\"folder\":\"images\"}'),
('246','277','2014-02-05 02:48:19','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"waza\"}'),
('247','277','2014-02-05 02:57:22','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"sthzrt+zrt+zrt\"}'),
('248','277','2014-02-05 02:58:03','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"drhr\"}'),
('249','277','2014-02-05 02:59:04','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"gniuk+gniuk\"}'),
('250','277','2014-02-05 02:59:39','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"qeffbqeb\"}'),
('251','277','2014-02-05 03:01:00','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"rthrth\"}'),
('252','277','2014-02-05 03:03:07','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"srgbsrb+srtbrtb\"}'),
('253','277','2014-02-05 03:03:46','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"srthzrsth\"}'),
('254','277','2014-02-05 03:05:12','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"ertyerty\"}'),
('255','277','2014-02-05 03:06:47','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"nty+detnyteyn+eyt\"}'),
('256','277','2014-02-05 03:08:03','4','ASSET','ASSET_NEW_MESSAGE','{\"idAsset\":\"12\",\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"12\",\"txtMess\":\"wazzzoooouy\"}'),
('257','277','2014-02-05 03:09:30','4','ASSET','ASSET_NEW_MESSAGE','{\"idAsset\":\"12\",\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"12\",\"txtMess\":\"ertyerty\"}'),
('258','277','2014-02-05 03:11:34','4','SCENE','SCENE_NEW_MESSAGE','{\"sceneID\":\"1\",\"deptID\":\"9\",\"txtMess\":\"test+wazz\"}'),
('259','277','2014-02-05 03:12:06','4','SCENE','SCENE_NEW_MESSAGE','{\"sceneID\":\"1\",\"deptID\":\"9\",\"txtMess\":\"ouh+yeaw\"}'),
('260','277','2014-02-05 03:12:31','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('261','277','2014-02-05 03:13:58','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('262','277','2014-02-05 03:15:07','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('263','277','2014-02-05 03:15:54','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('264','277','2014-02-05 03:16:25','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('265','277','2014-02-05 15:32:44','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"981\",\"dept\":\"anims\",\"txtMess\":\"Kikooo+%21%21\"}'),
('266','277','2014-02-05 15:36:18','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"981\",\"dept\":\"anims\",\"txtMess\":\"srthsrth+sthz+rt\"}'),
('267','277','2014-02-05 15:37:58','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"981\",\"dept\":\"anims\",\"txtMess\":\"sdfb+sz\"}'),
('268','277','2014-02-05 15:38:51','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"owkay+%21%21\"}'),
('269','277','2014-02-05 15:45:01','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"981\",\"dept\":\"anims\",\"txtMess\":\"wazzaah+%21%21+Juste+pour+voir+si+je+re%C3%A7oit+bien+le+mail+d%27alert+temps+r%C3%A9el+%21%21+On+verra+bien+le+truc+%21%21\"}'),
('270','277','2014-02-05 15:48:36','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"983\",\"dept\":\"anims\",\"txtMess\":\"Juste+un+test+en+local%2C+pour+voir+si+les+my_shots+sont+respect%C3%A9s+%21%0AD%C3%A9sol%C3%A9+pour+la+pollution+de+bo%C3%AEte+email+%21%0A%0AEn+tout+cas%2C+%C3%A7a+va+%C3%AAtre+vachement+%2B+joli+qu%27avant+%21%0Alol%0A%2B%2B+%21\"}'),
('271','277','2014-02-05 15:54:38','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"981\",\"dept\":\"anims\",\"txtMess\":\"gniuk+gniuk\"}'),
('272','277','2014-02-05 16:00:55','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"981\",\"dept\":\"anims\",\"txtMess\":\"zrtzrtg\"}'),
('273','277','2014-02-05 16:01:41','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"981\",\"dept\":\"anims\",\"txtMess\":\"ertyerty\"}'),
('274','277','2014-02-05 16:03:28','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"981\",\"dept\":\"anims\",\"txtMess\":\"ertherth+rth\"}'),
('275','277','2014-02-05 16:18:58','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"981\",\"dept\":\"anims\",\"txtMess\":\"xoinerg+oi+fgfg\"}'),
('276','277','2014-02-05 16:19:16','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"981\",\"dept\":\"anims\",\"txtMess\":\"sfgsdfg\"}'),
('277','277','2014-02-05 16:26:48','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"981\",\"dept\":\"anims\",\"txtMess\":\"wouzaaa+%21%21\"}'),
('278','277','2014-02-06 00:13:34','4','SCENE','SCENE_NEW_PUBLISHED','{\"sceneID\":\"12\",\"deptID\":\"9\"}'),
('279','277','2014-02-06 00:16:40','4','SCENE','SCENE_VALID_PUBLISHED','{\"sceneID\":\"12\",\"deptID\":\"9\"}'),
('280','277','2014-02-06 00:16:48','4','SCENE','SCENE_NEW_PUBLISHED','{\"sceneID\":\"12\",\"deptID\":\"9\"}'),
('281','277','2014-02-06 00:24:26','4','SCENE','SCENE_MOD_PUBLISHED','{\"sceneID\":\"12\",\"deptID\":\"9\"}'),
('282','277','2014-02-06 00:30:38','4','SCENE','SCENE_VALID_PUBLISHED','{\"sceneID\":\"12\",\"deptID\":\"9\"}'),
('283','277','2014-02-06 00:30:54','4','SCENE','SCENE_NEW_PUBLISHED','{\"sceneID\":\"12\",\"deptID\":\"9\"}'),
('284','277','2014-02-06 00:36:06','4','SCENE','SCENE_MOD_PUBLISHED','{\"sceneID\":\"12\",\"deptID\":\"9\"}'),
('285','277','2014-02-07 23:24:43','72','ROOT','SCENARIO_UPDATE','{\"idProject\":\"277\"}'),
('286','277','2014-02-07 23:27:08','72','ROOT','SCENARIO_UPDATE','{\"idProject\":\"277\"}'),
('287','277','2014-02-10 14:41:13','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"982\",\"dept\":\"storyboard\"}'),
('288','277','2014-02-10 14:41:38','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"982\",\"dept\":\"storyboard\",\"txtMess\":\"Test+%21\"}'),
('289','277','2014-02-10 14:41:43','4','SHOT','SHOT_VALID_PUBLISHED','{\"idShot\":\"982\",\"dept\":\"storyboard\"}'),
('290','277','2014-02-10 14:41:53','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"982\",\"dept\":\"storyboard\"}'),
('291','277','2014-02-10 14:42:05','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"982\",\"dept\":\"storyboard\",\"txtMess\":\"test\"}'),
('292','277','2014-02-10 14:42:10','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"982\",\"dept\":\"storyboard\",\"txtMess\":\"ok\"}'),
('293','277','2014-02-10 14:44:32','4','SCENE','SCENE_NEW_MESSAGE','{\"sceneID\":\"12\",\"deptID\":\"9\",\"txtMess\":\"wouza+%21\"}'),
('294','277','2014-02-12 03:01:25','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"testZa\"}'),
('295','277','2014-02-12 03:07:20','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"3\",\"folder\":\"testZa\"}'),
('296','277','2014-02-12 03:08:54','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"2\",\"folder\":\"testZa\"}'),
('297','277','2014-02-12 12:51:30','73','SCENE','SCENE_NEW_MESSAGE','{\"sceneID\":\"1\",\"deptID\":\"9\",\"txtMess\":\"Im+an+artist\"}'),
('298','277','2014-02-12 13:03:05','73','SCENE','SCENE_HANDLED','{\"sceneID\":\"10\",\"idNewHandler\":\"73\"}'),
('299','277','2014-02-12 13:05:29','73','SCENE','SCENE_HANDLED','{\"sceneID\":\"10\",\"idNewHandler\":\"0\"}'),
('300','277','2014-02-12 13:08:13','73','SCENE','SCENE_NEW_PUBLISHED','{\"sceneID\":\"10\",\"deptID\":\"9\"}'),
('301','277','2014-02-12 13:08:22','73','SCENE','SCENE_NEW_MESSAGE','{\"sceneID\":\"10\",\"deptID\":\"9\",\"txtMess\":\"wouzah\"}'),
('302','277','2014-02-12 20:06:18','4','ASSET','ASSET_HANDLED','{\"idAsset\":\"14\",\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"idNewHandler\":\"0\"}'),
('303','277','2014-02-12 21:07:03','73','ASSET','ASSET_NEW_MESSAGE','{\"idAsset\":\"12\",\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"12\",\"txtMess\":\"Test+waaazou\"}'),
('304','277','2014-02-12 21:07:23','4','ASSET','ASSET_NEW_MESSAGE','{\"idAsset\":\"12\",\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"12\",\"txtMess\":\"OKOK+bon+bah...\"}'),
('305','277','2014-02-13 13:22:22','4','ASSET','ASSET_HANDLED','{\"idAsset\":\"37\",\"pathAsset\":\"characters/aliens/gniuk/\",\"nameAsset\":\"gniuk.blend\",\"idNewHandler\":\"0\"}'),
('306','277','2014-02-16 17:59:00','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"wouzaahgrll\"}'),
('307','277','2014-02-20 13:46:41','73','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"7\",\"folder\":\"wouza\"}'),
('308','277','2014-02-20 13:57:41','73','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"3\",\"folder\":\"wouza\"}');


-- ----------------- TABLE saam_dailies_summary ------------------------

DROP TABLE IF EXISTS `saam_dailies_summary`;

CREATE TABLE `saam_dailies_summary` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `ID_project` int(5) NOT NULL,
  `week` varchar(8) NOT NULL,
  `user` int(5) NOT NULL,
  `comment` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `saam_dailies_summary` VALUES 
('1','277','2013_27','4','un petit test d\'ajout de résumé, à l\'ancienne !

Juste pour voir si je suis toujours aussi efficace :P','2013-07-05 17:24:29'),
('5','277','2013_28','4','Wazzaaaaaaaa !!

bah voila, tout qui marche

sauf les links bien sûr...
A suivre, donc','2013-07-13 17:50:30'),
('6','277','2013_28','4','eh non, t\'oublies les anciennes semaines !!
:O','2013-07-13 17:51:05'),
('7','277','2013_28','4','En voila une belle de modif !','2013-07-13 19:53:55'),
('11','277','2013_35','4','Petit résumé de ce qu\'il s\'est passé cette semaine !

Alors, en gros : Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec a diam lectus. Sed sit amet ipsum mauris. Maecenas congue ligula ac quam viverra nec consectetur ante hendrerit. Donec et mollis dolor. Praesent et diam eget libero egestas mattis sit amet vitae augue. Nam tincidunt congue enim, ut porta lorem lacinia consectetur. Donec ut libero sed arcu vehicula ultricies a non tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean ut gravida lorem. Ut turpis felis, pulvinar a semper sed, adipiscing id dolor. Pellentesque auctor nisi id magna consequat sagittis. Curabitur dapibus enim sit amet elit pharetra tincidunt feugiat nisl imperdiet. Ut convallis libero in urna ultrices accumsan. Donec sed odio eros. Donec viverra mi quis quam pulvinar at malesuada arcu rhoncus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. In rutrum accumsan ultricies. Mauris vitae nisi at sem facilisis semper ac in est.','2013-09-01 14:51:21');


-- ----------------- TABLE saam_depts ------------------------

DROP TABLE IF EXISTS `saam_depts`;

CREATE TABLE `saam_depts` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `type` varchar(12) NOT NULL,
  `label` varchar(32) NOT NULL,
  `position` int(2) NOT NULL,
  `template_name` varchar(32) NOT NULL,
  `etapes` text NOT NULL,
  `hide` tinyint(1) NOT NULL,
  `dict` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `position` (`position`),
  KEY `label` (`label`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

INSERT INTO `saam_depts` VALUES 
('1','shots','blockanim','1','template_1','[\"WIP\"]','0',''),
('2','shots','tournage','2','template_1','[\"En tournage\",\"D\\u00e9rushage\"]','0',''),
('3','shots','mocap','3','template_1','[\"Shooting\",\"Cleaning\"]','0',''),
('4','shots','anims','4','template_1','[\"Poses\",\"Anim draft\",\"Anim fine\"]','0',''),
('5','shots','vfx','5','template_1','[\"Passe1\",\"Passe2\"]','0',''),
('6','shots','compositing','6','template_1','[\"Matte-painting\",\"VFX\",\"DoF\"]','0',''),
('7','shots','montage','7','template_1','[\"Dérushage\",\"Passe 1\",\"Passe 2\"]','0',''),
('8','shots','etalonnage','8','template_1','[\"WIP\"]','0',''),
('9','scenes','keyframes','1','05_scenes','[\"todo\",\"layout\",\"draft\",\"fine\"]','0',''),
('10','scenes','mocap','2','05_scenes','[\"todo\",\"WIP\"]','0',''),
('11','scenes','vfx','3','05_scenes','[\"todo\",\"WIP\"]','0',''),
('12','assets','concept','1','06_assets','[\"todo\",\"WIP\"]','0',''),
('13','assets','modeling','2','06_assets','[\"todo\",\"WIP\"]','0',''),
('14','assets','sculpting','3','06_assets','[\"todo\",\"WIP\"]','0',''),
('15','assets','rigging','4','06_assets','[\"todo\",\"WIP\"]','0',''),
('16','assets','furs','5','06_assets','[\"todo\",\"WIP\"]','0',''),
('17','assets','texturing','6','06_assets','[\"todo\",\"WIP\"]','0','');


-- ----------------- TABLE saam_gantt ------------------------

DROP TABLE IF EXISTS `saam_gantt`;

CREATE TABLE `saam_gantt` (
  `id` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




-- ----------------- TABLE saam_jchat ------------------------

DROP TABLE IF EXISTS `saam_jchat`;

CREATE TABLE `saam_jchat` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `from` int(6) NOT NULL,
  `to` int(4) NOT NULL,
  `message` text NOT NULL,
  `sent` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `recd` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `to` (`to`),
  KEY `from` (`from`)
) ENGINE=MyISAM AUTO_INCREMENT=1362 DEFAULT CHARSET=utf8;

INSERT INTO `saam_jchat` VALUES 
('1356','58','4',':)','2013-09-01 14:55:02','1'),
('1355','58','4','bah c\'est dÃ©jÃ  pas mal, non ?','2013-09-01 14:55:01','1'),
('1354','4','58','c\'est tout ?','2013-09-01 14:54:52','1'),
('1353','4','58','oui','2013-09-01 14:54:41','1'),
('1352','58','4','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec a diam lectus. Sed sit amet ipsum mauris. Maecenas congue ligula ac quam viverra nec consectetur ante hendrerit.','2013-09-01 14:54:36','1'),
('1351','4','58','pourquoi pas','2013-09-01 14:54:18','1'),
('1350','4','58','bon, ok','2013-09-01 14:54:12','1'),
('1349','58','4','bah Ã©coute, Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec a diam lectus. Sed sit amet ipsum mauris. Maecenas congue ligula ac quam viverra nec consectetur ante hendrerit. Donec et mollis dolor. Praesent et diam eget libero egestas mattis sit amet vitae augue. Nam tincidunt congue enim, ut porta lorem lacinia consectetur !','2013-09-01 14:54:06','1'),
('1307','4','2','az','2013-04-25 20:51:44','1'),
('1308','4','2','az','2013-04-25 20:51:44','1'),
('1309','4','2','az','2013-04-25 20:51:45','1'),
('1310','4','2','az','2013-04-25 20:51:45','1'),
('1311','4','2','az','2013-04-25 20:51:45','1'),
('1348','4','58','comment va ?','2013-09-01 14:53:47','1'),
('1347','4','58','Hoy !','2013-09-01 14:53:42','1'),
('1346','4','58','Hi man !!','2013-09-01 14:53:28','1'),
('1345','58','4','Helllo !','2013-09-01 14:53:18','1'),
('1361','4','3','vla','2013-10-30 18:45:44','1'),
('1360','4','3','ye','2013-10-30 18:45:41','1'),
('1359','4','3','yop','2013-10-30 18:45:23','1'),
('1358','3','4','za','2013-10-30 18:44:52','1'),
('1357','4','1','shshsfgh','2013-09-03 22:54:49','0'),
('1312','4','2','az','2013-04-25 20:51:45','1'),
('1313','2','4','yop','2013-04-25 20:52:01','1'),
('1314','4','2','za','2013-04-28 01:09:21','1'),
('1315','2','4','hop la','2013-04-28 01:09:33','1'),
('1316','4','2','zou','2013-04-28 01:14:55','1'),
('1317','4','2','hoy','2013-04-28 01:22:38','1'),
('1318','4','2','yop','2013-04-28 01:23:00','1'),
('1319','4','2','zou','2013-04-28 01:55:00','1'),
('1320','2','4','zouzou','2013-04-28 02:03:05','1'),
('1321','2','4','za','2013-04-28 12:02:45','1'),
('1322','4','2','hop','2013-04-28 12:05:06','1'),
('1323','4','2','zou','2013-04-28 12:15:16','1'),
('1324','2','4','holay','2013-04-28 12:15:48','1'),
('1325','4','2','owkay','2013-04-28 12:16:41','1'),
('1326','2','4','owkay','2013-04-28 12:17:38','1'),
('1327','4','2','wouza','2013-04-28 12:17:45','1'),
('1328','2','4','hoy','2013-04-28 12:24:28','1'),
('1329','4','2','za','2013-04-28 12:24:37','1'),
('1330','2','4','owkay','2013-04-28 12:24:43','1'),
('1331','2','4','alors on va voir comment Ã§a rÃ©agit','2013-04-28 12:24:52','1'),
('1332','4','2','yes','2013-04-28 12:24:56','1'),
('1333','4','2','en espÃ©rant que Ã§a soit rÃ©glÃ© !!','2013-04-28 12:25:03','1'),
('1334','2','4','zou','2013-04-28 12:27:16','1'),
('1335','4','2','za','2013-04-28 12:27:33','1'),
('1336','2','4','test de refresh','2013-04-28 12:30:00','1'),
('1337','4','2','owkay','2013-04-28 12:30:13','1'),
('1338','4','2','allons y','2013-04-28 12:30:17','1'),
('1339','4','2','zy','2013-04-28 12:30:21','1'),
('1340','2','4','zou','2013-04-28 12:30:24','1'),
('1341','2','4','bah alors','2013-04-28 12:37:02','1'),
('1342','2','4','zoy ?','2013-04-28 12:42:27','1'),
('1343','4','2','zaf','2013-04-28 12:42:33','1'),
('1344','4','2','za','2013-04-28 17:10:30','1');


-- ----------------- TABLE saam_news ------------------------

DROP TABLE IF EXISTS `saam_news`;

CREATE TABLE `saam_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ID_creator` int(4) NOT NULL,
  `visible` tinyint(1) NOT NULL,
  `new_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `new_title` varchar(255) NOT NULL,
  `new_text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

INSERT INTO `saam_news` VALUES 
('1','1','1','2030-01-01 16:12:36','SaAM 0.99','<p class=\\\"big colorErrText\\\">
Nouvelle version du SaAM !
</p>
<p>Changelog :</p>
<p class=\\\"marge10l colorHard\\\">
* nouvelle partie : SCÈNES !!<br>
* choix du timing de la déconnexion auto dans les préférences<br>
* refonte de la BANK générale<br>
* refonte du système d\\\'envoi d\\\'email / dailies<br>
</p>
<p class=\\\"colorHard\\\">
Le SaAM est quasiment terminé.<br>
La version 1.0 sortira quand nous auront fait des tutos vidéos,<br>
rédigé le wiki, et terminé une version stable de l\\\'API python !
</p>
'),
('13','2','0','2012-07-04 21:50:39','ADD project utilisable','drag and drop pour les vignettes'),
('14','2','0','2012-07-10 18:10:15','Integration vraies données en cours','Les informations que vous voyez dans le SaAM ne sont pas forcément le reflet de la base de données... Leur intégration est en cous.'),
('15','2','0','2012-07-10 18:02:15','ADD / MOD User utilisable','acl wip'),
('16','2','0','2012-07-19 23:10:45','Masterfile xml','fichier \\\'thesaurus\\\' global'),
('18','2','0','2012-07-27 02:24:37','ACL, gestion droits UI','gestion visibilité Module interface en fonction du status -> DONE'),
('19','2','0','2013-02-04 17:06:33','Chat direct','Malgré quelques petits bugs, ça semble marcher...');


-- ----------------- TABLE saam_notes ------------------------

DROP TABLE IF EXISTS `saam_notes`;

CREATE TABLE `saam_notes` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `position` int(9) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ID_user` int(5) NOT NULL,
  `note` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

INSERT INTO `saam_notes` VALUES 
('7','1','2013-07-22 15:30:44','4','et%2C+hop+l%C3%A0+%21+encore+une+petite+pour+la+route+%21%0A%0Aon+va+pas+cracher+dessus...'),
('6','2','2013-07-22 15:29:25','4','WAZZAAAAa%0A%0Avla+de+la+note+qui+d%C3%A9boite...'),
('9','1','2013-07-24 12:50:28','4','on+va+bien+voir...%0A%0Abah+%C3%A7a+marche+pas+mal+tout+%C3%A7a+%21'),
('14','0','2013-07-24 12:53:20','4','Lorem+ipsum+et+dolor+sit+amet+nur+bratisclava+nonobstant+blor+lorem+ipsum+et+dolor+sit+amet+nur+bratisclava+nonobstant+blor+%21%0A%0Alorem+ipsum+et+dolor+sit+amet.'),
('18','0','2013-07-24 13:00:26','4','OWKAY+%21');


-- ----------------- TABLE saam_prod_custom ------------------------

DROP TABLE IF EXISTS `saam_prod_custom`;

CREATE TABLE `saam_prod_custom` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `ID_project` int(6) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `brand_new` text NOT NULL,
  `testMulti` text NOT NULL,
  `nickel` text NOT NULL,
  `vide` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=85 DEFAULT CHARSET=utf8;

INSERT INTO `saam_prod_custom` VALUES 
('0','0','0','[[\"1\",\"277\",\"293\"],{\"id\":\"int\",\"status\":\"*saam_config.default_status.val>json.default_status\",\"kidonc\":\"*saam_users.id.direct.pseudo\",\"addla\":\"text\",\"owkay\":\"text\",\"test\":\"text\",\"gniuk_gniuk\":\"int\",\"anniv\":\"datetime\",\"xfcgh\":\"*saam_assets.id.json>val.filename\"}]','[[\"277\",\"1\",\"293\",\"293\"],{\"id\":\"int\",\"status\":\"*saam_config.default_status.val>json.default_status\",\"cypher\":\"text\",\"meuh\":\"datetime\",\"tags\":\"*saam_config.global_tags.json>json.global_tags\",\"megaStatus\":\"*saam_config.default_status.val>json.default_status\",\"test\":\"boolean\",\"hehehe\":\"*saam_shots.id.json>val.title\"}]','[[\"277\"],{\"id\":\"int\",\"status\":\"*saam_config.default_status.val>json.default_status\",\"shots\":\"*saam_shots.id.json>val.title\",\"trop_fort\":\"boolean\",\"TC-in\":\"timecode\"}]','[[\"277\"],{\"id\":\"int\",\"status\":\"*saam_config.default_status.val>json.default_status\",\"userStatus\":\"*saam_users.id.direct.pseudo\",\"tcsz\":\"*CT_nickel.id.direct.TC-in\",\"assetsTestCT\":\"*saam_assets.id.json>val.filename\"}]'),
('1','277','0','{\"status\":2,\"test\":\"yeah\",\"owkay\":\"Yiiiihaaaa\",\"addla\":\"nice !!\",\"anniv\":\"2013-10-17 00:00:00\",\"kidonc\":2,\"gniuk_gniuk\":\"156\",\"xfcgh\":\"\"}','','',''),
('2','277','0','{\"status\":\"1\",\"addla\":\"zer\",\"test\":\"yeah\",\"owkay\":\"Wazzaaaaaa\",\"anniv\":\"2013-10-17 00:00:00\",\"kidonc\":4,\"gniuk_gniuk\":\"88\",\"xfcgh\":[\"13\",\"39\"]}','','',''),
('5','277','0','','{\"status\":\"1\",\"cypher\":\"Owkay, maintenant on est fix\\u00e9s : \'TOUT \\\"marche\\\" \' !!\\nyeah.\",\"meuh\":\"2013-10-14 00:00:00\",\"tags\":\"\",\"megaStatus\":2,\"za\":\"\",\"test\":1,\"hehehe\":[\"858\",\"917\"]}','',''),
('6','277','0','','{\"status\":\"2\",\"cypher\":\"hu00e9hu00e9\",\"meuh\":\"2013-07-06 00:00:00\",\"tags\":\"[\"Need review\",\"Stable\"]\",\"megaStatus\":\"2\",\"za\":\"\",\"test\":\"1\",\"hehehe\":\"\"}','',''),
('7','277','0','','','{\"status\":\"1\",\"trop_fort\":\"\",\"shots\":[\"858\",\"910\",\"911\"],\"TC-in\":\"00:05:12:04\",\"seqs\":\"\"}',''),
('8','277','1','{\"status\":1,\"test\":\"deleted\",\"owkay\":\"Wazzaaaaaa\",\"addla\":\"\",\"anniv\":\"2014-01-14 19:05:00\",\"kidonc\":\"4\",\"gniuk_gniuk\":\"156\",\"xfcgh\":\"\"}','','',''),
('9','277','0','{\"status\":\"3\",\"test\":\"vla l\'ultime test avant dodo\",\"addla\":\"perfect\",\"owkay\":\"ce que \\u00e7a donne ? Bah c\'est \\u00e9norme... vla !\",\"anniv\":\"2013-10-17 00:00:00\",\"kidonc\":\"4\",\"gniuk_gniuk\":\"27\",\"xfcgh\":\"\"}','','',''),
('10','277','0','{\"status\":3,\"test\":\"ftyu\",\"addla\":\"magnifique\",\"owkay\":\"Wazzaaaaaa\",\"kidonc\":3,\"gniuk_gniuk\":\"88\",\"anniv\":\"2013-10-25 00:00:00\",\"xfcgh\":\"\"}','','',''),
('11','277','0','','{\"status\":\"0\",\"cypher\":\"Pas mal tout \\u00e7a nom d\'une pipe !!\",\"meuh\":\"2013-10-15 00:00:00\",\"tags\":\"\",\"megaStatus\":2,\"za\":\"\",\"test\":1,\"hehehe\":[\"855\",\"856\",\"917\"]}','',''),
('12','277','0','','','{\"status\":\"0\",\"trop_fort\":0,\"shots\":\"\",\"TC-in\":\"00:23:05:01\",\"seqs\":\"\"}',''),
('13','277','0','','','{\"status\":\"2\",\"trop_fort\":0,\"shots\":[\"858\",\"910\",\"911\"],\"TC-in\":\"00:05:00:12\",\"seqs\":\"\"}',''),
('14','277','0','','{\"status\":\"0\",\"cypher\":\"Owkay, maintenant on est fix\\u00e9s : \'TOUT \\\"marche\\\" \' !!\\nyeah.\",\"meuh\":\"2013-10-16 00:00:00\",\"tags\":[\"Need review\"],\"megaStatus\":1,\"za\":\"\",\"test\":0,\"hehehe\":[\"857\",\"858\",\"908\",\"909\",\"910\",\"911\",\"912\",\"981\"]}','',''),
('15','277','0','','{\"status\":\"0\",\"cypher\":\"Owkay, maintenant on est fix\\u00e9s : \'TOUT \\\"marche\\\" \' !!\\nyeah.\",\"meuh\":\"2013-10-17 00:00:00\",\"tags\":[\"Need review\"],\"megaStatus\":1,\"za\":\"\",\"test\":0,\"hehehe\":[\"857\",\"858\",\"908\",\"909\",\"910\",\"911\",\"912\",\"981\"]}','',''),
('16','277','0','','','{\"status\":3,\"trop_fort\":1,\"shots\":[\"855\",\"856\",\"857\",\"858\"],\"TC-in\":\"00:05:00:12\",\"seqs\":\"\"}',''),
('18','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"\",\"TC-in\":\"00:00:00:00\",\"seqs\":\"\"}',''),
('19','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"\",\"TC-in\":\"00:00:00:00\",\"seqs\":\"\"}',''),
('20','277','0','','','{\"status\":\"0\",\"shots\":[\"808\",\"856\"],\"trop_fort\":\"0\",\"TC-in\":\"00:00:01:01\",\"seqs\":\"\"}',''),
('21','277','0','','','{\"status\":\"0\",\"shots\":[\"808\",\"856\"],\"trop_fort\":\"0\",\"TC-in\":\"00:00:01:01\",\"seqs\":\"\"}',''),
('22','277','0','','','{\"status\":\"0\",\"shots\":[\"808\",\"856\"],\"trop_fort\":\"0\",\"TC-in\":\"00:00:01:01\",\"seqs\":\"\"}',''),
('23','277','0','','','{\"status\":\"0\",\"shots\":[\"808\",\"856\"],\"trop_fort\":\"0\",\"TC-in\":\"00:00:01:01\",\"seqs\":\"\"}',''),
('24','277','0','','','{\"status\":\"0\",\"shots\":[\"808\",\"856\"],\"trop_fort\":\"0\",\"TC-in\":\"00:00:01:01\",\"seqs\":\"\"}',''),
('25','277','0','','','{\"status\":\"0\",\"shots\":[\"808\",\"856\"],\"trop_fort\":\"0\",\"TC-in\":\"00:00:01:01\",\"seqs\":\"\"}',''),
('26','277','0','','','{\"status\":\"0\",\"shots\":[\"808\",\"856\"],\"trop_fort\":\"0\",\"TC-in\":\"00:00:01:01\",\"seqs\":\"\"}',''),
('27','277','0','','','{\"status\":\"0\",\"shots\":[\"808\",\"856\"],\"trop_fort\":\"0\",\"TC-in\":\"00:00:01:01\",\"seqs\":\"\"}',''),
('28','277','0','','','{\"status\":\"0\",\"shots\":[\"808\",\"856\"],\"trop_fort\":\"0\",\"TC-in\":\"00:00:01:01\",\"seqs\":\"\"}',''),
('29','277','0','','','{\"status\":\"0\",\"shots\":[\"808\",\"856\"],\"trop_fort\":\"0\",\"TC-in\":\"00:00:01:01\",\"seqs\":\"\"}',''),
('30','277','0','','','{\"status\":\"0\",\"shots\":[\"808\",\"856\"],\"trop_fort\":\"0\",\"TC-in\":\"00:00:01:01\",\"seqs\":\"\"}',''),
('31','277','0','','','{\"status\":\"2\",\"shots\":[\"913\",\"917\"],\"trop_fort\":\"\",\"TC-in\":\"00:00:02:02\",\"seqs\":\"\"}',''),
('32','277','0','','','{\"status\":\"2\",\"shots\":[\"913\",\"917\"],\"trop_fort\":\"\",\"TC-in\":\"00:00:02:02\",\"seqs\":\"\"}',''),
('33','277','0','','','{\"status\":\"2\",\"shots\":[\"856\",\"913\",\"917\"],\"trop_fort\":1,\"TC-in\":\"00:00:02:02\",\"seqs\":\"\"}',''),
('34','277','0','','','{\"status\":\"2\",\"shots\":[\"856\",\"913\",\"917\"],\"trop_fort\":1,\"TC-in\":\"00:00:02:02\",\"seqs\":\"\"}',''),
('35','277','0','','','{\"status\":\"2\",\"shots\":[\"856\",\"913\",\"917\"],\"trop_fort\":1,\"TC-in\":\"00:00:02:02\",\"seqs\":\"\"}',''),
('36','277','0','','','{\"status\":\"2\",\"shots\":[\"856\",\"913\",\"917\"],\"trop_fort\":1,\"TC-in\":\"00:00:02:02\",\"seqs\":\"\"}',''),
('37','277','0','','','{\"status\":\"2\",\"shots\":[\"856\",\"913\",\"917\"],\"trop_fort\":1,\"TC-in\":\"00:00:02:02\",\"seqs\":\"\"}',''),
('38','277','0','','','{\"status\":\"2\",\"shots\":[\"913\",\"917\"],\"trop_fort\":\"\",\"TC-in\":\"00:00:02:02\",\"seqs\":\"\"}',''),
('39','277','0','','','{\"status\":\"2\",\"shots\":[\"913\",\"917\"],\"trop_fort\":\"\",\"TC-in\":\"00:00:02:02\",\"seqs\":\"\"}',''),
('40','277','0','','','{\"status\":\"2\",\"shots\":[\"913\",\"917\"],\"trop_fort\":\"\",\"TC-in\":\"00:00:02:02\",\"seqs\":\"\"}',''),
('41','277','0','','','{\"status\":\"2\",\"shots\":[\"913\",\"917\"],\"trop_fort\":\"\",\"TC-in\":\"00:00:02:02\",\"seqs\":\"\"}',''),
('42','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"\",\"TC-in\":\"00:00:03:03\",\"seqs\":\"\"}',''),
('43','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"\",\"TC-in\":\"00:00:03:03\",\"seqs\":\"\"}',''),
('44','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"\",\"TC-in\":\"00:00:03:03\",\"seqs\":\"\"}',''),
('45','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"\",\"TC-in\":\"00:00:03:03\",\"seqs\":\"\"}',''),
('46','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"\",\"TC-in\":\"00:00:03:03\",\"seqs\":\"\"}',''),
('47','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"\",\"TC-in\":\"00:00:03:03\",\"seqs\":\"\"}',''),
('48','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"\",\"TC-in\":\"00:00:03:03\",\"seqs\":\"\"}',''),
('49','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"\",\"TC-in\":\"00:00:03:03\",\"seqs\":\"\"}',''),
('50','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"\",\"TC-in\":\"00:00:03:03\",\"seqs\":\"\"}',''),
('51','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"\",\"TC-in\":\"00:00:03:03\",\"seqs\":\"\"}',''),
('52','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"\",\"TC-in\":\"00:00:03:03\",\"seqs\":\"\"}',''),
('53','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"1\",\"TC-in\":\"00:00:04:04\",\"seqs\":\"\"}',''),
('54','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"1\",\"TC-in\":\"00:00:04:04\",\"seqs\":\"\"}',''),
('55','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"1\",\"TC-in\":\"00:00:04:04\",\"seqs\":\"\"}',''),
('56','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"1\",\"TC-in\":\"00:00:04:04\",\"seqs\":\"\"}',''),
('57','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"1\",\"TC-in\":\"00:00:04:04\",\"seqs\":\"\"}',''),
('58','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"1\",\"TC-in\":\"00:00:04:04\",\"seqs\":\"\"}',''),
('59','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"1\",\"TC-in\":\"00:00:04:04\",\"seqs\":\"\"}',''),
('60','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"1\",\"TC-in\":\"00:00:04:04\",\"seqs\":\"\"}',''),
('61','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"1\",\"TC-in\":\"00:00:04:04\",\"seqs\":\"\"}',''),
('62','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"1\",\"TC-in\":\"00:00:04:04\",\"seqs\":\"\"}',''),
('63','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"1\",\"TC-in\":\"00:00:04:04\",\"seqs\":\"\"}',''),
('64','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":1,\"TC-in\":\"00:00:05:05\",\"seqs\":\"\"}',''),
('65','277','1','','','{\"status\":1,\"shots\":null,\"trop_fort\":\"\",\"TC-in\":\"00:00:05:05\",\"seqs\":\"\"}',''),
('66','277','0','','','{\"status\":1,\"shots\":null,\"trop_fort\":1,\"TC-in\":\"00:01:05:07\",\"seqs\":\"\"}',''),
('67','277','1','','','{\"status\":1,\"shots\":null,\"trop_fort\":1,\"TC-in\":\"00:01:05:05\",\"seqs\":\"\"}',''),
('68','277','1','','','{\"status\":1,\"shots\":null,\"trop_fort\":1,\"TC-in\":\"00:01:05:05\",\"seqs\":\"\"}',''),
('69','277','1','','','{\"status\":1,\"shots\":null,\"trop_fort\":\"\",\"TC-in\":\"00:00:05:05\",\"seqs\":\"\"}',''),
('70','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"\",\"TC-in\":\"00:00:05:05\",\"seqs\":\"\"}',''),
('71','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"\",\"TC-in\":\"00:00:05:05\",\"seqs\":\"\"}',''),
('72','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"\",\"TC-in\":\"00:00:05:05\",\"seqs\":\"\"}',''),
('73','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"\",\"TC-in\":\"00:00:05:05\",\"seqs\":\"\"}',''),
('74','277','0','','','{\"status\":\"0\",\"shots\":null,\"trop_fort\":\"\",\"TC-in\":\"00:00:05:05\",\"seqs\":\"\"}',''),
('75','277','0','','','','{\"status\":\"1\",\"userStatus\":\"2\",\"tags\":\"\",\"mouarf\":\"\",\"testRelCT\":\"\",\"haha\":11,\"assCat\":[\"12\",\"13\",\"15\"],\"tcsz\":66,\"assetsTestCT\":[\"12\",\"13\",\"14\"]}'),
('76','293','0','','','',''),
('77','293','0','','','',''),
('78','293','0','','','',''),
('79','277','0','','','',''),
('80','277','0','','','',''),
('81','277','0','','','',''),
('82','277','0','','','',''),
('83','277','0','','','',''),
('84','277','0','','','','');


-- ----------------- TABLE saam_projects ------------------------

DROP TABLE IF EXISTS `saam_projects`;

CREATE TABLE `saam_projects` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `ID_creator` int(4) NOT NULL,
  `fps` float NOT NULL,
  `nomenclature` text NOT NULL,
  `project_type` varchar(255) NOT NULL,
  `dpts` text NOT NULL,
  `position` int(5) NOT NULL,
  `supervisor` varchar(256) NOT NULL,
  `title` varchar(256) NOT NULL,
  `description` text NOT NULL,
  `director` varchar(255) NOT NULL,
  `equipe` text NOT NULL,
  `company` varchar(256) NOT NULL,
  `date` datetime NOT NULL,
  `update` date NOT NULL,
  `updated_by` int(6) NOT NULL,
  `deadline` datetime NOT NULL,
  `progress` int(3) NOT NULL,
  `demo` tinyint(1) NOT NULL DEFAULT '0',
  `hide` tinyint(1) NOT NULL,
  `lock` tinyint(1) NOT NULL,
  `archive` tinyint(1) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `reference` varchar(64) NOT NULL,
  `softwares` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`),
  KEY `demo` (`demo`)
) ENGINE=MyISAM AUTO_INCREMENT=317 DEFAULT CHARSET=utf8;

INSERT INTO `saam_projects` VALUES 
('1','1','25','SEQ###_SHOT###','demo','[\"1\",\"2\",\"4\",\"5\",\"9\",\"12\",\"13\"]','1','Demo','DEMO','Documentaire sur les koalas en capture de mouvement ... ','Melville','[\"1\",\"2\",\"3\",\"4\",\"58\",\"72\",\"73\"]','LRDS','2012-07-11 00:00:00','2014-02-11','4','2015-07-30 00:00:00','1','1','0','0','0','0','REF_DEMO','[\"blender\",\"AfterEffect\",\"Maya\",\"Ardour\"]'),
('277','58','24','SEQ###_SHOT###','short','[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"7\",\"8\",\"9\",\"10\",\"11\",\"12\",\"13\",\"14\"]','6','Polo','Projet Test','test description du projet !','Karlova','[\"4\",\"58\",\"72\",\"73\"]','LRDS','2012-07-23 00:00:00','2014-02-15','4','2014-03-31 00:00:00','1','0','0','0','0','0','REF_teste','[\"blender\",\"Zbrush\",\"Ardour\"]');


-- ----------------- TABLE saam_relations ------------------------

DROP TABLE IF EXISTS `saam_relations`;

CREATE TABLE `saam_relations` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `master_table` varchar(64) NOT NULL,
  `master_column` varchar(64) NOT NULL,
  `link_type` varchar(64) DEFAULT NULL,
  `link_table` varchar(64) NOT NULL,
  `link_column` varchar(64) NOT NULL,
  `link_default_return` varchar(64) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;

INSERT INTO `saam_relations` VALUES 
('1','saam_assets','ID_creator','direct','saam_users','id','pseudo'),
('2','saam_assets','ID_handler','direct','saam_users','id','pseudo'),
('3','saam_assets','updated_by','direct','saam_users','id','pseudo'),
('4','saam_comments_asset','ID_asset','direct','saam_assets','id','filename'),
('5','saam_comments_asset','response_to','direct','saam_comments_asset','id','id'),
('6','saam_comments_shots','ID_shot','direct','saam_shots','id','title'),
('7','saam_comments_shots','response_to','direct','saam_comments_shots','id','id'),
('8','saam_shots_depts_infos','ID_shot','direct','saam_shots','id','title'),
('9','saam_shots_depts_infos','ID_project','direct','saam_projects','id','title'),
('10','saam_users','ID_creator','direct','saam_users','id','pseudo'),
('11','saam_news','ID_creator','direct','saam_users','id','pseudo'),
('12','saam_notes','ID_user','direct','saam_users','id','pseudo'),
('13','saam_projects','ID_creator','direct','saam_users','id','pseudo'),
('14','saam_projects','updated_by','direct','saam_users','id','pseudo'),
('15','saam_sequences','ID_creator','direct','saam_users','id','pseudo'),
('16','saam_sequences','ID_project','direct','saam_projects','id','title'),
('17','saam_sequences','updated_by','direct','saam_users','id','pseudo'),
('18','saam_shots','ID_creator','direct','saam_users','id','pseudo'),
('19','saam_shots','ID_project','direct','saam_projects','id','title'),
('20','saam_shots','ID_sequence','direct','saam_sequences','id','title'),
('21','saam_shots','supervisor','direct','saam_users','id','pseudo'),
('22','saam_shots','lead','direct','saam_users','id','pseudo'),
('23','saam_shots','equipe','json>val','saam_users','id','pseudo'),
('24','saam_assets','category','val>json','saam_config','assets_categories','assets_categories'),
('25','saam_assets','ID_shots','json>val','saam_shots','id','title'),
('26','saam_assets','team','json>val','saam_users','id','pseudo'),
('27','saam_assets','relations_assets','json>val','saam_assets','filename','filename'),
('28','saam_shots','tags','json>json','saam_config','global_tags','global_tags'),
('30','saam_sequences','supervisor','direct','saam_users','id','pseudo'),
('29','saam_shots','updated_by','direct','saam_users','id','pseudo'),
('32','saam_shots','CC_mouarf','direct','CT_testMulti','id','meuh'),
('33','saam_shots','CC_tcz','json>val','CT_nickel','id','TC-in'),
('34','saam_users','competences','json>json','saam_config','available_competences','available_competences'),
('35','saam_users','status','val>json','saam_config','user_status','user_status'),
('36','saam_scenes','assets','json>val','saam_assets','id','filename'),
('37','saam_scenes','master','direct','saam_scenes','id','title'),
('38','saam_scenes','derivatives','json>val','saam_scenes','id','title'),
('39','saam_scenes','ID_handler','direct','saam_users','id','pseudo'),
('40','saam_scenes','ID_creator','direct','saam_users','id','pseudo'),
('41','saam_scenes','supervisor','direct','saam_users','id','pseudo'),
('42','saam_scenes','lead','direct','saam_users','id','pseudo'),
('43','saam_scenes','equipe','json>val','saam_users','id','pseudo'),
('44','saam_scenes','updated_by','json>val','saam_users','id','pseudo'),
('45','saam_scenes','sequences','json>val','saam_sequences','id','title'),
('46','saam_scenes','shots','json>val','saam_shots','id','title'),
('47','saam_shots','ID_scene','direct','saam_scenes','id','title'),
('48','saam_cameras','ID_project','direct','saam_projects','id','title'),
('49','saam_cameras','ID_scene','direct','saam_scenes','id','title'),
('50','saam_cameras','ID_sequence','direct','saam_sequences','id','title'),
('51','saam_cameras','ID_shot','direct','saam_shots','id','title'),
('52','saam_cameras','ID_creator','direct','saam_users','id','pseudo'),
('53','saam_cameras','updated_by','direct','saam_users','id','pseudo');


-- ----------------- TABLE saam_scenes ------------------------

DROP TABLE IF EXISTS `saam_scenes`;

CREATE TABLE `saam_scenes` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `label` varchar(256) NOT NULL,
  `title` varchar(256) NOT NULL,
  `ID_creator` int(6) NOT NULL,
  `ID_handler` int(6) NOT NULL,
  `ID_project` int(4) NOT NULL,
  `sequences` text NOT NULL,
  `shots` text NOT NULL,
  `master` int(6) NOT NULL,
  `derivatives` text NOT NULL,
  `assets` text NOT NULL,
  `nb_frames` int(6) NOT NULL,
  `fps` int(3) NOT NULL,
  `description` text NOT NULL,
  `supervisor` int(6) NOT NULL,
  `lead` int(6) NOT NULL,
  `equipe` text NOT NULL,
  `review` text NOT NULL,
  `date` datetime NOT NULL,
  `update` datetime NOT NULL,
  `deadline` datetime NOT NULL,
  `updated_by` int(6) NOT NULL,
  `tags` text NOT NULL,
  `progress` int(3) NOT NULL,
  `hide` tinyint(1) NOT NULL,
  `lock` tinyint(1) NOT NULL,
  `archive` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ID_project` (`ID_project`),
  KEY `label` (`label`),
  KEY `title` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

INSERT INTO `saam_scenes` VALUES 
('1','M_SC_001','M_SC_001_PHARE_EXT_KF_MC','4','4','277','{\"10\":[353],\"12\":[378],\"13\":[400]}','{\"10\":[808,855],\"12\":[856],\"13\":[910]}','0','[10,12,13,14]','[\"13\",\"12\",\"16\",\"19\",\"18\",\"28\"]','2453','24','Une description super longue, même si je sais pertinemment que personne ne prendra / n\'aura le temps d\'écrire une description aussi longue... Pas comme certains, qui font n\'imp au lieu de coder (hein Polo). En tout cas celui qui lit cette description jusqu\'au bout c\'est un gros ouf, ou alors il a vraiment envie de se foutre de la gueule du Poloch\' ! YEAH','4','72','[\"4\",\"73\"]','','2013-12-14 01:33:49','2014-02-12 12:50:59','2014-01-18 12:38:54','4','','0','0','1','0'),
('2','M_SC_002','M_SC_002_|PHARE-INT_SEQ007_MARCHE|_KF','4','0','277','{\"11\":[378]}','{\"11\":[982]}','0','[11,15]','[\"39\",\"19\",\"24\",\"13\",\"18\"]','5423','24','erg zer zebztbe ','0','2','[\"2\",\"4\",\"58\"]','','2014-01-09 16:02:10','2014-02-01 00:39:10','2014-01-24 16:02:16','4','','0','0','0','0'),
('3','M_SC_003','M_SC_003_PHARE_INT_KF','4','0','277','','','0','','[\"40\"]','3214','24','srtgh etn etyn','0','4','[\"4\",\"58\",\"72\"]','','0000-00-00 00:00:00','2014-01-25 01:24:07','0000-00-00 00:00:00','4','','0','0','0','0'),
('4','M_SC_004','M_SC_004_PHARE_INT_KF','4','0','277','','','0','','[\"17\"]','0','24','','0','0','','','0000-00-00 00:00:00','2014-01-23 19:08:30','0000-00-00 00:00:00','4','','0','0','0','0'),
('10','#_SC_001_D_001','#_SC_001_D_001_PHARE_EXT_KF_MC','4','0','277','[353]','[808,855]','1','','[\"12\",\"18\"]','0','0','Test de dérivée number one !','2','4','[\"4\",\"73\"]','','2014-01-10 00:00:00','2014-02-12 13:08:13','2014-01-14 00:00:00','73','','0','0','0','0'),
('11','#_SC_002_D_001','#_SC_002_D_001_|PHARE-INT_SEQ007_MARCHE|_KF','4','0','277','[378]','[982]','2','','[]','0','0','test add derivée number TWO !','2','4','[\"2\",\"4\",\"58\"]','','2014-01-10 00:00:00','2014-02-01 00:20:15','2014-01-24 00:00:00','4','','0','0','0','0'),
('12','#_SC_001_D_002','#_SC_001_D_002_PHARE_EXT_KF_MC','4','0','277','[378]','[856]','1','','','0','0','test blah blah','2','4','[\"4\",\"73\"]','','2014-01-10 00:00:00','2014-02-12 12:51:14','2014-01-14 00:00:00','4','','0','0','0','0'),
('13','#_SC_001_D_003','#_SC_001_D_003_PHARE_EXT_KF_MC','4','0','277','[400]','[910]','1','','','0','0','blah blah gniuk gniuk man !!','2','4','[\"4\",\"73\"]','','2014-01-10 00:00:00','2014-02-12 12:51:22','2014-01-14 00:00:00','4','','0','0','0','0'),
('14','#_SC_001_D_004','#_SC_001_D_004_PHARE_EXT_KF_MC','4','0','277','','','1','','','0','0','','0','0','','','2014-01-17 00:00:00','2014-01-17 17:50:04','2014-01-18 00:00:00','4','','0','0','0','1'),
('15','#_SC_002_D_002','#_SC_002_D_002_|PHARE-INT_SEQ007_MARCHE|_KF','4','0','277','[]','[]','2','','','0','0','Test from MASTER modal','2','4','[\"2\",\"4\",\"58\"]','','2014-01-23 00:00:00','2014-02-01 00:39:10','2014-01-24 00:00:00','4','','0','0','0','0'),
('28','M_SC_005','M_SC_005_BLAH','4','0','277','','','0','','','0','0','','0','0','','','2014-02-01 00:00:00','2014-02-01 01:23:06','2014-02-15 00:00:00','4','','0','0','0','0'),
('29','M_SC_006','M_SC_006_|YO|','4','0','277','','','0','','','0','0','','0','0','','','2014-02-01 00:00:00','2014-02-01 01:23:20','2014-02-15 00:00:00','4','','0','0','0','0'),
('30','M_SC_007','M_SC_007_|ZAWAA|','4','0','277','','','0','','','0','0','','0','0','','','2014-02-01 00:00:00','2014-02-01 01:23:32','2014-02-15 00:00:00','4','','0','0','0','0'),
('31','M_SC_008','M_SC_008_|HEIGHTONE|','4','0','277','','','0','','','0','0','','0','0','','','2014-02-01 00:00:00','2014-02-05 23:20:18','2014-02-15 00:00:00','4','','0','0','0','0'),
('32','M_SC_009','M_SC_009_|OUYEAH|','4','0','277','','','0','','','0','0','','0','0','','','2014-02-01 00:00:00','2014-02-01 01:24:05','2014-02-15 00:00:00','4','','0','0','0','0'),
('33','M_SC_010','M_SC_010_|GNIUKGNIUK|','4','0','277','','','0','','','0','0','','0','0','','','2014-02-01 00:00:00','2014-02-01 01:24:19','2014-02-15 00:00:00','4','','0','0','0','0'),
('34','M_SC_011','M_SC_011_|LASTONE|','4','0','277','{\"35\":[416]}','{\"35\":[964]}','0','[35]','','0','0','','0','0','','','2014-02-01 00:00:00','2014-02-01 01:25:09','2014-02-15 00:00:00','4','','0','0','0','0'),
('35','#_SC_011_D_001','#_SC_011_D_001_|LASTONE|','4','0','277','[416]','[964]','34','','','0','0','','0','0','','','2014-02-01 00:00:00','2014-02-01 01:25:09','2014-02-15 00:00:00','4','','0','0','0','0');


-- ----------------- TABLE saam_scenes_depts_infos ------------------------

DROP TABLE IF EXISTS `saam_scenes_depts_infos`;

CREATE TABLE `saam_scenes_depts_infos` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `ID_project` int(4) NOT NULL,
  `ID_scene` int(6) NOT NULL,
  `9` varchar(256) NOT NULL,
  `10` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `saam_scenes_depts_infos` VALUES 
('1','277','1','{\"sceneStep\":0,\"retake\":false}','{\"sceneStep\":0,\"retake\":false}'),
('3','277','31','{\"sceneStep\":0}',''),
('4','277','12','{\"sceneStep\":0,\"retake\":false}',''),
('5','277','10','{\"sceneStep\":0,\"retake\":false}','');


-- ----------------- TABLE saam_sequences ------------------------

DROP TABLE IF EXISTS `saam_sequences`;

CREATE TABLE `saam_sequences` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `label` varchar(256) NOT NULL,
  `title` varchar(256) NOT NULL,
  `description` text NOT NULL,
  `ID_creator` int(4) NOT NULL,
  `ID_project` int(5) NOT NULL,
  `date` datetime NOT NULL,
  `deadline` datetime NOT NULL,
  `supervisor` varchar(256) NOT NULL,
  `lead` varchar(256) NOT NULL,
  `position` int(9) NOT NULL,
  `reference` varchar(256) NOT NULL,
  `update` date NOT NULL,
  `updated_by` int(6) NOT NULL,
  `progress` int(3) NOT NULL,
  `hide` tinyint(1) NOT NULL,
  `lock` tinyint(1) NOT NULL,
  `archive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ID_project` (`ID_project`),
  KEY `label` (`label`),
  KEY `title` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=436 DEFAULT CHARSET=utf8;

INSERT INTO `saam_sequences` VALUES 
('1','SEQ001','SEQ001','Présentation du koala','4','1','2012-07-10 00:00:00','2013-07-25 00:00:00','','Karlova,Polo','1','','2012-08-06','0','5','0','0','0'),
('2','SEQ002','SEQ002','Le Koala en langue Aborigène veut dire: \'Qui  ne boit jamais\'','4','1','2012-07-10 00:00:00','2013-08-22 00:00:00','','Karlova,Polo','2','','2012-08-06','0','0','0','0','0'),
('3','SEQ003','SEQ003','Le Koala aime dormir, et ne se déplace que rarement dans l\'année ... il faut pas ewagéré non plus !!!','4','1','2012-07-10 00:00:00','2013-10-24 00:00:00','','Karlova,Polo','3','','2012-08-06','0','0','0','0','0'),
('4','SEQ004','SEQ004','Le Koala ne veut pas qu\'on coupe ses poils','4','1','2012-07-10 00:00:00','2013-05-14 00:00:00','','Karlova,Moutew,Polo,Riton','4','','2012-08-08','0','0','0','0','0'),
('5','SEQ005','SEQ005','Le Koala doit boire un jour. Et là ...','4','1','2012-07-10 00:00:00','2012-11-21 00:00:00','','Karlova,Polo','5','','2012-08-08','0','0','0','0','0'),
('353','SEQ001','S01','pourquoi donc ? Bonne question...','10','277','2012-07-26 00:00:00','2013-12-31 00:00:00','2','Yann','1','','2012-08-05','0','11','0','0','0'),
('378','SEQ002','S02','','4','277','2012-08-12 00:00:00','2013-12-31 00:00:00','58','Caul360','2','','2012-08-12','0','7','0','0','0'),
('379','SEQ003','S03','','4','277','2012-08-12 00:00:00','2013-12-25 00:00:00','4','Caul360','3','','2012-08-12','0','0','1','0','0'),
('397','SEQ004','S04','','4','277','2013-10-17 00:00:00','2013-12-31 00:00:00','','Karlova,Polo','4','','2013-02-01','0','0','0','0','1'),
('398','SEQ005','S05','','4','277','2013-10-17 00:00:00','2013-12-31 00:00:00','','Karlova,Polo,Yann','5','','2013-02-01','0','0','0','0','1'),
('399','SEQ006','S06','','4','277','2013-10-17 00:00:00','2013-12-31 00:00:00','','Benoît','6','','2013-02-01','0','0','0','0','1'),
('400','SEQ007','S07','description','4','277','2013-02-01 00:00:00','2013-12-31 00:00:00','','null','7','','2013-11-18','0','2','0','0','0'),
('401','SEQ008','S08','','4','277','2013-02-04 00:00:00','2013-12-31 00:00:00','','Karlova','8','','2013-02-04','0','1','0','0','0'),
('402','SEQ009','S09','','4','277','2013-02-04 00:00:00','2013-12-31 00:00:00','','Benoît','9','','2013-02-04','0','0','0','0','0'),
('414','SEQ001','SEQ001','','4','306','2013-02-22 00:00:00','2013-02-28 00:00:00','','','1','','2013-02-22','0','0','0','0','0'),
('416','SEQ010','S10','','4','277','2013-05-23 00:00:00','2013-12-31 00:00:00','','Karlova,Polo','10','','2013-05-23','0','0','0','0','0'),
('423','SEQ011','S11','Un za qui wah fort','4','277','2013-10-07 00:00:00','2013-12-31 00:00:00','3','Polo','11','test11','2013-10-07','0','0','0','1','1'),
('428','SEQ001','SEQ001','','4','313','2014-02-05 00:00:00','2014-02-14 00:00:00','','','1','','2014-02-05','0','0','0','0','0');


-- ----------------- TABLE saam_shots ------------------------

DROP TABLE IF EXISTS `saam_shots`;

CREATE TABLE `saam_shots` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `ID_sequence` int(9) NOT NULL,
  `ID_scene` int(6) NOT NULL,
  `ID_camera` int(6) NOT NULL,
  `title` varchar(256) NOT NULL,
  `label` varchar(256) NOT NULL,
  `ID_creator` int(6) NOT NULL,
  `ID_project` int(5) NOT NULL,
  `position` int(12) NOT NULL,
  `nbframes` int(8) NOT NULL,
  `description` text NOT NULL,
  `supervisor` int(6) NOT NULL,
  `lead` int(6) NOT NULL,
  `equipe` varchar(256) NOT NULL,
  `date` datetime NOT NULL,
  `update` datetime NOT NULL,
  `updated_by` int(6) NOT NULL,
  `deadline` datetime NOT NULL,
  `hide` tinyint(1) NOT NULL,
  `lock` tinyint(1) NOT NULL,
  `archive` tinyint(1) NOT NULL DEFAULT '0',
  `progress` int(3) NOT NULL,
  `reference` varchar(50) NOT NULL,
  `tags` text NOT NULL,
  `fps` int(4) NOT NULL,
  `1` varchar(256) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ID_sequence` (`ID_sequence`),
  KEY `label` (`label`),
  KEY `title` (`title`),
  KEY `ID_project` (`ID_project`)
) ENGINE=MyISAM AUTO_INCREMENT=1026 DEFAULT CHARSET=utf8;

INSERT INTO `saam_shots` VALUES 
('6','1','0','0','last one','SHOT006','4','1','6','0','','0','0','[\"2\",\"4\"]','2012-08-01 00:00:00','2014-02-05 15:26:36','4','2012-12-12 00:00:00','0','0','0','0','','','0',''),
('5','1','0','0','fifth shot','SHOT005','4','1','5','0','','0','0','[\"3\"]','2012-08-01 00:00:00','2014-02-05 15:26:36','4','2012-10-31 00:00:00','0','0','0','0','','','0',''),
('4','1','0','0','test shot 4','SHOT004','4','1','4','0','','0','0','[]','2012-08-13 00:00:00','2014-02-05 15:26:36','4','2012-08-31 00:00:00','0','0','0','0','','','25',''),
('3','1','0','0','blabla','SHOT003','4','1','3','0','','0','0','[\"2\",\"4\"]','2012-08-05 00:00:00','2014-02-05 15:26:36','4','2012-10-15 00:00:00','0','0','0','0','','','0',''),
('2','1','0','0','The shot','SHOT002','4','1','2','2500','','0','0','[\"2\",\"3\",\"4\"]','2012-08-03 00:00:00','2014-02-05 15:26:36','4','2012-08-29 00:00:00','0','0','0','20','','[\"Stable\"]','0',''),
('7','2','0','0','','SHOT001','4','1','9','0','','0','0','[]','0000-00-00 00:00:00','2014-02-05 15:26:36','4','0000-00-00 00:00:00','0','0','0','0','','','0',''),
('11','2','0','0','','SHOT005','4','1','11','0','','0','0','[]','0000-00-00 00:00:00','2014-02-05 15:26:36','4','0000-00-00 00:00:00','0','0','0','0','','','0',''),
('10','2','0','0','','SHOT004','4','1','7','0','','0','0','[]','0000-00-00 00:00:00','2014-02-05 15:26:36','4','0000-00-00 00:00:00','0','0','0','0','','','0',''),
('9','2','0','0','','SHOT003','4','1','10','0','','0','0','[]','0000-00-00 00:00:00','2014-02-05 15:26:36','4','0000-00-00 00:00:00','0','0','0','0','','','0',''),
('8','2','0','0','','SHOT002','4','1','8','0','','0','0','[]','0000-00-00 00:00:00','2014-02-05 15:26:36','4','0000-00-00 00:00:00','0','0','0','0','','','0',''),
('12','3','0','0','','SHOT001','4','1','1','0','','0','0','[]','0000-00-00 00:00:00','2014-02-05 15:26:36','4','0000-00-00 00:00:00','0','0','0','0','','','0',''),
('15','3','0','0','','SHOT004','4','1','4','0','','0','0','[]','0000-00-00 00:00:00','2014-02-05 15:26:36','4','0000-00-00 00:00:00','0','0','0','0','','','0',''),
('14','3','0','0','','SHOT003','4','1','3','0','','0','0','[]','0000-00-00 00:00:00','2014-02-05 15:26:36','4','0000-00-00 00:00:00','0','0','0','0','','','0',''),
('13','3','0','0','gniuk gniuk','SHOT002','4','1','2','0','','0','0','[\"2\"]','2012-08-01 00:00:00','2014-02-05 15:26:36','4','2012-08-31 00:00:00','0','0','0','0','','','0',''),
('1','1','0','0','Plan 001','SHOT001','4','1','1','9874','FX Koala Furs to Koala Mécanik','0','0','[\"2\",\"4\"]','2012-08-01 00:00:00','2014-02-10 14:32:34','4','2013-05-15 00:00:00','0','0','0','12','','[\"Need review\",\"Planche Storyboard\"]','25',''),
('16','4','0','0','title SHOT001','SHOT001','4','1','1','0','','0','0','[]','0000-00-00 00:00:00','2014-02-05 15:26:36','4','0000-00-00 00:00:00','0','0','0','0','','','0',''),
('17','4','0','0','title SHOT002','SHOT002','4','1','2','0','','0','0','[]','0000-00-00 00:00:00','2014-02-05 15:26:36','4','0000-00-00 00:00:00','0','0','0','0','','','0',''),
('18','4','0','0','title SHOT003','SHOT003','4','1','3','0','','0','0','[]','0000-00-00 00:00:00','2014-02-05 15:26:36','4','0000-00-00 00:00:00','0','0','0','0','','','0',''),
('19','5','0','0','title SHOT001','SHOT001','4','1','1','1500','','0','0','[\"2\",\"4\"]','2012-08-01 00:00:00','2014-02-05 15:26:36','4','2014-08-30 00:00:00','0','0','0','0','','','0',''),
('20','5','0','0','title SHOT002','SHOT002','4','1','2','0','','0','0','[\"4\"]','2012-08-01 00:00:00','2014-02-05 15:26:36','4','2013-05-30 00:00:00','0','0','0','0','','','0',''),
('808','353','10','7','Shot_01','SHOT001','0','277','1','540','Une petite description du délire, ça peut pas faire de mal, ça peut même s\'avérer vital, nom d\'un chien (ou d\'un cheval) !','4','2','[\"2\",\"3\",\"4\"]','2014-02-06 00:00:00','2014-02-05 15:26:36','4','2014-02-28 00:00:00','0','0','0','12','','[\"#FT_special Polo\"]','25',''),
('855','353','10','9','testShot mod','SHOT002','4','277','2','2256','Et hop là !','2','4','[\"4\"]','2012-08-01 00:00:00','2014-02-05 15:26:36','4','2013-08-31 00:00:00','0','0','0','20','','[\"Need review\",\"Stable\"]','0',''),
('856','378','12','0','shot test','SHOT001','4','277','1','124','','0','0','[\"2\",\"4\"]','2012-08-01 00:00:00','2014-02-05 15:26:36','4','2014-07-24 00:00:00','0','0','0','6','','[\"Need review\",\"Planche Storyboard\"]','0',''),
('857','379','0','0','title SHOT001','SHOT001','4','277','5','124','','0','0','[\"2\",\"4\",\"58\"]','0000-00-00 00:00:00','2014-02-05 15:26:36','4','0000-00-00 00:00:00','0','0','0','0','','[\"Planche Storyboard\",\"Dépouillement MOCAP\"]','0',''),
('858','379','0','0','the shot at the end','SHOT002','4','277','6','124','','0','0','[]','2012-08-01 00:00:00','2014-02-05 15:26:36','4','2012-08-25 00:00:00','0','0','0','0','','[\"Planche Storyboard\",\"Dépouillement MOCAP\"]','0',''),
('908','400','0','0','oopsyeah1','SHOT001','4','277','2','124','','0','0','[\"2\",\"4\"]','2013-02-05 00:00:00','2014-02-05 15:26:36','4','2013-05-31 00:00:00','0','0','0','3','','','0',''),
('909','400','0','0','egerg','SHOT002','4','277','4','124','','0','0','[\"2\"]','2013-02-06 00:00:00','2014-02-05 15:26:36','4','2013-02-27 00:00:00','0','0','0','20','','','0',''),
('910','400','13','0','bla','SHOT003','4','277','3','124','','0','0','[]','2013-02-05 00:00:00','2014-02-05 15:26:36','4','2013-02-07 00:00:00','0','0','0','0','','','0',''),
('911','400','0','0','bli','SHOT004','4','277','5','124','','0','0','[]','2013-02-06 00:00:00','2014-02-05 15:26:36','4','2013-02-14 00:00:00','0','0','0','0','','','0',''),
('912','400','0','0','S7P1za','SHOT001','4','277','5','124','','0','0','[]','2013-11-17 00:00:00','2014-02-05 15:26:37','4','2013-11-17 00:00:00','0','0','0','3','','','0',''),
('913','401','0','0','yeah','SHOT002','4','277','6','124','','0','0','[]','2013-05-25 00:00:00','2014-02-05 15:26:37','4','2013-05-25 00:00:00','0','0','0','0','','','0',''),
('914','401','0','0','srtg','SHOT003','4','277','4','124','','0','0','[]','0000-00-00 00:00:00','2014-02-05 15:26:37','4','0000-00-00 00:00:00','0','0','0','0','','','0',''),
('915','402','0','0','title SHOT001','SHOT001','4','277','2','124','','0','0','[]','0000-00-00 00:00:00','2014-02-05 15:26:37','4','0000-00-00 00:00:00','0','0','0','0','','','0',''),
('916','402','0','0','yeah','SHOT002','4','277','1','124','','0','0','[]','2013-02-05 00:00:00','2014-02-05 15:26:37','4','2013-02-07 00:00:00','0','0','0','0','','','0',''),
('917','402','0','0','man','SHOT003','4','277','3','124','','0','0','[]','2013-02-11 00:00:00','2014-02-05 15:26:37','4','2013-02-14 00:00:00','0','0','0','0','','','0',''),
('952','414','0','0','title SHOT002','SHOT002','4','306','2','0','','0','0','','2013-02-22 00:00:00','2013-02-22 00:00:00','0','2013-02-28 00:00:00','0','0','0','0','','','0',''),
('953','414','0','0','ertyerty','SHOT003','4','306','3','0','','0','0','','2013-02-22 00:00:00','2013-02-22 00:00:00','0','0000-00-00 00:00:00','0','0','0','0','','','0',''),
('951','414','0','0','title SHOT001','SHOT001','4','306','1','0','','0','0','','2013-02-22 00:00:00','2013-02-22 00:00:00','0','2013-02-28 00:00:00','0','0','0','0','','','0',''),
('954','414','0','0','','SHOT004','4','306','4','0','','0','0','','0000-00-00 00:00:00','2013-02-22 00:00:00','0','0000-00-00 00:00:00','0','0','0','0','','','0',''),
('955','414','0','0','SHOT005','SHOT005','4','306','5','0','','0','0','','2013-02-22 00:00:00','2013-02-22 00:00:00','0','2013-02-28 00:00:00','0','0','0','0','','','0',''),
('956','414','0','0','SHOT006','SHOT006','4','306','6','0','','0','0','','2013-02-22 00:00:00','2013-02-22 00:00:00','0','2013-02-28 00:00:00','0','0','0','0','','','0',''),
('957','414','0','0','SHOT007','SHOT007','4','306','7','0','','0','0','','2013-02-22 00:00:00','2013-02-22 00:00:00','0','2013-02-28 00:00:00','0','0','0','0','','','0',''),
('958','414','0','0','SHOT008','SHOT008','4','306','8','0','','0','0','','2013-02-22 00:00:00','2013-02-22 00:00:00','0','2013-02-28 00:00:00','0','0','0','0','','','0',''),
('959','414','0','0','SHOT009','SHOT009','4','306','9','0','','0','0','','2013-02-22 00:00:00','2013-02-22 00:00:00','0','2013-02-28 00:00:00','0','0','0','0','','','0',''),
('960','414','0','0','SHOT010','SHOT010','4','306','10','0','','0','0','','2013-02-22 00:00:00','2013-02-22 00:00:00','0','2013-02-28 00:00:00','0','0','0','0','','','0',''),
('961','414','0','0','SHOT011','SHOT011','4','306','11','0','','0','0','','2013-02-22 00:00:00','2013-02-22 00:00:00','0','2013-02-28 00:00:00','0','0','0','0','','','0',''),
('964','416','35','0','title SHOT001','SHOT001','4','277','3','540','','0','0','[]','2013-05-23 00:00:00','2014-02-05 15:26:37','4','2013-08-22 00:00:00','0','0','0','0','','','0',''),
('981','353','0','0','testZaaW','SHOT003','4','277','3','543','un essai d\'ajout de shot depuis le dept. \"Prod\" !','4','3','[\"4\"]','2013-10-07 00:00:00','2014-02-05 15:26:37','4','2013-10-25 00:00:00','0','0','0','6','','[\"#FT_special Polo\"]','0',''),
('982','378','11','23','shot test 2','SHOT054','4','277','11','6542','nom d\'un ptit chien chien','2','58','[\"73\",\"4\"]','2012-05-10 00:00:00','2014-02-10 14:41:53','4','2013-08-08 00:00:00','0','0','0','9','','[\"#BA_special polo\"]','0',''),
('983','353','0','0','zertzert','SHOT006','4','277','11','6542','srtyy stht rst','4','2','[\"2\",\"4\"]','0000-00-00 00:00:00','2014-02-05 15:26:37','4','0000-00-00 00:00:00','0','0','0','6','','[\"Stable\",\"#FT_special Polo\"]','0',''),
('984','400','0','0','zaw','SHOT006','4','277','6','0','','0','0','[]','2013-10-25 00:00:00','2014-02-05 15:26:37','4','2013-10-26 00:00:00','0','0','0','0','','','24',''),
('985','400','0','0','rma','SHOT007','4','277','7','0','','0','0','[]','2013-10-25 00:00:00','2014-02-05 15:26:37','4','2013-10-26 00:00:00','0','0','0','0','','','24',''),
('986','400','0','0','zou','SHOT008','4','277','8','0','','0','0','[]','2013-10-25 00:00:00','2014-02-05 15:26:37','4','2013-10-26 00:00:00','0','0','0','0','','','24',''),
('987','400','0','0','fli','SHOT009','4','277','9','0','','0','0','[]','2013-10-25 00:00:00','2014-02-05 15:26:37','4','2013-10-26 00:00:00','0','0','0','0','','','24',''),
('988','400','0','0','tac','SHOT010','4','277','10','0','','0','0','[]','2013-10-25 00:00:00','2014-02-05 15:26:37','4','2013-10-26 00:00:00','0','0','0','0','','','24',''),
('1003','428','0','0','title SHOT001','SHOT001','4','313','1','0','','0','0','','2014-02-05 00:00:00','2014-02-05 21:06:14','4','2014-02-14 00:00:00','0','0','0','0','','','0','');


-- ----------------- TABLE saam_shots_depts_infos ------------------------

DROP TABLE IF EXISTS `saam_shots_depts_infos`;

CREATE TABLE `saam_shots_depts_infos` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `ID_project` int(6) NOT NULL,
  `ID_shot` int(6) NOT NULL,
  `scenario` text NOT NULL,
  `dectech` text NOT NULL,
  `storyboard` text NOT NULL,
  `sound` text NOT NULL,
  `2` varchar(256) NOT NULL,
  `3` varchar(256) NOT NULL,
  `4` varchar(256) NOT NULL,
  `5` varchar(256) NOT NULL,
  `6` varchar(256) NOT NULL,
  `7` varchar(256) NOT NULL,
  `8` varchar(256) NOT NULL,
  `1` varchar(256) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ID_shot` (`ID_shot`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

INSERT INTO `saam_shots_depts_infos` VALUES 
('1','1','1','','{\"fps\":25}','{\"fps\":25}','{\"clock\":48000,\"fps\":25}','{\"fps\":25}','{\"fps\":\"30\",\"startF\":\"155\",\"endF\":\"3456\"}','{\"fps\":\"25\",\"startF\":\"155\",\"endF\":\"7560\",\"retake\":true}','{\"fps\":25}','{\"fps\":25}','','',''),
('2','1','2','','','','','{\"fps\":\"25\"}','{\"fps\":25}','{\"fps\":\"25\",\"startF\":\"150\",\"endF\":\"250\"}','{\"fps\":\"25\"}','{\"fps\":\"25\"}','','',''),
('3','1','4','','','','','','','{\"retake\":true,\"fps\":\"25\"}','{\"fps\":25}','','','',''),
('5','277','808','','','','','','','{\"fps\":\"25\",\"shotStep\":2,\"retake\":false,\"startF\":\"1\",\"endF\":\"533\",\"anims\":{\"nRetake\":6}}','','{\"compositing\":{\"nRetake\":1},\"fps\":\"25\",\"retake\":false}','','','{\"retake\":false}'),
('7','277','855','','','','','','','{\"shotStep\":2,\"fps\":\"25\",\"retake\":true}','','{\"fps\":25,\"shotStep\":3}','','','{\"retake\":false}'),
('13','277','908','','','{\"retake\":false}','','','','{\"fps\":25}','','','','',''),
('12','277','856','','','{\"retake\":true}','','','','{\"fps\":\"25\",\"retake\":false}','','','','','{\"retake\":false}'),
('14','277','909','','','','','{\"fps\":25}','{\"fps\":25}','{\"fps\":25}','{\"fps\":25}','{\"fps\":25}','{\"fps\":25}','{\"fps\":25}',''),
('15','277','912','','','','','{\"fps\":25}','','','','','','',''),
('16','277','964','','','{\"retake\":false}','','','','','','','','',''),
('17','311','979','','','','','{\"fps\":25}','','{\"fps\":25}','','','','',''),
('19','311','980','','','{\"retake\":true}','','','','','','','','',''),
('20','277','981','','','','','','','{\"fps\":24,\"retake\":false}','','','','','{\"retake\":false}'),
('21','277','983','','','','','','','{\"retake\":false}','','','','','{\"retake\":false}'),
('22','277','982','','','{\"retake\":false}','','','','{\"retake\":false}','{\"retake\":false}','','','','{\"retake\":false}'),
('23','312','989','','','','','','','{\"fps\":\"24\",\"retake\":false}','','','','','');


-- ----------------- TABLE saam_users ------------------------

DROP TABLE IF EXISTS `saam_users`;

CREATE TABLE `saam_users` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(256) DEFAULT NULL,
  `login` varchar(25) NOT NULL,
  `passwd` varchar(256) NOT NULL,
  `nom` varchar(256) NOT NULL,
  `prenom` varchar(256) NOT NULL,
  `status` int(2) DEFAULT NULL,
  `competences` text NOT NULL,
  `mail` varchar(255) NOT NULL,
  `vcard` text NOT NULL,
  `lang` varchar(25) NOT NULL,
  `theme` varchar(25) NOT NULL,
  `receiveMails` tinyint(1) NOT NULL DEFAULT '0',
  `receiveNotifs` tinyint(1) NOT NULL,
  `my_projects` text NOT NULL,
  `my_dpts` text NOT NULL,
  `my_sequences` text NOT NULL,
  `my_shots` text NOT NULL,
  `my_scenes` text NOT NULL,
  `my_assets` text NOT NULL,
  `my_tags` text NOT NULL,
  `my_msgs` text NOT NULL,
  `ID_creator` int(6) DEFAULT NULL,
  `date_inscription` int(11) NOT NULL,
  `date_last_connexion` int(10) NOT NULL,
  `date_last_action` int(10) NOT NULL,
  `deconx_time` int(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`)
) ENGINE=MyISAM AUTO_INCREMENT=86 DEFAULT CHARSET=utf8;

INSERT INTO `saam_users` VALUES 
('4','Polo','polosson','670bd210128c4256c0b39c161a1dccb7','MAILLARDET','Paul','9','[\"soundTech\",\"artist3D\",\"coder\",\"soundMix\"]','polo@polosson.com','','fr','dark','1','1','[\"1\",\"277\"]','','','[\"1\",\"2\",\"3\",\"6\",\"19\",\"20\",\"808\",\"855\",\"856\",\"857\",\"908\",\"981\",\"983\",\"982\"]','[\"2\",\"3\",\"11\",\"15\",\"1\",\"10\",\"12\",\"13\"]','[\"18\",\"19\",\"20\",\"21\",\"22\",\"23\",\"24\",\"26\",\"27\",\"28\",\"38\",\"13\",\"14\",\"12\",\"30\",\"51\"]','[\"#FT_special Polo\",\"D\\u00e9pouillement MOCAP\",\"Planche Storyboard\"]','','2','1337273676','1393023237','1393034232','160'),
('2','Karlova','vincseize','670bd210128c4256c0b39c161a1dccb7','POTTIER','Charles','9','[\"director\",\"scenarist\",\"artist2D\",\"artist3D\",\"coder\"]','vincseize@gmail.com','','fr','dark','1','0','[\"1\"]','','','[\"1\",\"2\",\"3\",\"6\",\"13\",\"19\",\"808\",\"856\",\"857\",\"908\",\"909\",\"983\"]','[\"2\",\"11\",\"15\"]','[\"19\",\"21\",\"23\",\"24\",\"28\",\"38\"]','[\"D\\u00e9pouillement MOCAP\",\"Planche Storyboard\",\"charles one\",\"charles two\"]','','2','1337273676','1385228107','1385246200','30'),
('3','Moutew','moutew','02eb6c80b85216d62038f7491e33c0b8','DI MARTINO','Mathieu','8','[\"cameraman\",\"lightTech\",\"coder\",\"VFX\"]','mathieu@d2mphotos.fr','','fr','dark','1','0','[\"1\"]','','','[\"2\",\"5\",\"808\"]','[]','[]','','','2','1337273676','1387495484','1387501486','30'),
('1','Demo','demo','d32bb9c982791415b53df04aa0357d42','DEGUN','Demonstration','2','[\"director\",\"scenarist\",\"cameraman\",\"lightTech\",\"soundTech\",\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\",\"soundMix\"]','','','fr','dark','0','0','[\"1\"]','','','[]','[]','[]','','','2','1337273676','1378240336','1378242472','30'),
('72','superviseur','superviseur','d7f2bb5fe499b7324b3ab3b9560931c1','Viseur','Super','5','[\"director\",\"lightTech\",\"artist3D\",\"editor\"]','lrds@lerevedelasalamandre.net','','fr','dark','0','0','[\"1\",\"277\"]','','','[]','[\"3\"]','[\"51\"]','','','4','1374676194','1391811072','1391812949','30'),
('73','Artiste','artiste','35db7e2ae670a085547c4ec0e8a784d2','Tiste','Art','3','[\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\"]','lrds@lerevedelasalamandre.net','','fr','dark','0','0','[\"1\",\"277\"]','','','[\"982\"]','[\"1\",\"10\",\"12\",\"13\"]','[\"13\",\"14\",\"12\",\"30\",\"51\"]','','','4','1374676261','1392898104','1392901293','30'),
('58','debug','debug','924b34c19c39beabd0f5fb367d414fcd','bug','de','3','[\"producer\",\"assistantProd\"]','test@debug.org','','en','dark','0','0','[\"1\",\"277\"]','','','[\"857\"]','[\"2\",\"3\",\"11\",\"15\"]','[\"51\"]','','','4','1344977557','1384821556','1384823099','30');


