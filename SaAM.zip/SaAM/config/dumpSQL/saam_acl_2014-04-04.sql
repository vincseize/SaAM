
-- BACKUP BASE DE DONNÉES -- 
-- DATE (AA-MM-JJ): 2014-04-04 
-- FAITE PAR : MAILLARDET
-- 068e3504a03224b5832de5f9d29385eb 

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- ----------------- TABLE saam_acl ------------------------

DROP TABLE IF EXISTS `saam_acl`;

CREATE TABLE `saam_acl` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `grp_name` varchar(64) NOT NULL,
  `1` varchar(8) NOT NULL,
  `2` varchar(8) NOT NULL,
  `3` varchar(8) NOT NULL,
  `4` varchar(8) NOT NULL,
  `5` varchar(8) NOT NULL,
  `6` varchar(8) NOT NULL,
  `7` varchar(8) NOT NULL,
  `8` varchar(8) NOT NULL,
  `9` varchar(8) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `grp_name` (`grp_name`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

INSERT INTO `saam_acl` VALUES 
('1','VIEW_TOOLS_BTNS_ADMIN','N','A','N','N','A','A','A','A','A'),
('2','VIEW_TOOLS_BTNS_NOTES','N','A','A','A','A','A','A','A','A'),
('3','VIEW_TOOLS_BTNS_SCRIPT','N','A','A','A','A','A','A','A','A'),
('4','VIEW_TOOLS_BTNS_PLUGINS','N','N','A','A','A','A','A','A','A'),
('5','VIEW_TOOLS_BTNS_DEV','N','N','N','N','N','N','N','A','A'),
('6','VIEW_TOOLS_CAL','A','A','A','A','A','A','A','A','A'),
('7','VIEW_HEADER_BTN_PREF','N','A','A','A','A','A','A','A','A'),
('8','VIEW_HEADER_BTN_WIP','N','N','N','N','N','N','N','A','A'),
('9','VIEW_HEADER_SEARCH','N','A','A','A','A','A','A','A','A'),
('10','VIEW_HEADER_JCHAT','N','N','A','A','A','N','N','A','A'),
('11','VIEW_BANK_BTN_DEL','N','N','N','A','A','N','N','A','A'),
('12','VIEW_TOOLS_BTNS_BUGHUNTER','N','N','A','A','A','A','A','A','A'),
('13','VIEW_DEPT_PROD','N','N','N','N','N','A','A','A','A'),
('14','VIEW_DEPT_STRUCTURE','N','N','N','N','A','A','A','A','A'),
('15','SHOTS_ADMIN','N','N','N','N','A','N','A','A','A'),
('16','SHOTS_PUBLISH','N','A','O','O','A','N','A','A','A'),
('17','SHOTS_MESSAGE','N','A','O','O','A','N','A','A','A'),
('18','SHOTS_TAGS','N','A','O','O','A','N','A','A','A'),
('19','SHOTS_DEPTS_INFOS','N','A','O','O','A','N','A','A','A'),
('20','SHOTS_UPLOAD','N','A','O','O','A','N','A','A','A'),
('21','ASSETS_ADMIN','N','N','N','N','A','N','A','A','A'),
('23','ASSETS_MESSAGE','N','A','O','O','A','N','A','A','A'),
('24','ASSETS_PUBLISH','N','A','O','O','A','N','A','A','A'),
('25','ASSETS_TAGS','N','A','O','O','A','N','A','A','A'),
('26','ASSETS_UPLOAD','N','A','O','O','A','N','A','A','A'),
('27','ASSETS_HANDLE','N','N','O','O','A','N','A','A','A'),
('28','ASSETS_REVIEW_ASK','N','N','O','O','A','N','N','A','A'),
('29','ASSETS_REVIEW_VALID','N','N','N','N','O','N','N','A','A'),
('30','SCENES_ADMIN','N','N','N','N','A','A','A','A','A'),
('31','SCENES_HANDLE','N','N','O','O','A','N','A','A','A'),
('32','SCENES_PUBLISH','N','A','O','O','A','N','A','A','A'),
('33','SCENES_MESSAGE','N','A','O','O','A','N','A','A','A'),
('34','SCENES_REVIEW_ASK','N','N','O','O','A','N','N','A','A'),
('35','SCENES_REVIEW_VALID','N','N','N','N','O','N','N','A','A'),
('36','BANK_UPLOAD','N','A','A','A','A','A','A','A','A'),
('37','ASSETS_CREATE','N','N','N','N','A','A','A','A','A');


