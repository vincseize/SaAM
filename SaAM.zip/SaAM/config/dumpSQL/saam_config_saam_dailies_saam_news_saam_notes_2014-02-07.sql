
-- BACKUP BASE DE DONNÉES -- 
-- DATE (AA-MM-JJ): 2014-02-07 
-- FAITE PAR : MAILLARDET
-- 068e3504a03224b5832de5f9d29385eb 

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- ----------------- TABLE saam_config ------------------------

DROP TABLE IF EXISTS `saam_config`;

CREATE TABLE `saam_config` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `version` varchar(25) NOT NULL,
  `oldversion` varchar(25) NOT NULL,
  `default_lang` varchar(2) NOT NULL,
  `default_theme` varchar(12) NOT NULL,
  `fps_list` varchar(256) NOT NULL,
  `default_fps` int(3) NOT NULL DEFAULT '25',
  `ratio_list` varchar(256) NOT NULL,
  `date_format` varchar(256) NOT NULL,
  `url_intranet` varchar(1024) NOT NULL,
  `home_max_news` int(11) NOT NULL DEFAULT '4',
  `calendar_file` varchar(256) NOT NULL,
  `default_depts` text NOT NULL,
  `default_project_types` text NOT NULL,
  `default_seqLabel` varchar(128) NOT NULL,
  `default_shotLabel` varchar(128) NOT NULL,
  `default_scenesLabel` varchar(128) NOT NULL,
  `alert_uploads` tinyint(1) NOT NULL DEFAULT '1',
  `alert_retakes` tinyint(1) NOT NULL DEFAULT '1',
  `alert_messages` tinyint(1) NOT NULL DEFAULT '1',
  `global_tags` text NOT NULL,
  `assets_categories` text NOT NULL,
  `default_assets_dirs` text NOT NULL,
  `default_assets_exclude_dirs` text NOT NULL,
  `default_data_folders` text NOT NULL,
  `default_status` varchar(256) NOT NULL,
  `available_softs` text NOT NULL,
  `available_competences` text NOT NULL,
  `user_status` varchar(256) NOT NULL,
  `dectech_infos` text NOT NULL,
  `wip` tinyint(1) NOT NULL DEFAULT '0',
  `dailies_max_weeks` int(3) NOT NULL,
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `version` (`version`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `saam_config` VALUES 
('1','0.1','0.0','fr','dark','16|18|23.97|24|25|30|60|100','25','16:9|4:3','d/m/Y','http://saamanager.net','4','datas/calendar/events.json','[\"layout\"]','[\"demo\",\"short\",\"feature\",\"commercial\",\"effects\",\"game\",\"web\",\"test\"]','seq_##','shot_###','','1','1','1','','{\"1\":\"characters\",\"2\":\"sets\",\"3\":\"props\",\"4\":\"textures\",\"5\":\"matte\"}','[\"characters\",\"props\",\"sets\",\"vehicles\",\"terrains\"]','[\"refs\",\"bank\",\"stills\"]','[\"refs\",\"bank\",\"stills\"]','{\"0\":\"WIP\",\"1\":\"On Hold\",\"2\":\"VALID\"}','[\"blender\",\"Zbrush\",\"AfterEffect\",\"Maya\",\"Ardour\"]','[\"director\",\"scenarist\",\"cameraman\",\"lightTech\",\"soundTech\",\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\",\"soundMix\"]','','{\"action\":{\"1\":[\"Lieu\",\"\"],\"2\":[\"Int-Ext\",\"\"],\"3\":[\"day-night\",\"\"],\"4\":[\"Action\",\"\"]},\"camera\":{\"1\":[\"Valeur_Plan\",\"\"],\"2\":[\"Mvt_Cam\",\"\"],\"3\":[\"Angle\",\"\"],\"4\":[\"Raccord\",\"\"]},\"son\":{\"1\":[\"Son_Amb\",\"\"],\"2\":[\"Dialogue\",\"\"],\"3\":[\"In-Off\",\"\"],\"4\":[\"Musique\",\"\"]}}','0','0'),
('2','0.2','0.1','fr','dark','16|18|23.97|24|25|30|60|100','25','16:9|4:3','d/m/Y','http://saamanager.net','4','datas/calendar/events.json','[\"layout\"]','[\"demo\",\"short\",\"feature\",\"commercial\",\"effects\",\"game\",\"web\",\"test\"]','seq_##','shot_###','','1','1','1','','{\"1\":\"characters\",\"2\":\"sets\",\"3\":\"props\",\"4\":\"textures\",\"5\":\"matte\"}','[\"characters\",\"props\",\"sets\",\"vehicles\",\"terrains\"]','[\"refs\",\"bank\",\"stills\"]','[\"refs\",\"bank\",\"stills\"]','{\"0\":\"WIP\",\"1\":\"On Hold\",\"2\":\"VALID\"}','[\"blender\",\"Zbrush\",\"AfterEffect\",\"Maya\",\"Ardour\"]','[\"director\",\"scenarist\",\"cameraman\",\"lightTech\",\"soundTech\",\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\",\"soundMix\"]','','{\"action\":{\"1\":[\"Lieu\",\"\"],\"2\":[\"Int-Ext\",\"\"],\"3\":[\"day-night\",\"\"],\"4\":[\"Action\",\"\"]},\"camera\":{\"1\":[\"Valeur_Plan\",\"\"],\"2\":[\"Mvt_Cam\",\"\"],\"3\":[\"Angle\",\"\"],\"4\":[\"Raccord\",\"\"]},\"son\":{\"1\":[\"Son_Amb\",\"\"],\"2\":[\"Dialogue\",\"\"],\"3\":[\"In-Off\",\"\"],\"4\":[\"Musique\",\"\"]}}','0','0'),
('3','0.3','0.2','fr','dark','16|18|23.97|24|25|30|60|100','25','16:9|4:3','d/m/Y','http://saamanager.net','4','datas/calendar/events.json','[\"layout\"]','[\"demo\",\"short\",\"feature\",\"commercial\",\"effects\",\"game\",\"web\",\"test\"]','seq_##','shot_###','','1','1','1','','{\"1\":\"characters\",\"2\":\"sets\",\"3\":\"props\",\"4\":\"textures\",\"5\":\"matte\"}','[\"characters\",\"props\",\"sets\",\"vehicles\",\"terrains\"]','[\"refs\",\"bank\",\"stills\"]','[\"refs\",\"bank\",\"stills\"]','{\"0\":\"WIP\",\"1\":\"On Hold\",\"2\":\"VALID\"}','[\"blender\",\"Zbrush\",\"AfterEffect\",\"Maya\",\"Ardour\"]','[\"director\",\"scenarist\",\"cameraman\",\"lightTech\",\"soundTech\",\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\",\"soundMix\"]','','{\"action\":{\"1\":[\"Lieu\",\"\"],\"2\":[\"Int-Ext\",\"\"],\"3\":[\"day-night\",\"\"],\"4\":[\"Action\",\"\"]},\"camera\":{\"1\":[\"Valeur_Plan\",\"\"],\"2\":[\"Mvt_Cam\",\"\"],\"3\":[\"Angle\",\"\"],\"4\":[\"Raccord\",\"\"]},\"son\":{\"1\":[\"Son_Amb\",\"\"],\"2\":[\"Dialogue\",\"\"],\"3\":[\"In-Off\",\"\"],\"4\":[\"Musique\",\"\"]}}','0','0'),
('4','0.4','0.3','fr','dark','16|18|23.97|24|25|30|60|100','25','16:9|4:3','d/m/Y','http://saamanager.net','4','datas/calendar/events.json','[\"layout\"]','[\"demo\",\"short\",\"feature\",\"commercial\",\"effects\",\"game\",\"web\",\"test\"]','seq_##','shot_###','','1','1','1','','{\"1\":\"characters\",\"2\":\"sets\",\"3\":\"props\",\"4\":\"textures\",\"5\":\"matte\"}','[\"characters\",\"props\",\"sets\",\"vehicles\",\"terrains\"]','[\"refs\",\"bank\",\"stills\"]','[\"refs\",\"bank\",\"stills\"]','{\"0\":\"WIP\",\"1\":\"On Hold\",\"2\":\"VALID\"}','[\"blender\",\"Zbrush\",\"AfterEffect\",\"Maya\",\"Ardour\"]','[\"director\",\"scenarist\",\"cameraman\",\"lightTech\",\"soundTech\",\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\",\"soundMix\"]','','{\"action\":{\"1\":[\"Lieu\",\"\"],\"2\":[\"Int-Ext\",\"\"],\"3\":[\"day-night\",\"\"],\"4\":[\"Action\",\"\"]},\"camera\":{\"1\":[\"Valeur_Plan\",\"\"],\"2\":[\"Mvt_Cam\",\"\"],\"3\":[\"Angle\",\"\"],\"4\":[\"Raccord\",\"\"]},\"son\":{\"1\":[\"Son_Amb\",\"\"],\"2\":[\"Dialogue\",\"\"],\"3\":[\"In-Off\",\"\"],\"4\":[\"Musique\",\"\"]}}','0','0'),
('5','0.41','0.4','fr','dark','16|18|23.97|24|25|30|60|100','25','16:9|4:3','d/m/Y','http://saamanager.net','4','datas/calendar/events.json','[\"layout\"]','[\"demo\",\"short\",\"feature\",\"commercial\",\"effects\",\"game\",\"web\",\"test\"]','seq_##','shot_###','','1','1','1','','{\"1\":\"characters\",\"2\":\"sets\",\"3\":\"props\",\"4\":\"textures\",\"5\":\"matte\"}','[\"characters\",\"props\",\"sets\",\"vehicles\",\"terrains\"]','[\"refs\",\"bank\",\"stills\"]','[\"refs\",\"bank\",\"stills\"]','{\"0\":\"WIP\",\"1\":\"On Hold\",\"2\":\"VALID\"}','[\"blender\",\"Zbrush\",\"AfterEffect\",\"Maya\",\"Ardour\"]','[\"director\",\"scenarist\",\"cameraman\",\"lightTech\",\"soundTech\",\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\",\"soundMix\"]','','{\"action\":{\"1\":[\"Lieu\",\"\"],\"2\":[\"Int-Ext\",\"\"],\"3\":[\"day-night\",\"\"],\"4\":[\"Action\",\"\"]},\"camera\":{\"1\":[\"Valeur_Plan\",\"\"],\"2\":[\"Mvt_Cam\",\"\"],\"3\":[\"Angle\",\"\"],\"4\":[\"Raccord\",\"\"]},\"son\":{\"1\":[\"Son_Amb\",\"\"],\"2\":[\"Dialogue\",\"\"],\"3\":[\"In-Off\",\"\"],\"4\":[\"Musique\",\"\"]}}','0','0'),
('6','0.45','0.41','fr','dark','16|18|23.97|24|25|30|60|100','25','16:9|4:3','d/m/Y','http://saamanager.net','4','datas/calendar/events.json','[\"layout\"]','[\"demo\",\"short\",\"feature\",\"commercial\",\"effects\",\"game\",\"web\",\"test\"]','seq_##','shot_###','','1','1','1','[\"Need review\",\"Stable\"]','{\"1\":\"characters\",\"2\":\"sets\",\"3\":\"props\",\"4\":\"textures\",\"5\":\"matte\"}','[\"characters\",\"props\",\"sets\",\"vehicles\",\"terrains\"]','[\"refs\",\"bank\",\"stills\"]','[\"refs\",\"bank\",\"stills\"]','{\"0\":\"WIP\",\"1\":\"On Hold\",\"2\":\"VALID\"}','[\"blender\",\"Zbrush\",\"AfterEffect\",\"Maya\",\"Ardour\"]','[\"director\",\"scenarist\",\"cameraman\",\"lightTech\",\"soundTech\",\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\",\"soundMix\"]','','{\"action\":{\"1\":[\"Lieu\",\"\"],\"2\":[\"Int-Ext\",\"\"],\"3\":[\"day-night\",\"\"],\"4\":[\"Action\",\"\"]},\"camera\":{\"1\":[\"Valeur_Plan\",\"\"],\"2\":[\"Mvt_Cam\",\"\"],\"3\":[\"Angle\",\"\"],\"4\":[\"Raccord\",\"\"]},\"son\":{\"1\":[\"Son_Amb\",\"\"],\"2\":[\"Dialogue\",\"\"],\"3\":[\"In-Off\",\"\"],\"4\":[\"Musique\",\"\"]}}','0','0'),
('7','0.5','0.45','fr','dark','16|18|23.97|24|25|30|60|100','25','16:9|4:3','d/m/Y','http://saamanager.net','4','datas/calendar/events.json','[\"layout\"]','[\"demo\",\"short\",\"feature\",\"commercial\",\"effects\",\"game\",\"web\",\"test\"]','seq_##','shot_###','','1','1','1','[\"Need review\",\"Stable\"]','{\"1\":\"characters\",\"2\":\"sets\",\"3\":\"props\",\"4\":\"textures\",\"5\":\"matte\"}','[\"characters\",\"props\",\"sets\",\"vehicles\",\"terrains\"]','[\"refs\",\"bank\",\"stills\"]','[\"refs\",\"bank\",\"stills\"]','{\"0\":\"WIP\",\"1\":\"On Hold\",\"2\":\"VALID\"}','[\"blender\",\"Zbrush\",\"AfterEffect\",\"Maya\",\"Ardour\"]','[\"director\",\"scenarist\",\"cameraman\",\"lightTech\",\"soundTech\",\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\",\"soundMix\"]','','{\"action\":{\"1\":[\"Lieu\",\"\"],\"2\":[\"Int-Ext\",\"\"],\"3\":[\"day-night\",\"\"],\"4\":[\"Action\",\"\"]},\"camera\":{\"1\":[\"Valeur_Plan\",\"\"],\"2\":[\"Mvt_Cam\",\"\"],\"3\":[\"Angle\",\"\"],\"4\":[\"Raccord\",\"\"]},\"son\":{\"1\":[\"Son_Amb\",\"\"],\"2\":[\"Dialogue\",\"\"],\"3\":[\"In-Off\",\"\"],\"4\":[\"Musique\",\"\"]}}','0','0'),
('8','0.6','0.5','fr','dark','16|18|23.97|24|25|30|60|100','25','16:9|4:3','d/m/Y','http://saamanager.net','4','datas/calendar/events.json','[\"1\",\"8\"]','[\"demo\",\"short\",\"feature\",\"commercial\",\"effects\",\"game\",\"web\",\"test\"]','SEQ','SHOT','','1','1','1','[\"Need review\",\"Stable\"]','{\"1\":\"characters\",\"2\":\"sets\",\"3\":\"props\",\"4\":\"textures\",\"5\":\"matte\"}','[\"characters\",\"props\",\"sets\",\"vehicles\",\"terrains\"]','[\"refs\",\"bank\",\"stills\"]','[\"refs\",\"bank\",\"stills\"]','{\"0\":\"WIP\",\"1\":\"On Hold\",\"2\":\"VALID\"}','[\"blender\",\"Zbrush\",\"AfterEffect\",\"Maya\",\"Ardour\"]','[\"producer\",\"assistantProd\",\"director\",\"scenarist\",\"cameraman\",\"lightTech\",\"soundTech\",\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\",\"soundMix\"]','','{\"action\":{\"1\":[\"Lieu\",\"\"],\"2\":[\"Int-Ext\",\"\"],\"3\":[\"day-night\",\"\"],\"4\":[\"Action\",\"\"]},\"camera\":{\"1\":[\"Valeur_Plan\",\"\"],\"2\":[\"Mvt_Cam\",\"\"],\"3\":[\"Angle\",\"\"],\"4\":[\"Raccord\",\"\"]},\"son\":{\"1\":[\"Son_Amb\",\"\"],\"2\":[\"Dialogue\",\"\"],\"3\":[\"In-Off\",\"\"],\"4\":[\"Musique\",\"\"]}}','0','8'),
('9','0.7','0.6','fr','dark','16|18|23.97|24|25|30|60|100','25','16:9|4:3','d/m/Y','http://saamanager.net','4','datas/calendar/events.json','[\"1\",\"8\"]','[\"demo\",\"short\",\"feature\",\"commercial\",\"effects\",\"game\",\"web\",\"test\"]','SEQ','SHOT','','1','1','1','[\"Need review\",\"Stable\"]','{\"1\":\"characters\",\"2\":\"sets\",\"3\":\"props\",\"4\":\"textures\",\"5\":\"matte\"}','[\"characters\",\"props\",\"sets\",\"vehicles\",\"terrains\"]','[\"refs\",\"bank\",\"stills\"]','[\"refs\",\"bank\",\"stills\"]','[\"--\",\"WIP\",\"OnHold\",\"VALID\",\"Disabled\"]','[\"blender\",\"Zbrush\",\"AfterEffect\",\"Maya\",\"Ardour\"]','[\"producer\",\"assistantProd\",\"director\",\"scenarist\",\"cameraman\",\"lightTech\",\"soundTech\",\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\",\"soundMix\"]','{\"1\":\"visitor\",\"2\":\"demo\",\"3\":\"artist\",\"4\":\"lead\",\"5\":\"supervisor\",\"6\":\"prod.dir.\",\"7\":\"magic\",\"8\":\"dev\",\"9\":\"root\"}','{\"action\":{\"1\":[\"Lieu\",\"\"],\"2\":[\"Int-Ext\",\"\"],\"3\":[\"day-night\",\"\"],\"4\":[\"Action\",\"\"]},\"camera\":{\"1\":[\"Valeur_Plan\",\"\"],\"2\":[\"Mvt_Cam\",\"\"],\"3\":[\"Angle\",\"\"],\"4\":[\"Raccord\",\"\"]},\"son\":{\"1\":[\"Son_Amb\",\"\"],\"2\":[\"Dialogue\",\"\"],\"3\":[\"In-Off\",\"\"],\"4\":[\"Musique\",\"\"]}}','0','8'),
('10','0.8','0.7','fr','dark','16|18|23.97|24|25|30|60|100','25','16:9|4:3','d/m/Y','http://saamanager.net','4','datas/calendar/events.json','[\"1\",\"8\"]','[\"demo\",\"short\",\"feature\",\"commercial\",\"effects\",\"game\",\"web\",\"test\"]','SEQ','SHOT','','1','1','1','[\"Need review\",\"Stable\"]','{\"1\":\"characters\",\"2\":\"sets\",\"3\":\"props\",\"4\":\"textures\",\"5\":\"matte\"}','[\"characters\",\"props\",\"sets\",\"vehicles\",\"terrains\"]','[\"refs\",\"bank\",\"stills\"]','[\"refs\",\"bank\",\"stills\"]','[\"--\",\"WIP\",\"OnHold\",\"VALID\",\"Disabled\"]','[\"blender\",\"Zbrush\",\"AfterEffect\",\"Maya\",\"Ardour\"]','[\"producer\",\"assistantProd\",\"director\",\"scenarist\",\"cameraman\",\"lightTech\",\"soundTech\",\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\",\"soundMix\"]','{\"1\":\"visitor\",\"2\":\"demo\",\"3\":\"artist\",\"4\":\"lead\",\"5\":\"supervisor\",\"6\":\"prod.dir.\",\"7\":\"magic\",\"8\":\"dev\",\"9\":\"root\"}','{\"action\":{\"1\":[\"Lieu\",\"\"],\"2\":[\"Int-Ext\",\"\"],\"3\":[\"day-night\",\"\"],\"4\":[\"Action\",\"\"]},\"camera\":{\"1\":[\"Valeur_Plan\",\"\"],\"2\":[\"Mvt_Cam\",\"\"],\"3\":[\"Angle\",\"\"],\"4\":[\"Raccord\",\"\"]},\"son\":{\"1\":[\"Son_Amb\",\"\"],\"2\":[\"Dialogue\",\"\"],\"3\":[\"In-Off\",\"\"],\"4\":[\"Musique\",\"\"]}}','0','8'),
('11','0.9','0.8','fr','dark','16|18|23.97|24|25|30|60|100','25','16:9|4:3','d/m/Y','http://saamanager.net','4','datas/calendar/events.json','[\"1\",\"8\"]','[\"demo\",\"short\",\"feature\",\"commercial\",\"effects\",\"game\",\"web\",\"test\"]','SEQ','SHOT','M_SC','1','1','1','[\"Need review\",\"Stable\"]','{\"1\":\"characters\",\"2\":\"sets\",\"3\":\"props\",\"4\":\"textures\",\"5\":\"matte\"}','[\"characters\",\"props\",\"sets\",\"vehicles\",\"terrains\"]','[\"refs\",\"bank\",\"stills\"]','[\"refs\",\"bank\",\"stills\"]','[\"--\",\"WIP\",\"OnHold\",\"VALID\",\"Disabled\"]','[\"blender\",\"Zbrush\",\"AfterEffect\",\"Maya\",\"Ardour\"]','[\"producer\",\"assistantProd\",\"director\",\"scenarist\",\"cameraman\",\"lightTech\",\"soundTech\",\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\",\"soundMix\"]','{\"1\":\"visitor\",\"2\":\"demo\",\"3\":\"artist\",\"4\":\"lead\",\"5\":\"supervisor\",\"6\":\"prod.dir.\",\"7\":\"magic\",\"8\":\"dev\",\"9\":\"root\"}','{\"action\":{\"1\":[\"Lieu\",\"\"],\"2\":[\"Int-Ext\",\"\"],\"3\":[\"day-night\",\"\"],\"4\":[\"Action\",\"\"]},\"camera\":{\"1\":[\"Valeur_Plan\",\"\"],\"2\":[\"Mvt_Cam\",\"\"],\"3\":[\"Angle\",\"\"],\"4\":[\"Raccord\",\"\"]},\"son\":{\"1\":[\"Son_Amb\",\"\"],\"2\":[\"Dialogue\",\"\"],\"3\":[\"In-Off\",\"\"],\"4\":[\"Musique\",\"\"]}}','0','8'),
('12','0.99','0.9','fr','dark','16|18|23.97|24|25|30|60|100','25','16:9|4:3','d/m/Y','http://saamanager.net','4','datas/calendar/events.json','[\"1\",\"8\"]','[\"demo\",\"short\",\"feature\",\"commercial\",\"effects\",\"game\",\"web\",\"test\"]','SEQ','SHOT','M_SC','1','1','1','[\"Need review\",\"Stable\"]','{\"1\":\"characters\",\"2\":\"sets\",\"3\":\"props\",\"4\":\"textures\",\"5\":\"matte\"}','[\"characters\",\"props\",\"sets\",\"vehicles\",\"terrains\"]','[\"refs\",\"bank\",\"stills\"]','[\"refs\",\"bank\",\"stills\"]','[\"--\",\"WIP\",\"OnHold\",\"VALID\",\"Disabled\"]','[\"blender\",\"Zbrush\",\"AfterEffect\",\"Maya\",\"Ardour\"]','[\"producer\",\"assistantProd\",\"director\",\"scenarist\",\"cameraman\",\"lightTech\",\"soundTech\",\"artist2D\",\"artist3D\",\"editor\",\"coder\",\"VFX\",\"soundMix\"]','{\"1\":\"visitor\",\"2\":\"demo\",\"3\":\"artist\",\"4\":\"lead\",\"5\":\"supervisor\",\"6\":\"prod.dir.\",\"7\":\"magic\",\"8\":\"dev\",\"9\":\"root\"}','{\"action\":{\"1\":[\"Lieu\",\"\"],\"2\":[\"Int-Ext\",\"\"],\"3\":[\"day-night\",\"\"],\"4\":[\"Action\",\"\"]},\"camera\":{\"1\":[\"Valeur_Plan\",\"\"],\"2\":[\"Mvt_Cam\",\"\"],\"3\":[\"Angle\",\"\"],\"4\":[\"Raccord\",\"\"]},\"son\":{\"1\":[\"Son_Amb\",\"\"],\"2\":[\"Dialogue\",\"\"],\"3\":[\"In-Off\",\"\"],\"4\":[\"Musique\",\"\"]}}','0','8');


-- ----------------- TABLE saam_dailies ------------------------

DROP TABLE IF EXISTS `saam_dailies`;

CREATE TABLE `saam_dailies` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `ID_project` int(4) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user` int(4) NOT NULL,
  `groupe` varchar(32) NOT NULL,
  `type` varchar(32) NOT NULL,
  `corresp` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ID_project` (`ID_project`),
  KEY `date` (`date`)
) ENGINE=InnoDB AUTO_INCREMENT=285 DEFAULT CHARSET=utf8;

INSERT INTO `saam_dailies` VALUES 
('1','277','2013-06-07 11:35:05','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anim\",\"txtMess\":\"wazzza, vla pour le premier dailies\"}'),
('2','277','2013-06-14 16:48:42','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anim\",\"txtMess\":\"et, another one to bite the dust\"}'),
('3','277','2013-06-21 16:49:13','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"855\",\"dept\":\"anim\"}'),
('4','277','2013-06-28 16:49:40','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"855\",\"dept\":\"anim\",\"txtMess\":\"héhéhé ça fonctionne direct, c\'est pas beau ça ?\"}'),
('5','277','2013-07-05 16:49:46','4','SHOT','SHOT_VALID_PUBLISHED','{\"idShot\":\"855\",\"dept\":\"anim\"}'),
('6','277','2013-07-01 16:50:07','4','SHOT','SHOT_BANK_UPLOAD','{\"idShot\":\"808\",\"dept\":\"anim\",\"nbF\":\"1\",\"folder\":\"bank\"}'),
('7','277','2013-07-02 16:50:51','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\"}'),
('8','277','2013-07-03 16:51:27','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"hop la, vla pour les assets, un ptit message ?\"}'),
('9','277','2013-07-04 16:51:37','4','ASSET','ASSET_HANDLED','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"idNewHandler\":\"4\"}'),
('10','277','2013-07-12 16:51:47','4','ASSET','ASSET_HANDLED','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"idNewHandler\":\"0\"}'),
('11','277','2013-07-12 16:52:22','4','ASSET','ASSET_BANK_UPLOAD','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"nbF\":\"1\",\"folder\":\"bank\"}'),
('12','277','2013-07-12 16:52:59','4','ASSET','ASSET_NEW_PUBLISHED','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\"}'),
('13','277','2013-07-12 16:53:37','4','ASSET','ASSET_VALID_PUBLISHED','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\"}'),
('14','277','2013-07-12 16:54:08','4','ROOT','BLOCKANIM_NEW_MESSAGE','owkay, just a test'),
('15','277','2013-07-12 23:29:52','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"856\",\"dept\":\"anims\",\"txtMess\":\"hop la\"}'),
('16','277','2013-07-12 23:31:10','4','ASSET','ASSET_NEW_PUBLISHED','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\"}'),
('17','277','2013-07-14 02:23:29','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"fghjdghjdghj\"}'),
('18','277','2013-07-14 02:23:40','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"vhjkfghjfghj\"}'),
('19','277','2013-07-14 18:19:43','4','ASSET','ASSET_MOD_PUBLISHED','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\"}'),
('20','277','2013-07-14 18:31:36','4','ASSET','ASSET_MOD_PUBLISHED','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\"}'),
('21','277','2013-07-14 20:09:45','4','ASSET','ASSET_NEW_PUBLISHED','{\"pathAsset\":\"props/casque_pompier/\",\"nameAsset\":\"casque_pompier.blend\"}'),
('22','277','2013-07-14 20:09:55','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"props/casque_pompier/\",\"nameAsset\":\"casque_pompier.blend\",\"txtMess\":\"zawaaaaa\"}'),
('23','277','2013-07-14 20:10:48','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"props/casque_pompier/\",\"nameAsset\":\"casque_pompier.blend\",\"txtMess\":\"Cool... En tout cas te prends pas trop le choux, dans le sens ou ce sont des assets mineurs... Bienvenue dans léquipe Azuk !\"}'),
('24','277','2013-07-14 20:17:38','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"props/casque_pompier/\",\"nameAsset\":\"casque_pompier.blend\",\"txtMess\":\"Voyons+voir+ce+que+%C3%A7a+donne+avec+un+petit+urlencode+%3F%0AHop+j%27ai+saut%C3%A9+une+ligne+%21%21%0A%0A%22attention%22+les+v%C3%A9los+nom+d%27%27unchien%27%27%0A%5E%5E%0A%3AD%0A%0A\"}'),
('25','277','2013-07-15 13:44:22','4','ASSET','ASSET_VALID_PUBLISHED','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\"}'),
('26','277','2013-07-15 13:44:52','4','ASSET','ASSET_NEW_PUBLISHED','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\"}'),
('27','277','2013-07-17 00:07:05','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"okay\"}'),
('28','277','2013-07-17 00:40:37','58','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"wazzzoy\"}'),
('29','277','2013-07-17 00:47:37','58','SHOT','SHOT_MOD_PUBLISHED','{\"idShot\":\"808\",\"dept\":\"anims\"}'),
('30','277','2013-07-17 01:18:28','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"utkgjhlkg+kguikk\"}'),
('31','277','2013-07-17 01:18:47','58','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"dtydg+hdtgh+et+gnety+rtyntt\"}'),
('32','277','2013-07-17 01:20:45','58','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"raaaazaaaaalgul\"}'),
('33','277','2013-07-17 11:47:02','58','SHOT','SHOT_BANK_UPLOAD','{\"idShot\":\"855\",\"dept\":\"anims\",\"nbF\":\"1\",\"folder\":\"stills\"}'),
('34','277','2013-07-17 11:48:25','58','SHOT','SHOT_BANK_UPLOAD','{\"idShot\":\"855\",\"dept\":\"anims\",\"nbF\":\"1\",\"folder\":\"stills\"}'),
('35','277','2013-07-17 14:31:41','58','SHOT','SHOT_BANK_UPLOAD','{\"idShot\":\"808\",\"dept\":\"anims\",\"nbF\":\"1\",\"folder\":\"mon triip\"}'),
('36','277','2013-07-17 15:02:11','4','SHOT','SHOT_BANK_UPLOAD','{\"idShot\":\"910\",\"dept\":\"storyboard\",\"nbF\":\"1\",\"folder\":\"stills\"}'),
('37','277','2013-07-17 23:29:02','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"ertyert+erth+erth\"}'),
('38','277','2013-07-17 23:31:52','58','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"ergzerg+zerrv\"}'),
('39','277','2013-07-17 23:39:18','58','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"owkay%2C+1er+message\"}'),
('40','277','2013-07-17 23:39:29','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"r%C3%A9ponse+nom+d%27un+chien\"}'),
('41','277','2013-07-17 23:39:43','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"r%C3%A9ponse+nom+d%27un+chien\"}'),
('42','277','2013-07-17 23:44:54','58','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"h%C3%A9h%C3%A9h%C3%A9\"}'),
('43','277','2013-07-17 23:45:12','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"voila+qui+est+interresting+%3A%29\"}'),
('44','277','2013-07-17 23:53:26','58','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"jme+r%C3%A9pond\"}'),
('45','277','2013-07-17 23:53:40','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"je+te+r%C3%A9pond\"}'),
('46','277','2013-07-17 23:53:51','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"jme+r%C3%A9pond+%C3%A0+moi\"}'),
('47','277','2013-07-17 23:54:58','58','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"owkay\"}'),
('48','277','2013-07-18 00:58:37','4','ASSET','ASSET_VALID_PUBLISHED','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\"}'),
('49','277','2013-07-18 11:14:12','4','ASSET','ASSET_HANDLED','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"idNewHandler\":\"58\"}'),
('50','277','2013-07-18 11:38:06','58','ASSET','ASSET_NEW_PUBLISHED','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\"}'),
('51','277','2013-07-18 13:02:47','58','ASSET','ASSET_HANDLED','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"idNewHandler\":\"0\"}'),
('52','277','2013-07-23 12:33:33','4','ASSET','ASSET_BANK_UPLOAD','{\"pathAsset\":\"./characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"nbF\":\"1\",\"folder\":\"wip\"}'),
('53','277','2013-07-23 12:33:55','58','ASSET','ASSET_BANK_UPLOAD','{\"pathAsset\":\"./characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"nbF\":\"1\",\"folder\":\"wip\"}'),
('54','277','2013-07-24 17:25:00','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"zdfgz+feg+zrfb+zrbzrtb+gf\"}'),
('55','277','2013-07-27 23:07:36','4','ASSET','ASSET_VALID_PUBLISHED','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\"}'),
('56','277','2013-07-27 23:10:11','4','ASSET','ASSET_VALID_PUBLISHED','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\"}'),
('57','277','2013-07-27 23:18:31','4','ASSET','ASSET_VALID_PUBLISHED','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\"}'),
('58','277','2013-08-30 01:28:59','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"964\",\"dept\":\"storyboard\"}'),
('59','277','2013-08-30 01:29:35','4','SHOT','SHOT_MOD_PUBLISHED','{\"idShot\":\"964\",\"dept\":\"storyboard\"}'),
('60','277','2013-08-31 02:08:38','4','ASSET','ASSET_NEW_PUBLISHED','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\"}'),
('61','277','2013-08-31 02:09:11','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"txtMess\":\"En+voila+une+belle+Lune+%21%21+Un+peu+stretch%C3%A9e+mais+%C3%A7a+va...\"}'),
('62','277','2013-08-31 02:09:34','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"txtMess\":\"Non%2C+elle+est+stretch%C3%A9e+parce+que+l%27image+n%27est+pas+au+format+du+film.\"}'),
('63','277','2013-08-31 02:09:43','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"txtMess\":\"Ah%2C+ok+je+vois\"}'),
('64','277','2013-08-31 02:10:11','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"txtMess\":\"Lorem+ipsum+dolor+sit+amet%2C+consectetur+adipiscing+elit.+Donec+a+diam+lectus.+Sed+sit+amet+ipsum+mauris.+Maecenas+congue+ligula+ac+quam+viverra+nec+consectetur+ante+hendrerit.+Donec+et+mollis+dolor.+Praesent+et+diam+eget+libero+egestas+mattis+sit+amet+vitae+augue.+Nam+tincidunt+congue+enim%2C+ut+porta+lorem+lacinia+consectetur.+Donec+ut+libero+sed+arcu+vehicula+ultricies+a+non+tortor.+Lorem+ipsum+dolor+sit+amet%2C+consectetur+adipiscing+elit\"}'),
('65','277','2013-08-31 02:10:18','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"txtMess\":\"okok\"}'),
('66','277','2013-09-01 17:11:31','4','SHOT','SHOT_VALID_PUBLISHED','{\"idShot\":\"808\",\"dept\":\"anims\"}'),
('67','277','2013-09-01 17:13:07','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"808\",\"dept\":\"anims\"}'),
('68','277','2013-09-01 17:14:31','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"Lorem+ipsum+dolor+sit+amet%2C+consectetur+adipiscing+elit.+Donec+a+diam+lectus.+Sed+sit+amet+ipsum+mauris.+Maecenas+congue+ligula+ac+quam+viverra+nec+consectetur+ante+hendrerit.\"}'),
('69','277','2013-09-01 17:14:44','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"Owkay+%21%0A%0A%C3%87a+roule+%21+%3A%29\"}'),
('70','277','2013-09-01 17:16:01','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"Lorem+ipsum+dolor+sit+amet%2C+consectetur+adipiscing+elit.+Donec+a+diam+lectus.+Sed+sit+amet+ipsum+mauris.\"}'),
('71','277','2013-09-04 19:16:16','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"yeah\"}'),
('72','277','2013-09-04 19:18:01','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"et+l%C3%A0+%3F+C+good+%3F\"}'),
('73','277','2013-09-04 19:18:15','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"c%27est+goooood+%21%21\"}'),
('74','277','2013-09-04 19:18:41','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"owkay%2C+pourquoi+pas%2C+mais+c%27est+le+dernier+%21%0Alol\"}'),
('75','277','2013-09-04 19:20:15','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"dfghdfhdfgh+dfgghh+dfgh\"}'),
('77','277','2013-09-06 02:52:45','4','ASSET','ASSET_NEW_PUBLISHED','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\"}'),
('78','277','2013-09-06 02:53:09','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"txtMess\":\"rhoooo%0Amagnifique\"}'),
('79','277','2013-09-06 02:56:43','4','ASSET','ASSET_MOD_PUBLISHED','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\"}'),
('80','277','2013-09-06 03:15:03','4','ASSET','ASSET_MOD_PUBLISHED','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"deptID\":\"9\"}'),
('81','277','2013-09-06 03:15:35','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"deptID\":\"9\",\"txtMess\":\"sfgsfgb+sfdb+sfdbsfdsfgb\"}'),
('88','277','2013-09-06 16:50:30','4','ASSET','ASSET_BANK_UPLOAD','{\"pathAsset\":\"./characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"deptID\":\"8\",\"nbF\":\"1\",\"folder\":\"bank\"}'),
('89','277','2013-09-06 16:58:38','4','ASSET','ASSET_BANK_UPLOAD','{\"pathAsset\":\"./characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"deptID\":\"8\",\"nbF\":\"1\",\"folder\":\"bank\"}'),
('90','277','2013-09-06 16:59:29','4','ASSET','ASSET_BANK_UPLOAD','{\"pathAsset\":\"./characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"deptID\":\"8\",\"nbF\":\"1\",\"folder\":\"bank\"}'),
('91','277','2013-09-06 16:59:56','4','ASSET','ASSET_BANK_UPLOAD','{\"pathAsset\":\"./characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"deptID\":\"8\",\"nbF\":\"1\",\"folder\":\"bank\"}'),
('92','277','2013-09-06 17:01:44','4','ASSET','ASSET_BANK_UPLOAD','{\"pathAsset\":\"./characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"deptID\":\"8\",\"nbF\":\"1\",\"folder\":\"bank\"}'),
('93','277','2013-09-06 17:25:37','4','ASSET','ASSET_NEW_PUBLISHED','{\"pathAsset\":\"sets/bedroom/\",\"nameAsset\":\"Marcel-Bedroom.blend\",\"deptID\":\"8\"}'),
('94','277','2013-09-06 17:27:04','4','ASSET','ASSET_NEW_PUBLISHED','{\"pathAsset\":\"sets/bedroom/\",\"nameAsset\":\"Marcel-Bedroom.blend\",\"deptID\":\"9\"}'),
('95','277','2013-09-07 01:53:17','4','ASSET','ASSET_VALID_PUBLISHED','{\"pathAsset\":\"sets/bedroom/\",\"nameAsset\":\"Marcel-Bedroom.blend\",\"deptID\":\"9\"}'),
('96','293','2013-09-11 22:59:05','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"939\",\"dept\":\"storyboard\"}'),
('97','293','2013-09-11 22:59:16','4','SHOT','SHOT_VALID_PUBLISHED','{\"idShot\":\"939\",\"dept\":\"storyboard\"}'),
('98','293','2013-09-11 22:59:37','4','SHOT','SHOT_VALID_PUBLISHED','{\"idShot\":\"939\",\"dept\":\"storyboard\"}'),
('102','277','2013-09-18 23:21:53','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"test+add+message+new+button\"}'),
('103','277','2013-09-18 23:22:19','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"855\",\"dept\":\"anims\"}'),
('104','277','2013-09-18 23:22:36','4','SHOT','SHOT_MOD_PUBLISHED','{\"idShot\":\"855\",\"dept\":\"anims\"}'),
('105','277','2013-09-20 13:52:02','4','ROOT','SCENARIO_UPDATE','{\"idProject\":\"277\"}'),
('106','277','2013-09-20 13:54:30','4','ROOT','SCENARIO_UPDATE','{\"idProject\":\"277\"}'),
('107','277','2013-09-20 13:56:20','4','ROOT','SCENARIO_UPDATE','{\"idProject\":\"277\"}'),
('108','277','2013-09-23 01:47:08','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"Test+de+commentaire+depuis+l%27API+%21\"}'),
('109','277','2013-09-23 01:47:44','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"VFX\",\"txtMess\":\"Test+de+commentaire+depuis+l%27API+%21\"}'),
('110','277','2013-09-23 01:53:03','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"855\",\"dept\":\"anims\",\"txtMess\":\"Test+de+commentaire+depuis+l%27API+%21\"}'),
('111','277','2013-09-23 01:53:09','4','SHOT','SHOT_VALID_PUBLISHED','{\"idShot\":\"855\",\"dept\":\"anims\"}'),
('112','277','2013-09-23 02:19:45','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"9\",\"txtMess\":\"Test+de+commentaire+depuis+l%27API+%21\"}'),
('113','277','2013-09-23 02:20:42','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"deptID\":\"8\",\"txtMess\":\"Test+de+commentaire+depuis+l%27API+%21\"}'),
('114','277','2013-09-23 02:26:58','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"Test+de+commentaire+depuis+l%27API+%21\"}'),
('115','277','2013-09-23 18:56:27','4','ASSET','ASSET_REVIEW_REQUEST','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"comment\":\"Test de demande de review depuis l\'API !\"}'),
('116','277','2013-09-23 19:01:07','4','ASSET','ASSET_REVIEW_VALID','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\"}'),
('117','277','2013-09-23 19:02:08','4','ASSET','ASSET_REVIEW_REQUEST','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"comment\":\"Test de demande de review depuis l\'API !\"}'),
('118','277','2013-09-23 19:03:40','4','ASSET','ASSET_REVIEW_REQUEST','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"comment\":\"Test de demande de review depuis l\'API !\"}'),
('119','277','2013-09-23 19:06:52','4','ASSET','ASSET_REVIEW_VALID','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\"}'),
('120','277','2013-09-23 19:07:24','4','ASSET','ASSET_REVIEW_VALID','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\"}'),
('121','277','2013-09-23 19:09:31','4','ASSET','ASSET_REVIEW_REQUEST','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"comment\":\"Test de demande de review depuis l\'API !\"}'),
('122','277','2013-09-23 19:18:27','4','ASSET','ASSET_REVIEW_VALID','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\"}'),
('123','277','2013-10-03 16:36:25','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"deptID\":\"9\",\"txtMess\":\"waz+az+%21%21\"}'),
('124','277','2013-10-07 20:42:41','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"981\",\"dept\":\"anims\"}'),
('125','277','2013-11-13 00:29:16','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"wouzaaa\"}'),
('126','277','2013-11-13 00:38:32','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"gniuk+gniuk+1\"}'),
('127','277','2013-11-13 00:38:38','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"yeah+2\"}'),
('128','277','2013-11-13 00:38:50','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"bon...+hum+3\"}'),
('129','277','2013-11-13 00:39:04','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"pas+au+top+tout+%C3%A7a...+4\"}'),
('130','277','2013-11-13 00:39:34','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"r%C3%A9ponse+au+4...+5+%21\"}'),
('131','277','2013-11-13 00:55:19','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"et+donc+%3F\"}'),
('132','277','2013-11-13 01:03:09','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"deptID\":\"9\",\"txtMess\":\"yo+1\"}'),
('133','277','2013-11-13 01:03:14','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"deptID\":\"9\",\"txtMess\":\"yo+2\"}'),
('134','277','2013-11-13 01:03:22','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"deptID\":\"9\",\"txtMess\":\"yo+3\"}'),
('135','277','2013-11-13 01:03:50','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"deptID\":\"9\",\"txtMess\":\"mouagahahaha\"}'),
('136','277','2013-11-13 01:04:01','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"deptID\":\"9\",\"txtMess\":\"t%27en+veux+%3F\"}'),
('137','277','2013-11-13 01:04:07','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"deptID\":\"9\",\"txtMess\":\"oh+oui+%21\"}'),
('138','277','2013-11-13 01:04:20','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"deptID\":\"9\",\"txtMess\":\"et+pis+moi+%21\"}'),
('139','277','2013-11-13 01:05:12','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"deptID\":\"9\",\"txtMess\":\"wouzaa\"}'),
('140','277','2013-11-13 01:05:31','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"deptID\":\"9\",\"txtMess\":\"yo+4\"}'),
('141','277','2013-11-13 01:05:40','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"deptID\":\"9\",\"txtMess\":\"yo+da+%21\"}'),
('142','277','2013-11-13 01:20:16','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/marcel/\",\"nameAsset\":\"Marcel_000.blend\",\"deptID\":\"9\",\"txtMess\":\"burped+code\"}'),
('143','277','2013-11-13 02:13:11','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"wouza+%21\"}'),
('144','277','2013-11-13 02:13:20','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"zerzer\"}'),
('145','277','2013-11-20 22:29:03','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"6\"}'),
('146','277','2013-11-21 23:54:47','3','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"storyboard\",\"txtMess\":\"wouza+first+%21\"}'),
('147','277','2013-11-22 01:42:11','4','ROOT','BLOCKANIM_NEW_MESSAGE','wouzaah'),
('148','277','2013-11-22 01:42:25','4','ROOT','BLOCKANIM_NEW_MESSAGE','wouzaah'),
('149','277','2013-11-22 01:45:24','4','ROOT','BLOCKANIM_NEW_MESSAGE','ezrttyzre'),
('150','277','2013-11-22 01:46:32','4','ROOT','BLOCKANIM_NEW_MESSAGE','erty'),
('151','277','2013-11-22 01:48:21','4','ROOT','BLOCKANIM_NEW_MESSAGE','fghj fiuuuu'),
('152','277','2013-11-22 02:05:37','4','ROOT','BLOCKANIM_NEW_MESSAGE','mozette'),
('153','277','2013-11-22 15:23:42','4','ROOT','BLOCKANIM_NEW_MESSAGE','ertererrg 
egsdfg 
sdfgsdfg sdfg sdfg sdffg
sdfg 
sdfg 
sdf g
sdf g!'),
('154','277','2013-11-22 23:41:11','3','ROOT','BLOCKANIM_NEW_MESSAGE','yeah !!'),
('155','277','2013-11-22 23:41:38','3','ROOT','BLOCKANIM_NEW_MESSAGE','la grande classe'),
('156','277','2013-11-22 23:41:51','4','ROOT','BLOCKANIM_NEW_MESSAGE','yep, pas mal, no ?'),
('157','277','2013-11-23 01:06:52','4','SHOT','SHOT_VALID_PUBLISHED','{\"idShot\":\"981\",\"dept\":\"anims\"}'),
('158','277','2013-11-23 01:07:41','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"981\",\"dept\":\"anims\"}'),
('159','277','2013-11-23 01:12:21','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"983\",\"dept\":\"anims\"}'),
('160','277','2013-11-23 01:16:09','4','SHOT','SHOT_MOD_PUBLISHED','{\"idShot\":\"981\",\"dept\":\"anims\"}'),
('161','277','2013-11-23 01:23:15','4','SHOT','SHOT_MOD_PUBLISHED','{\"idShot\":\"808\",\"dept\":\"anims\"}'),
('162','277','2013-11-23 17:14:02','4','SHOT','SHOT_VALID_PUBLISHED','{\"idShot\":\"808\",\"dept\":\"compositing\"}'),
('163','277','2013-11-23 17:21:29','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"808\",\"dept\":\"compositing\"}'),
('164','277','2013-11-24 00:50:41','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"982\",\"dept\":\"anims\"}'),
('165','277','2013-11-24 00:51:54','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"982\",\"dept\":\"VFX\"}'),
('166','277','2013-11-26 00:58:31','3','ROOT','BLOCKANIM_NEW_MESSAGE','Illud tamen clausos vehementer angebat quod captis navigiis, quae frumenta vehebant per flumen, Isauri quidem alimentorum copiis adfluebant, ipsi vero solitarum rerum cibos iam consumendo inediae propinquantis aerumnas exitialis horrebant.

Ergo ego senator inimicus, si ita vultis, homini, amicus esse, sicut semper fui, rei publicae debeo. Quid? si ipsas inimicitias, depono rei publicae causa, quis me tandem iure reprehendet, praesertim cum ego omnium meorum consiliorum atque factorum exempla semper ex summorum hominum consiliis atque factis mihi censuerim petenda.

Quapropter a natura mihi videtur potius quam ab indigentia orta amicitia, applicatione magis animi cum quodam sensu amandi quam cogitatione quantum illa res utilitatis esset habitura. Quod quidem quale sit, etiam in bestiis quibusdam animadverti potest, quae ex se natos ita amant ad quoddam tempus et ab eis ita amantur ut facile earum sensus appareat. Quod in homine multo est evidentius, primum ex ea caritate quae est inter natos et parentes, quae dirimi nisi detestabili scelere non potest; deinde cum similis sensus exstitit amoris, si aliquem nacti sumus cuius cum moribus et natura congruamus, quod in eo quasi lumen aliquod probitatis et virtutis perspicere videamur.

Illud tamen clausos vehementer angebat quod captis navigiis, quae frumenta vehebant per flumen, Isauri quidem alimentorum copiis adfluebant, ipsi vero solitarum rerum cibos iam consumendo inediae propinquantis aerumnas exitialis horrebant.

Ergo ego senator inimicus, si ita vultis, homini, amicus esse, sicut semper fui, rei publicae debeo. Quid? si ipsas inimicitias, depono rei publicae causa, quis me tandem iure reprehendet, praesertim cum ego omnium meorum consiliorum atque factorum exempla semper ex summorum hominum consiliis atque factis mihi censuerim petenda.

Quapropter a natura mihi videtur potius quam ab indigentia orta amicitia, applicatione magis animi cum quodam sensu amandi quam cogitatione quantum illa res utilitatis esset habitura. Quod quidem quale sit, etiam in bestiis quibusdam animadverti potest, quae ex se natos ita amant ad quoddam tempus et ab eis ita amantur ut facile earum sensus appareat. Quod in homine multo est evidentius, primum ex ea caritate quae est inter natos et parentes, quae dirimi nisi detestabili scelere non potest; deinde cum similis sensus exstitit amoris, si aliquem nacti sumus cuius cum moribus et natura congruamus, quod in eo quasi lumen aliquod probitatis et virtutis perspicere videamur.'),
('167','277','2013-11-26 01:30:07','4','ROOT','BLOCKANIM_NEW_MESSAGE','serser serg segr'),
('168','277','2013-11-26 01:30:54','4','ROOT','BLOCKANIM_NEW_MESSAGE','rytuukr yu,,yru, aerg zrtth h'),
('169','277','2013-11-26 01:31:11','4','ROOT','BLOCKANIM_NEW_MESSAGE','g yu;fy ;fy u,'),
('170','277','2013-12-19 15:49:49','4','ASSET','ASSET_HANDLED','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"idNewHandler\":\"4\"}'),
('171','277','2013-12-20 12:09:09','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"808\",\"dept\":\"blockanim\"}'),
('172','277','2013-12-20 12:09:21','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"855\",\"dept\":\"blockanim\"}'),
('173','277','2013-12-20 12:14:14','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"981\",\"dept\":\"blockanim\"}'),
('174','277','2013-12-20 12:14:24','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"983\",\"dept\":\"blockanim\"}'),
('175','277','2013-12-20 12:14:43','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"856\",\"dept\":\"blockanim\"}'),
('176','277','2013-12-20 12:14:56','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"982\",\"dept\":\"blockanim\"}'),
('177','277','2014-01-10 02:30:47','4','SCENE','SCENE_NEW_MESSAGE','{\"sceneID\":\"1\",\"deptID\":\"9\",\"txtMess\":\"zer+guuut+%21\"}'),
('178','277','2014-01-17 12:45:03','4','SCENE','SCENE_NEW_MESSAGE','{\"sceneID\":\"1\",\"deptID\":\"10\",\"txtMess\":\"wouzaaaa+test+test\"}'),
('179','277','2014-02-01 13:53:12','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('180','277','2014-02-01 13:53:53','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('181','277','2014-02-01 13:57:07','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('182','277','2014-02-01 13:57:39','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('183','277','2014-02-01 23:03:39','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('184','277','2014-02-01 23:04:08','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('185','277','2014-02-01 23:13:11','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('186','277','2014-02-01 23:15:46','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('187','277','2014-02-01 23:16:26','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"6\"}'),
('188','277','2014-02-01 23:27:29','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"2\"}'),
('189','277','2014-02-01 23:28:21','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"2\"}'),
('190','277','2014-02-01 23:29:22','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"2\"}'),
('191','277','2014-02-01 23:32:48','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('192','277','2014-02-02 01:03:26','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('193','277','2014-02-02 01:03:32','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('194','277','2014-02-02 01:03:41','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"2\"}'),
('195','277','2014-02-02 01:03:46','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"2\"}'),
('196','277','2014-02-02 01:51:00','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('197','277','2014-02-02 01:51:55','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('198','277','2014-02-02 18:58:26','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('199','277','2014-02-02 18:59:33','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('200','277','2014-02-02 19:07:25','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277,\"nbF\":\"1\"}'),
('201','277','2014-02-03 14:43:00','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"testZa\"}'),
('202','277','2014-02-03 14:43:15','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"2\",\"folder\":\"testZa\"}'),
('203','277','2014-02-03 14:44:13','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"test+dailies+msg\"}'),
('204','277','2014-02-03 14:45:16','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/crastors/\",\"nameAsset\":\"crastor.blend\",\"deptID\":\"13\",\"txtMess\":\"Un+ptit+message+pour+tester+le+nouveau+fonctionnement+de+l%27envoi+de+mail+%21%0AOn+verra+bien+ce+que+%C3%A7a+donne+%21%21\"}'),
('205','293','2014-02-03 20:51:14','4','ROOT','BANK_UPLOAD','{\"idProject\":\"293\",\"nbF\":\"1\",\"folder\":\"thumbs\"}'),
('206','312','2014-02-05 01:09:49','4','ROOT','BANK_UPLOAD','{\"idProject\":\"312\",\"nbF\":\"1\",\"folder\":\"Polo_anniv_Thorin.jpg\"}'),
('207','312','2014-02-05 01:11:33','4','ROOT','BANK_UPLOAD','{\"idProject\":\"312\",\"nbF\":\"1\",\"folder\":\"datas/projects/312_wouza/bank\"}'),
('208','312','2014-02-05 01:12:06','4','ROOT','BANK_UPLOAD','{\"idProject\":\"312\",\"nbF\":\"1\",\"folder\":\"images\"}'),
('209','312','2014-02-05 01:13:05','4','ROOT','SCENARIO_UPDATE','{\"idProject\":\"312\"}'),
('210','312','2014-02-05 01:15:47','4','SHOT','SHOT_BANK_UPLOAD','{\"idShot\":\"989\",\"dept\":\"storyboard\",\"nbF\":\"1\",\"folder\":\"bank\"}'),
('211','312','2014-02-05 01:16:24','4','SHOT','SHOT_BANK_UPLOAD','{\"idShot\":\"989\",\"dept\":\"anims\",\"nbF\":\"1\",\"folder\":\"stills\"}'),
('212','277','2014-02-05 01:18:05','4','ASSET','ASSET_BANK_UPLOAD','{\"pathAsset\":\"./characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"12\",\"nbF\":\"1\",\"folder\":\"bank\"}'),
('213','312','2014-02-05 01:19:47','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"989\",\"dept\":\"anims\"}'),
('214','312','2014-02-05 01:21:47','4','SHOT','SHOT_VALID_PUBLISHED','{\"idShot\":\"989\",\"dept\":\"anims\"}'),
('215','312','2014-02-05 01:22:06','4','SHOT','SHOT_NEW_PUBLISHED','{\"idShot\":\"989\",\"dept\":\"anims\"}'),
('216','312','2014-02-05 01:22:14','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"989\",\"dept\":\"anims\",\"txtMess\":\"Wouzah\"}'),
('217','312','2014-02-05 01:23:02','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"989\",\"dept\":\"anims\",\"txtMess\":\"Un+ptit+test+un+peu+plus+pouss%C3%A9%2C+pour+t%27ester+les%0A%22urlD%C3%A9c%C3%B4des%22+%21+YEAH\"}'),
('218','277','2014-02-05 01:26:41','4','ASSET','ASSET_NEW_PUBLISHED','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"12\"}'),
('219','277','2014-02-05 01:27:15','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"12\",\"txtMess\":\"Test+blah+blah+new+mess%27age+%22dho%22+%21%21%0A%0AVla\"}'),
('220','277','2014-02-05 01:27:38','4','ASSET','ASSET_VALID_PUBLISHED','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"12\"}'),
('221','277','2014-02-05 01:28:07','4','ASSET','ASSET_HANDLED','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"idNewHandler\":\"4\"}'),
('222','277','2014-02-05 01:28:21','4','ASSET','ASSET_HANDLED','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"idNewHandler\":\"0\"}'),
('223','277','2014-02-05 01:30:10','4','SCENE','SCENE_HANDLED','{\"sceneID\":\"1\",\"idNewHandler\":\"4\"}'),
('224','277','2014-02-05 01:32:39','4','SCENE','SCENE_NEW_MESSAGE','{\"sceneID\":\"1\",\"deptID\":\"9\",\"txtMess\":\"zawaah%0AT%27est+dailies+%21%21%0Ach%C3%B4%C3%B4%C3%B4%C3%B4\"}'),
('225','277','2014-02-05 01:32:51','4','SCENE','SCENE_VALID_PUBLISHED','{\"sceneID\":\"1\",\"deptID\":\"9\"}'),
('226','277','2014-02-05 01:33:25','4','SCENE','SCENE_NEW_PUBLISHED','{\"sceneID\":\"1\",\"deptID\":\"9\"}'),
('227','277','2014-02-05 01:35:44','4','ROOT','FINAL_NEW_MESSAGE','Oooooooowwww yeah !'),
('228','277','2014-02-05 01:49:38','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"testZa\"}'),
('229','277','2014-02-05 01:54:32','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('230','277','2014-02-05 01:55:16','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('231','277','2014-02-05 01:57:36','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('232','277','2014-02-05 01:59:33','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('233','277','2014-02-05 02:04:15','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"owkay%2C+voyons+ce+que+%C3%A7a+donne\"}'),
('234','277','2014-02-05 02:05:22','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"encore\"}'),
('235','277','2014-02-05 02:07:32','4','ASSET','ASSET_NEW_PUBLISHED','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"12\"}'),
('236','277','2014-02-05 02:08:32','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"12\",\"txtMess\":\"Waahzzoy\"}'),
('237','277','2014-02-05 02:09:23','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"12\",\"txtMess\":\"qdfgqdf+g\"}'),
('238','277','2014-02-05 02:09:39','4','ASSET','ASSET_NEW_MESSAGE','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"12\",\"txtMess\":\"srthsfgb+nrs+nzyrtn\"}'),
('239','277','2014-02-05 02:10:56','4','ASSET','ASSET_MOD_PUBLISHED','{\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"12\"}'),
('240','277','2014-02-05 02:17:29','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('241','277','2014-02-05 02:17:59','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('242','277','2014-02-05 02:18:43','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('243','277','2014-02-05 02:20:06','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('244','277','2014-02-05 02:47:13','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('245','312','2014-02-05 02:48:02','4','ROOT','BANK_UPLOAD','{\"idProject\":\"312\",\"nbF\":\"1\",\"folder\":\"images\"}'),
('246','277','2014-02-05 02:48:19','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"waza\"}'),
('247','277','2014-02-05 02:57:22','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"sthzrt+zrt+zrt\"}'),
('248','277','2014-02-05 02:58:03','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"drhr\"}'),
('249','277','2014-02-05 02:59:04','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"gniuk+gniuk\"}'),
('250','277','2014-02-05 02:59:39','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"qeffbqeb\"}'),
('251','277','2014-02-05 03:01:00','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"rthrth\"}'),
('252','277','2014-02-05 03:03:07','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"srgbsrb+srtbrtb\"}'),
('253','277','2014-02-05 03:03:46','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"srthzrsth\"}'),
('254','277','2014-02-05 03:05:12','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"ertyerty\"}'),
('255','277','2014-02-05 03:06:47','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"nty+detnyteyn+eyt\"}'),
('256','277','2014-02-05 03:08:03','4','ASSET','ASSET_NEW_MESSAGE','{\"idAsset\":\"12\",\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"12\",\"txtMess\":\"wazzzoooouy\"}'),
('257','277','2014-02-05 03:09:30','4','ASSET','ASSET_NEW_MESSAGE','{\"idAsset\":\"12\",\"pathAsset\":\"characters/moon/\",\"nameAsset\":\"moon.blend\",\"deptID\":\"12\",\"txtMess\":\"ertyerty\"}'),
('258','277','2014-02-05 03:11:34','4','SCENE','SCENE_NEW_MESSAGE','{\"sceneID\":\"1\",\"deptID\":\"9\",\"txtMess\":\"test+wazz\"}'),
('259','277','2014-02-05 03:12:06','4','SCENE','SCENE_NEW_MESSAGE','{\"sceneID\":\"1\",\"deptID\":\"9\",\"txtMess\":\"ouh+yeaw\"}'),
('260','277','2014-02-05 03:12:31','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('261','277','2014-02-05 03:13:58','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('262','277','2014-02-05 03:15:07','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('263','277','2014-02-05 03:15:54','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('264','277','2014-02-05 03:16:25','4','ROOT','BANK_UPLOAD','{\"idProject\":\"277\",\"nbF\":\"1\",\"folder\":\"wouza\"}'),
('265','277','2014-02-05 15:32:44','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"981\",\"dept\":\"anims\",\"txtMess\":\"Kikooo+%21%21\"}'),
('266','277','2014-02-05 15:36:18','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"981\",\"dept\":\"anims\",\"txtMess\":\"srthsrth+sthz+rt\"}'),
('267','277','2014-02-05 15:37:58','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"981\",\"dept\":\"anims\",\"txtMess\":\"sdfb+sz\"}'),
('268','277','2014-02-05 15:38:51','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"808\",\"dept\":\"anims\",\"txtMess\":\"owkay+%21%21\"}'),
('269','277','2014-02-05 15:45:01','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"981\",\"dept\":\"anims\",\"txtMess\":\"wazzaah+%21%21+Juste+pour+voir+si+je+re%C3%A7oit+bien+le+mail+d%27alert+temps+r%C3%A9el+%21%21+On+verra+bien+le+truc+%21%21\"}'),
('270','277','2014-02-05 15:48:36','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"983\",\"dept\":\"anims\",\"txtMess\":\"Juste+un+test+en+local%2C+pour+voir+si+les+my_shots+sont+respect%C3%A9s+%21%0AD%C3%A9sol%C3%A9+pour+la+pollution+de+bo%C3%AEte+email+%21%0A%0AEn+tout+cas%2C+%C3%A7a+va+%C3%AAtre+vachement+%2B+joli+qu%27avant+%21%0Alol%0A%2B%2B+%21\"}'),
('271','277','2014-02-05 15:54:38','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"981\",\"dept\":\"anims\",\"txtMess\":\"gniuk+gniuk\"}'),
('272','277','2014-02-05 16:00:55','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"981\",\"dept\":\"anims\",\"txtMess\":\"zrtzrtg\"}'),
('273','277','2014-02-05 16:01:41','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"981\",\"dept\":\"anims\",\"txtMess\":\"ertyerty\"}'),
('274','277','2014-02-05 16:03:28','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"981\",\"dept\":\"anims\",\"txtMess\":\"ertherth+rth\"}'),
('275','277','2014-02-05 16:18:58','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"981\",\"dept\":\"anims\",\"txtMess\":\"xoinerg+oi+fgfg\"}'),
('276','277','2014-02-05 16:19:16','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"981\",\"dept\":\"anims\",\"txtMess\":\"sfgsdfg\"}'),
('277','277','2014-02-05 16:26:48','4','SHOT','SHOT_NEW_MESSAGE','{\"idShot\":\"981\",\"dept\":\"anims\",\"txtMess\":\"wouzaaa+%21%21\"}'),
('278','277','2014-02-06 00:13:34','4','SCENE','SCENE_NEW_PUBLISHED','{\"sceneID\":\"12\",\"deptID\":\"9\"}'),
('279','277','2014-02-06 00:16:40','4','SCENE','SCENE_VALID_PUBLISHED','{\"sceneID\":\"12\",\"deptID\":\"9\"}'),
('280','277','2014-02-06 00:16:48','4','SCENE','SCENE_NEW_PUBLISHED','{\"sceneID\":\"12\",\"deptID\":\"9\"}'),
('281','277','2014-02-06 00:24:26','4','SCENE','SCENE_MOD_PUBLISHED','{\"sceneID\":\"12\",\"deptID\":\"9\"}'),
('282','277','2014-02-06 00:30:38','4','SCENE','SCENE_VALID_PUBLISHED','{\"sceneID\":\"12\",\"deptID\":\"9\"}'),
('283','277','2014-02-06 00:30:54','4','SCENE','SCENE_NEW_PUBLISHED','{\"sceneID\":\"12\",\"deptID\":\"9\"}'),
('284','277','2014-02-06 00:36:06','4','SCENE','SCENE_MOD_PUBLISHED','{\"sceneID\":\"12\",\"deptID\":\"9\"}');


-- ----------------- TABLE saam_news ------------------------

DROP TABLE IF EXISTS `saam_news`;

CREATE TABLE `saam_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ID_creator` int(4) NOT NULL,
  `visible` tinyint(1) NOT NULL,
  `new_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `new_title` varchar(255) NOT NULL,
  `new_text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

INSERT INTO `saam_news` VALUES 
('1','1','1','2030-01-01 16:12:36','SaAM 0.99','<p class=\\\"big colorErrText\\\">
Nouvelle version du SaAM !
</p>
<p>Changelog :</p>
<p class=\\\"marge10l colorHard\\\">
* nouvelle partie : SCÈNES !!<br>
* choix du timing de la déconnexion auto dans les préférences<br>
* refonte de la BANK générale<br>
* refonte du système d\\\'envoi d\\\'email / dailies<br>
</p>
<p class=\\\"colorHard\\\">
Le SaAM est quasiment terminé.<br>
La version 1.0 sortira quand nous auront fait des tutos vidéos,<br>
rédigé le wiki, et terminé une version stable de l\\\'API python !
</p>
'),
('13','2','0','2012-07-04 21:50:39','ADD project utilisable','drag and drop pour les vignettes'),
('14','2','0','2012-07-10 18:10:15','Integration vraies données en cours','Les informations que vous voyez dans le SaAM ne sont pas forcément le reflet de la base de données... Leur intégration est en cous.'),
('15','2','0','2012-07-10 18:02:15','ADD / MOD User utilisable','acl wip'),
('16','2','0','2012-07-19 23:10:45','Masterfile xml','fichier \\\'thesaurus\\\' global'),
('18','2','0','2012-07-27 02:24:37','ACL, gestion droits UI','gestion visibilité Module interface en fonction du status -> DONE'),
('19','2','0','2013-02-04 17:06:33','Chat direct','Malgré quelques petits bugs, ça semble marcher...');


-- ----------------- TABLE saam_notes ------------------------

DROP TABLE IF EXISTS `saam_notes`;

CREATE TABLE `saam_notes` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `position` int(9) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ID_user` int(5) NOT NULL,
  `note` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO `saam_notes` VALUES 
('7','1','2013-07-22 15:30:44','4','et%2C+hop+l%C3%A0+%21+encore+une+petite+pour+la+route+%21%0A%0Aon+va+pas+cracher+dessus...'),
('6','2','2013-07-22 15:29:25','4','WAZZAAAAa%0A%0Avla+de+la+note+qui+d%C3%A9boite...'),
('9','1','2013-07-24 12:50:28','4','on+va+bien+voir...%0A%0Abah+%C3%A7a+marche+pas+mal+tout+%C3%A7a+%21'),
('14','0','2013-07-24 12:53:20','4','Lorem+ipsum+et+dolor+sit+amet+nur+bratisclava+nonobstant+blor+lorem+ipsum+et+dolor+sit+amet+nur+bratisclava+nonobstant+blor+%21%0A%0Alorem+ipsum+et+dolor+sit+amet.'),
('18','0','2013-07-24 13:00:26','4','OWKAY+%21');


