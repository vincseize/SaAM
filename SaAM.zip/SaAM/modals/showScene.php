
<script src="ajax/depts/dept_scenes.js"></script>


<div class="bordBankSection" id="sectionSceneParent">
	<?php include('scenes_specific/showScene_parent.php'); ?>
</div>

<div id="sectionSceneSelect">
	<?php include('scenes_specific/showScene_selected.php'); ?>
</div>