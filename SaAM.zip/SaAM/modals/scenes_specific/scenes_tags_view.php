<?php
	@session_start();
	require_once ($_SESSION['INSTALL_PATH_INC'].'/checkConnect.php' );

	/////////// TAGS VIEW ///////////////
?>

<div id="scenesList">
	<div>
		<p class="marge10l gros leftText ui-state-disabled">No tag yet.</p>
	</div>
</div>

