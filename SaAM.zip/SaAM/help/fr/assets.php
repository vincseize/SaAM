
<a id="assets"></a>
<h2 class="ui-state-default ui-corner-top pad3">Assets<div class="floatR marge30r doigt btnTop"><span class="ui-icon ui-icon-arrowreturn-1-n"></span></div></h2>
	<ol>
		<li>
			<h4>Définition d'un asset</h4>
				<p></p>
		</li>
		<li>
			<h4>Ajouter un asset</h4>
				<p></p>
		</li>
		<li>
			<h4>Modifier un asset</h4>
				<p></p>
		</li>
		<li>
			<h4>Archiver un asset</h4>
				<p></p>
		</li>
		<li>
			<h4>Discussions autour d'un asset</h4>
				<p>(messages commentaires, koi)</p>
		</li>
		<li>
			<h4>Supprimer un asset</h4>
				<p></p>
		</li>
		<li>
			<h4>Vos assets</h4>
			<div class="margeTop10" id="help_vos_assets">
				<img src="<?php echo $dirHelp ?>/help_mes_assets.jpg" class="floatL marge10r marge15bot shadowOut"/>
				<p>Il s'agit des assets qui vous concernent (assets dont vous faites partie de l'équipe).</p>
				<p>Cliquer sur un asset vous permet d'accéder directement à l'asset, via le dernier département visité de la section "assets".</p>
				<p>La liste est rafraîchie toutes les 3 minutes.<br />Scroll vertical molette souris possible.</p>
				<div class="fixFloat"></div>
				<p>Les attributions se font dans la section "assets", en ouvrant un asset <i>(des droits utilisateurs spéciaux sont nécessaires)</i></p>
				<img src="<?php echo $dirHelp ?>/help_mes_assets2.jpg" class="marge10r shadowOut"/>
			</div>
		</li>
	</ol>
