
<a id="users"></a>
<h2 class="ui-state-default ui-corner-top pad3">Utilisateurs<div class="floatR marge30r doigt btnTop"><span class="ui-icon ui-icon-arrowreturn-1-n"></span></div></h2>
	<ol>
		<li>
			<h4>Droits des utilisateurs</h4>
			<p>SaAM utilise un système d'ACL (Access Control List) pour gérer les droits des actions de chaque statut d'utilisateur. En voici les tables principales :</p>
			<div class="petit">
				<?php include('ACL_fr.php'); ?>
			</div>
		</li>
		<li>
			<h4>Préférences utilisateur</h4>
				<p></p>
		</li>
		<li>
			<h4>Gestion des utilisateurs</h4>
				<p></p>
		</li>
	</ol>