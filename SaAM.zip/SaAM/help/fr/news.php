
<a id="news"></a>
<h2 class="ui-state-default ui-corner-top pad3">Nouvelles<div class="floatR marge30r doigt btnTop"><span class="ui-icon ui-icon-arrowreturn-1-n"></span></div></h2>
	<ol>
		<li>
			<h4>Créer une nouvelle</h4>
				<p></p>
		</li>
		<li>
			<h4>Modifier une nouvelle</h4>
				<p></p>
		</li>
		<li>
			<h4>Supprimer une nouvelle</h4>
				<p></p>
		</li>
	</ol>