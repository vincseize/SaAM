
<a id="tasks"></a>
<h2 class="ui-state-default ui-corner-top pad3">Tâches<div class="floatR marge30r doigt btnTop"><span class="ui-icon ui-icon-arrowreturn-1-n"></span></div></h2>
	<ol>
		<li>
			<h4>Définition des tâches</h4>
				<p></p>
		</li>
		<li>
			<h4>Ajouter une tâche</h4>
				<p></p>
		</li>
		<li>
			<h4>Modifier une tâche</h4>
				<p></p>
		</li>
		<li>
			<h4>Discussions autour d'une tâche</h4>
				<p>(messages commentaires, koi)</p>
		</li>
		<li>
			<h4>Supprimer une tâche</h4>
				<p></p>
		</li>
		<li>
			<h4>Vos tâches</h4>
			<div class="margeTop10" id="help_vos_taches">
				<img src="<?php echo $dirHelp ?>/help_mes_taches.jpg" class="floatL marge10r shadowOut"/>
				<p>Il s'agit des tâches qui vous concernent.</p>
				<ul>
					<li class="colorActiveFolder gras">En <span>bleu</span> celles qui vous sont attribuées</li>
					<li class="colorDiscret gras">en <span >gris</span> celles qui sont libres (attribuées à personne)</li>
					<li class="colorMid gras">Un bord jaune vous indique que vous êtes le créateur de cette tâche</li>
				</ul>
				<p>La liste est rafraîchie toutes les 3 minutes.<br />Scroll vertical molette souris possible.</p>
				<div class="fixFloat"></div>
				<p>Les attributions se font dans la section "tâches", ou bien via l'îcone "taches" d'un plan, d'une scene ou d'un asset. <i>(des droits utilisateurs spéciaux sont nécessaires)</i></p>
				<img src="<?php echo $dirHelp ?>/help_mes_taches2.jpg" class="shadowOut"/>
			</div>
		</li>
	</ol>