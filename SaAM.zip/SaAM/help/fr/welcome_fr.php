<p>
	Voici le <b class="colorBtnFake">SaAM, version <?php echo SAAM_VERSION ;?></b>.
</p>
<p>
	Vous pouvez commencer par ajouter un nouveau projet, en cliquant sur l'onglet + ci dessus. Allez aussi faire
	un tour dans vos préférences tout en haut, pour envoyer un avatar, et n'hésitez pas à consulter l'aide !
</p>
<p>
	Tutoriel Video <a href="http://youtu.be/yl5HEqhTGTU" target="_blank"> [ <u>ICI</u> ] </a>
</p>
<p>
	<b class="colorBtnFake">Tip : Appuyer sur la touche [ h ] du clavier, pour afficher | fermer l'aide sur l'élément survolé !</b>
</p>
<p>
	L'arbre ci-contre est vivant : Au plus il y aura de projets en cours, au plus il aura de branches !
</p>
<p class="mini colorDiscret">
	Ps: L'apparition soudaine de la mention rouge "Travaux en cours", dans le menu supérieur, indique seulement qu'une mise à jour est en cours;<br />
	Ceci n'empêche généralement aucunement SaAM d'être opérationnel.<br />
	Dans tous les cas, n'oubliez pas que vous pouvez rafraîchir le SaAM en cas de bug, avec la touche "F5".
</p>
