
<a id="notes"></a>
<h2 class="ui-state-default ui-corner-top pad3">Notes<div class="floatR marge30r doigt btnTop"><span class="ui-icon ui-icon-arrowreturn-1-n"></span></div></h2>
	<ol>
		<li>
			<h4>Gestion des notes personelles</h4>
		</li>
		<li>
			<h4>Vos notes</h4>
			<div class="margeTop10" id="help_vos_notes">
				<img src="<?php echo $dirHelp ?>/help_mes_notes.jpg" class="floatL marge10r shadowOut"/>
				<p>Il s'agit de la liste de vos notes personnelles.</p>
				<p>Cliquer sur une note ouvrira la page de gestion de vos notes personelles.</p>
				<p>La liste est rafraîchie toutes les 3 minutes.<br />Scroll vertical molette souris possible.</p>
				<div class="fixFloat"></div>
			</div>
		</li>
	</ol>