
<a id="notes"></a>
<h2 class="ui-state-default ui-corner-top pad3">Notes<div class="floatR marge30r doigt btnTop"><span class="ui-icon ui-icon-arrowreturn-1-n"></span></div></h2>
	<ol>
		<li>
			<h4>Manage personnal notes</h4>
		</li>
		<li>
			<h4>Your notes</h4>
			<div class="margeTop10" id="help_vos_notes">
				<img src="<?php echo $dirHelp ?>/help_mes_notes.jpg" class="floatL marge10r shadowOut"/>
				<p>This is the list of your personnal notes.</p>
				<p>Clicking on a note will open the "notes" panel.</p>
				<p>This list is refreshed every 3 minutes.<br />Vertical scroll available with mouse wheel.</p>
				<div class="fixFloat"></div>
			</div>
		</li>
	</ol>