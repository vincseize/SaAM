<p>
	Here is the <b class="colorBtnFake">SaAM, version <?php echo SAAM_VERSION ;?></b>.
</p>
<p>
	You can start by adding a project: click on the "+" tab above. You can also check your preferences at the top of this page,
	to send your avatar, and don't hesitate to consult the help section!
</p>
<p>
	Video tutorial <a href="http://youtu.be/yl5HEqhTGTU" target="_blank"> [ <u>HERE</u> ] </a>
</p>
<p>
	<b class="colorBtnFake">Tip : Press th key [ h ], to show | hide some help about the hovered element!</b>
</p>
<p>
	The tree below is alive: the more there are projects, the more it got branches!
</p>
<p class="mini colorDiscret">
	Ps: sudden apparition of the red mention "Work in progress!" at the top of the page, only means that there is an update ongoing;<br />
	This usually don't block anything, you just have to be carefull.<br />
	By the way, don't forget that you can refresh the SaAM in case of a bug, with the hotkey "F5".
</p>

