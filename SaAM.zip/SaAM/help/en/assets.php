
<a id="assets"></a>
<h2 class="ui-state-default ui-corner-top pad3">Assets<div class="floatR marge30r doigt btnTop"><span class="ui-icon ui-icon-arrowreturn-1-n"></span></div></h2>
	<ol>
		<li>
			<h4>Assets structure</h4>
				<p></p>
		</li>
		<li>
			<h4>Add an asset</h4>
				<p></p>
		</li>
		<li>
			<h4>Modify an asset</h4>
				<p></p>
		</li>
		<li>
			<h4>Archive an asset</h4>
				<p></p>
		</li>
		<li>
			<h4>Asset discussions</h4>
				<p>(messages comments, ...)</p>
		</li>
		<li>
			<h4>Delete an asset</h4>
				<p></p>
		</li>
		<li>
			<h4>Your assets</h4>
			<div class="margeTop10" id="help_vos_assets">
				<img src="<?php echo $dirHelp ?>/help_mes_assets.jpg" class="floatL marge10r marge15bot shadowOut"/>
				<p>This is the list of all assets assigned to you. (assets which you are in team of).</p>
				<p>Click on an asset allows you to open directly the asset, within the last visited department of section "assets".</p>
				<p>This list is refreshed all 3 minutes.<br />Vertical scroll available with mouse wheel.</p>
				<div class="fixFloat"></div>
				<p>Assignations are made within the "assets" section, and opening an asset. <i>(special user status needed)</i></p>
				<img src="<?php echo $dirHelp ?>/help_mes_assets2.jpg" class="marge10r shadowOut"/>
			</div>
		</li>
	</ol>
