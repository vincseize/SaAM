
<a id="news"></a>
<h2 class="ui-state-default ui-corner-top pad3">News<div class="floatR marge30r doigt btnTop"><span class="ui-icon ui-icon-arrowreturn-1-n"></span></div></h2>
	<ol>
		<li>
			<h4>Add a news</h4>
				<p></p>
		</li>
		<li>
			<h4>Modify a news</h4>
				<p></p>
		</li>
		<li>
			<h4>Delete a news</h4>
				<p></p>
		</li>
	</ol>
