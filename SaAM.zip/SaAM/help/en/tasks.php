
<a id="tasks"></a>
<h2 class="ui-state-default ui-corner-top pad3">Tasks<div class="floatR marge30r doigt btnTop"><span class="ui-icon ui-icon-arrowreturn-1-n"></span></div></h2>
	<ol>
		<li>
			<h4>Tasks structure</h4>
				<p></p>
		</li>
		<li>
			<h4>Add a task</h4>
				<p></p>
		</li>
		<li>
			<h4>Modify a task</h4>
				<p></p>
		</li>
		<li>
			<h4>Task discussions</h4>
				<p>(messages comments, ...)</p>
		</li>
		<li>
			<h4>Delete a task</h4>
				<p></p>
		</li>
		<li>
			<h4>Your Tasks</h4>
			<div class="margeTop10" id="help_vos_taches">
				<img src="<?php echo $dirHelp ?>/help_mes_taches.jpg" class="floatL marge10r shadowOut"/>
				<p>This is the list of all tasks that concern you.</p>
				<ul>
					<li class="colorActiveFolder gras">In <span>blue</span> those which you are assigned to</li>
					<li class="colorDiscret gras">In <span >grey</span> those which are free (not assigned to anybody)</li>
					<li class="colorMid gras">A yellow border tells you that your are the creator of the task</li>
				</ul>
				<p>This list is refreshed all 3 minutes.<br />Vertical scroll available with mouse wheel.</p>
				<div class="fixFloat"></div>
				<p>Attributions are made within the "tasks" section, or via the "tasks" button of a shot, scene or asset. <i>(special user status needed)</i></p>
				<img src="<?php echo $dirHelp ?>/help_mes_taches2.jpg" class="shadowOut"/>
			</div>
		</li>
	</ol>
