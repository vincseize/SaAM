
<a id="users"></a>
<h2 class="ui-state-default ui-corner-top pad3">Users<div class="floatR marge30r doigt btnTop"><span class="ui-icon ui-icon-arrowreturn-1-n"></span></div></h2>
	<ol>
		<li>
			<h4>Users rules</h4>
			<p>SaAM uses an ACL system (Access Control List) to manage users actions permissions according to user status. Here is the main ACL table :</p>
			<div class="petit">
				<?php include('ACL_en.php'); ?>
			</div>
		</li>
		<li>
			<h4>Users preferences</h4>
				<p></p>
		</li>
		<li>
			<h4>Users administration</h4>
				<p></p>
		</li>
	</ol>