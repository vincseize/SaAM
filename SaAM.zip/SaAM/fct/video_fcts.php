<?php

function convert_video_OGG ($videoPath) {
	// @TODO : Fonction de conversion de vidéo en OGG pour compatibilité générale.
	return true;
}

?>
