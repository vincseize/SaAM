<?php
	@session_start();
	require_once ("../inc/checkConnect.php" );
    
?>

<div class="headerStage">
	<div class="inline deptBtn colorSoft" type="apps" content="apps_list" active>Liste</div>
	<div class="inline deptBtn colorSoft" type="apps" content="apps_install">Installer</div>
</div>

<div class="pageContent">
	<h2>Applications, scripts disponibles</h2>
</div>
