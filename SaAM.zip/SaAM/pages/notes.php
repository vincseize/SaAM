<?php
	@session_start();
	require_once ("../inc/checkConnect.php" );

?>

<div class="headerStage">
	<div class="inline deptBtn colorSoft" type="notes" content="notes_list" active><?php echo L_LIST; ?></div>
</div>

<div class="pageContent">

</div>

<div class="ui-corner-all" id="retourAjax"></div>