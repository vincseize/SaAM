<?php
	@session_start();
	require_once ("../inc/checkConnect.php" );
    
?>

<div class="headerStage">
	<div class="inline deptBtn colorSoft" type="langs" content="list_langs" active>Langues</div>
</div>

<div class="ui-corner-all doigt" id="retourAjax"></div>

<div class="pageContent">
	
</div>
