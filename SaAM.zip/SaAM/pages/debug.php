<?php
	@session_start();
	require_once ("../inc/checkConnect.php" );

?>

<div class="headerStage">
    <div class="inline deptBtn colorSoft" type="../_RECETTE" content="debug_draft" active>DEBUG</div>
    <div class="inline deptBtn colorSoft" type="../_RECETTE/projects" content="recette_projects">RECETTE PROJECTS</div>
    <div class="inline deptBtn colorSoft" type="../_RECETTE/users" content="recette_users">RECETTE USERS</div>

</div>

<div class="pageContent">

</div>
