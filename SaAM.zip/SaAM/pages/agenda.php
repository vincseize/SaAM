<?php
	@session_start();
	require_once ("../inc/checkConnect.php" );
    
?>

<div class="pageContent">
	AGENDA DU PROJET SÉLECTIONNÉ
</div>
