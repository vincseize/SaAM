
<script>
	$(function() {
		$('.bouton').button();
		$('#calendarNav').hide();
	});
</script>

<h2>INTRANET</h2>

<p>Exploration du serveur</p>