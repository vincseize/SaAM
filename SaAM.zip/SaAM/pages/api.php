<?php
	@session_start();
	require_once ("../inc/checkConnect.php" );
?>

<div class="headerStage">
	<div class="inline deptBtn colorSoft" type="api" content="api_api" active>API</div>
	<div class="inline deptBtn colorSoft" type="api" content="api_css">Css</div>
</div>

<div class="pageContent">
	<h2>API</h2>
</div>
