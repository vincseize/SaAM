<?php
	@session_start();
	require_once ("../inc/checkConnect.php" );
    
?>

<div class="headerStage">
	<div class="inline deptBtn colorSoft" type="admins" content="news_list" active>Liste</div>
	<div class="inline deptBtn colorSoft" type="admins" content="news_add">Ajouter</div>
</div>

<div class="ui-corner-all" id="retourAjax"></div>

<div class="pageContent">
	
</div>